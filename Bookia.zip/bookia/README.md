# 📚 Bookia — Librería Pick-Up (PHP Puro)

## ⚡ Instalación rápida

### 1. Copiar archivos
Copia la carpeta **completa** a:
```
C:\xampp\htdocs\bookia\
```

### 2. Importar base de datos
1. Inicia **Apache** y **MySQL** en XAMPP Control Panel
2. Abre: `http://localhost/phpmyadmin`
3. Clic en **Importar** → selecciona `bookia.sql` → **Continuar**

### 3. Abrir el sitio
```
http://localhost/bookia/
```
> ⚠️ IMPORTANTE: Abre desde `http://localhost/bookia/` — NO desde el explorador de archivos

---

## 👤 Cuentas de prueba
Contraseña de todos: **Bookia2026**

| Rol     | Correo               |
|---------|----------------------|
| Admin   | admin@bookia.com     |
| Admin   | angela@bookia.com    |
| Usuario | maria@example.com    |
| Usuario | juan@example.com     |

---

## 📁 Estructura del proyecto
```
bookia/
├── index.php          ← Página principal
├── login.php          ← Inicio de sesión
├── registro.php       ← Registro de usuarios
├── logout.php         ← Cerrar sesión
├── catalogo.php       ← Catálogo con filtros
├── reservar.php       ← Reservar libro
├── perfil.php         ← Perfil del usuario
├── admin.php          ← Panel administrador
├── servicios.php
├── contacto.php
├── includes/
│   ├── config.php     ← BD y utilidades
│   ├── session.php    ← Manejo de sesión PHP
│   ├── header.php     ← Navbar
│   └── footer.php     ← Footer
├── css/               ← Estilos
├── js/                ← Carousel y animaciones
├── img/               ← Logo
└── bookia.sql         ← Base de datos
```

---

## ✅ Diferencias con la versión anterior
- **100% PHP** — Sin dependencia de fetch/JavaScript para el login
- **Sesión PHP nativa** — `$_SESSION` en lugar de `sessionStorage`
- **Login funciona desde el primer momento** — Sin problemas de CORS
- **Libros cargados directamente de MySQL** — Sin spinners infinitos
