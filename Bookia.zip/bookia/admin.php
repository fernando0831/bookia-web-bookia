<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/session.php';
require_admin();

$u   = session_user();
$tab = $_GET['tab'] ?? 'dashboard';
$msg = '';

// ── Acciones POST ────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    try {
        $pdo = db();
        if ($action === 'add_libro') {
            $pdo->prepare(
                'INSERT INTO libros (id,titulo,autor,genero,anio,disponibles,descripcion,imagen,isbn) VALUES(?,?,?,?,?,?,?,?,?)'
            )->execute([uuid(),$_POST['titulo'],$_POST['autor'],$_POST['genero'],$_POST['anio']??null,$_POST['disponibles']??0,$_POST['descripcion']??'',$_POST['imagen']??'',$_POST['isbn']??'']);
            $msg = '✅ Libro agregado.'; $tab = 'libros';
        } elseif ($action === 'edit_libro') {
            $pdo->prepare(
                'UPDATE libros SET titulo=?,autor=?,genero=?,anio=?,disponibles=?,descripcion=?,imagen=?,isbn=? WHERE id=?'
            )->execute([$_POST['titulo'],$_POST['autor'],$_POST['genero'],$_POST['anio']??null,$_POST['disponibles']??0,$_POST['descripcion']??'',$_POST['imagen']??'',$_POST['isbn']??'',$_POST['id']]);
            $msg = '✅ Libro actualizado.'; $tab = 'libros';
        } elseif ($action === 'del_libro') {
            $pdo->prepare('DELETE FROM libros WHERE id=?')->execute([$_POST['id']]);
            $msg = '✅ Libro eliminado.'; $tab = 'libros';
        } elseif ($action === 'add_user') {
            // RBAC: solo superadmin puede asignar rol admin/superadmin
            $rol_nuevo = in_array($_POST['rol']??'', ['usuario','editor','admin','superadmin']) ? $_POST['rol'] : 'usuario';
            if (in_array($rol_nuevo, ['superadmin','admin']) && !is_superadmin()) {
                $msg = '⛔ Solo el SUPERADMIN puede asignar roles de admin/superadmin.'; $tab = 'usuarios';
            } else {
                $hash = password_hash($_POST['password'], PASSWORD_BCRYPT, ['cost'=>12]);
                $pdo->prepare('INSERT INTO usuarios (id,nombre,email,telefono,rol,password_hash) VALUES(?,?,?,?,?,?)')
                    ->execute([uuid(),$_POST['nombre'],$_POST['email'],$_POST['telefono']??'',$rol_nuevo,$hash]);
                registrar_auditoria('USUARIO_CREADO', "email={$_POST['email']} rol=$rol_nuevo");
                $msg = '✅ Usuario agregado.'; $tab = 'usuarios';
            }
        } elseif ($action === 'edit_user') {
            // RBAC: cambiar_rol => solo superadmin
            $rol_nuevo = $_POST['rol'] ?? null;
            if ($rol_nuevo !== null && !is_superadmin()) {
                // Admin no puede cambiar roles
                $rol_nuevo = null;
                $msg = '⚠️ Rol no modificado (solo SUPERADMIN puede cambiar roles). ';
            }
            $sql = 'UPDATE usuarios SET nombre=?,email=?,telefono=?' . ($rol_nuevo ? ',rol=?' : '');
            $params = [$_POST['nombre'],$_POST['email'],$_POST['telefono']??''];
            if ($rol_nuevo) $params[] = $rol_nuevo;
            if (!empty($_POST['password'])) { $sql .= ',password_hash=?'; $params[] = password_hash($_POST['password'],PASSWORD_BCRYPT,['cost'=>12]); }
            $sql .= ' WHERE id=?'; $params[] = $_POST['id'];
            $pdo->prepare($sql)->execute($params);
            registrar_auditoria('USUARIO_EDITADO', "id={$_POST['id']}");
            $msg .= '✅ Usuario actualizado.'; $tab = 'usuarios';
        } elseif ($action === 'del_user') {
            if ($_POST['id'] === $u['id']) { $msg = '⛔ No puedes eliminar tu propia cuenta.'; }
            elseif (!is_superadmin() && $_POST['id'] === 'u-superadmin-001') { $msg = '⛔ No puedes eliminar al SUPERADMIN.'; }
            else {
                $pdo->prepare('DELETE FROM usuarios WHERE id=?')->execute([$_POST['id']]);
                registrar_auditoria('USUARIO_ELIMINADO', "id={$_POST['id']}");
                $msg = '✅ Usuario eliminado.';
            }
            $tab = 'usuarios';
        } elseif ($action === 'edit_reserva') {
            $pdo->prepare('UPDATE reservas SET estado=? WHERE id=?')->execute([$_POST['estado'],$_POST['id']]);
            $msg = '✅ Estado actualizado.'; $tab = 'reservas';
        } elseif ($action === 'del_reserva') {
            $pdo->prepare('DELETE FROM reservas WHERE id=?')->execute([$_POST['id']]);
            $msg = '✅ Reserva eliminada.'; $tab = 'reservas';
        } elseif ($action === 'revocar_sesiones_usuario') {
            $targetId = $_POST['usuario_id'] ?? '';
            if ($targetId && $targetId !== $u['id']) {
                $pdo->prepare('UPDATE sessions SET activa=0 WHERE usuario_id=?')->execute([$targetId]);
                $pdo->prepare('UPDATE refresh_tokens SET revocado=1 WHERE usuario_id=?')->execute([$targetId]);
                $msg = '✅ Sesiones revocadas. El usuario será redirigido al login en segundos.';
            } else {
                $msg = '⚠️ No puedes revocar tu propia sesión desde aquí.';
            }
            $tab = 'usuarios';
        } elseif ($action === 'preferencias') {
            $tema   = ($_POST['tema_oscuro'] ?? '0') === '1' ? 1 : 0;
            $idioma = in_array($_POST['idioma'] ?? '', ['es','en']) ? $_POST['idioma'] : 'es';
            $pdo->prepare('UPDATE usuarios SET tema_oscuro=?, idioma=? WHERE id=?')
                ->execute([$tema, $idioma, $u['id']]);
            $_SESSION['bookia_user']['tema_oscuro'] = $tema;
            $_SESSION['bookia_user']['idioma']      = $idioma;
            $msg = '✅ Preferencias guardadas.'; $tab = 'preferencias';
        } elseif ($action === 'cambiar_password_admin') {
            $act  = $_POST['password_actual'] ?? '';
            $new  = $_POST['password_nueva']  ?? '';
            $conf = $_POST['password_conf']   ?? '';
            $row  = $pdo->prepare('SELECT password_hash FROM usuarios WHERE id=? LIMIT 1');
            $row->execute([$u['id']]); $row = $row->fetch();
            if (!password_verify($act, $row['password_hash']))  { $msg = '❌ Contraseña actual incorrecta.'; }
            elseif (strlen($new) < 8)                           { $msg = '❌ Mínimo 8 caracteres.'; }
            elseif ($new !== $conf)                             { $msg = '❌ Las contraseñas no coinciden.'; }
            else {
                $pdo->prepare('UPDATE usuarios SET password_hash=? WHERE id=?')
                    ->execute([password_hash($new, PASSWORD_BCRYPT, ['cost'=>12]), $u['id']]);
                $msg = '✅ Contraseña actualizada correctamente.';
            }
            $tab = 'seguridad';
        } elseif ($action === 'cerrar_sesion_admin') {
            $sid = $_POST['session_id'] ?? '';
            cerrar_sesion_bd($pdo, $sid, $u['id']);
            $msg = '✅ Sesión cerrada.'; $tab = 'seguridad';
        } elseif ($action === 'cerrar_otras_admin') {
            cerrar_otras_sesiones($pdo, $u['id']);
            $msg = '✅ Todas las otras sesiones han sido cerradas.'; $tab = 'seguridad';
        }
    } catch (Exception $e) {
        $msg = '❌ Error: ' . $e->getMessage();
    }
}

// ── Datos ────────────────────────────────────────────────────────
try {
    $pdo      = db();
    $libros   = $pdo->query('SELECT * FROM libros ORDER BY genero,titulo')->fetchAll();
    $usuarios = $pdo->query('SELECT * FROM usuarios ORDER BY nombre')->fetchAll();
    $reservas = $pdo->query(
        'SELECT r.*,u.nombre AS nombre_usuario FROM reservas r
         LEFT JOIN usuarios u ON r.usuario_id=u.id ORDER BY r.created_at DESC'
    )->fetchAll();
    $totalDisponibles = array_sum(array_column($libros, 'disponibles'));
    $librosAgotados   = count(array_filter($libros, fn($l)=>(int)$l['disponibles']===0));
    $stats = [
        'libros'      => count($libros),
        'disponibles' => $totalDisponibles,
        'usuarios'    => count($usuarios),
        'reservas'    => count($reservas),
        'pendientes'  => count(array_filter($reservas, fn($r)=>$r['estado']==='pendiente')),
        'agotados'    => $librosAgotados,
    ];
    $reservasRecientes = array_slice($reservas, 0, 5);
    $libroEdit = null;
    if ($tab === 'libros' && isset($_GET['edit'])) {
        foreach ($libros as $l) { if ($l['id']===$_GET['edit']) { $libroEdit=$l; break; } }
    }
    $userEdit = null;
    if ($tab === 'usuarios' && isset($_GET['edit'])) {
        foreach ($usuarios as $us) { if ($us['id']===$_GET['edit']) { $userEdit=$us; break; } }
    }
} catch (Exception $e) {
    $msg = '❌ Error de BD.'; $libros=[]; $usuarios=[]; $reservas=[]; $reservasRecientes=[];
    $stats=['libros'=>0,'disponibles'=>0,'usuarios'=>0,'reservas'=>0,'pendientes'=>0,'agotados'=>0];
}

$generosList = ['Ficción','No Ficción','Infantil','Misterio','Ciencia Ficción','Romance','Historia','Autoayuda'];
$estadosList = ['pendiente','lista','recogida','cancelada'];

function estadoPill(string $estado): string {
    $map = [
        'pendiente' => 'pill-yellow',
        'lista'     => 'pill-green',
        'recogida'  => 'pill-blue',
        'cancelada' => 'pill-red',
    ];
    $cls = $map[$estado] ?? 'pill-gray';
    return "<span class=\"pill {$cls}\">{$estado}</span>";
}
// Sesiones activas del admin
$_adm_sesiones = [];
$_adm_sid = session_id();
try {
    $_adm_sesiones = listar_sesiones(db(), $u['id']);
} catch (Exception $e) {}

// Preferencias de tema e idioma
$_adm_tema = 0; $_adm_idioma = 'es';
try {
    $pref = db()->prepare('SELECT tema_oscuro, idioma FROM usuarios WHERE id=? LIMIT 1');
    $pref->execute([$u['id']]);
    $row = $pref->fetch();
    if ($row) { $_adm_tema = (int)$row['tema_oscuro']; $_adm_idioma = $row['idioma']; }
} catch (Exception $e) {}
$en = $_adm_idioma === 'en';
?>
<!DOCTYPE html>
<html lang="<?= $_adm_idioma ?>" data-theme="<?= $_adm_tema ? 'dark' : 'light' ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $en ? 'Admin Panel — Bookia' : 'Panel Admin — Bookia' ?></title>
  <link rel="stylesheet" href="<?= url('css/estilos.css') ?>">
  <link rel="stylesheet" href="<?= url('css/animations.css') ?>">
  <style>
    .navbarAD { background: linear-gradient(135deg,#6B0F2A 0%,#8B1A3A 60%,#6B0F2A 100%); color:#fff; padding:0 40px; display:flex; justify-content:space-between; align-items:center; position:sticky; top:0; z-index:1000; box-shadow:0 3px 16px rgba(107,15,42,.45); min-height:76px; border-bottom:2px solid rgba(193,154,107,.35); }
    .navbarAD .logo { display:flex; align-items:center; gap:10px; text-decoration:none; }
    .navbarAD .logo img { height:44px; width:44px; border-radius:8px; object-fit:contain; }
    .navbarAD .logo-text { font-size:22px; font-weight:800; letter-spacing:2px; color:#C19A6B; font-family:'Georgia',serif; text-transform:uppercase; }
    .navbarAD ul { display:flex; list-style:none; gap:8px; align-items:center; margin:0; padding:0; }
    .navbarAD ul li { position:relative; }
    .navbarAD a { color:#fff; text-decoration:none; padding:8px 14px; border-radius:6px; transition:background .2s; font-size:15px; }
    .navbarAD > ul > li > a { font-weight:600; }
    .navbarAD a:hover { background:rgba(193,154,107,.2); color:#C19A6B; }
    .navbarAD .submenu { display:none; position:absolute; right:0; top:100%; background:#6B0F2A; min-width:180px; border-radius:8px; box-shadow:0 8px 24px rgba(0,0,0,.3); padding:6px 0; z-index:1001; }
    .navbarAD li:hover .submenu { display:block; }
    .navbarAD .submenu li { width:100%; }
    .navbarAD .submenu a { display:block; padding:10px 18px; font-size:14px; }
    .navbarAD .submenu a:hover { background:rgba(193,154,107,.25); color:#fff; }
  </style>
</head>
<body>

<!-- ═══════ NAVBAR ADMIN ═══════ -->
<nav class="navbarAD" role="navigation" aria-label="Navegación AD">
  <a href="<?= url('index.php') ?>" class="logo" aria-label="Bookia inicio">
    <img src="<?= url('img/logo.png') ?>" alt="Bookia" width="46" height="46">
    <span class="logo-text">BOOKIA <span class="badge-admin" style="font-size:11px;vertical-align:middle;margin-left:4px">ADMIN</span></span>
  </a>
  <button class="menu-toggle" aria-label="<?= $en?'Open menu':'Abrir menú' ?>" aria-expanded="false">☰</button>
  <ul role="menubar">
    <li><a href="<?= url('index.php') ?>" style="display:flex;align-items:center;gap:6px">🌐 <?= $en?'View Site':'Ver sitio' ?></a></li>
    <li class="has-submenu">
      <a href="#" aria-haspopup="true">🛡️ <?= e($u['nombre']) ?> ▾</a>
      <ul class="submenu">
        <li><a href="<?= url('logout.php') ?>" style="color:#fca5a5">🚪 <?= $en?'Log Out':'Cerrar Sesión' ?></a></li>
      </ul>
    </li>
  </ul>
</nav>

<!-- ═══════ BREADCRUMB ═══════ -->
<div class="breadcrumbs" style="padding:12px 40px">
  <ul>
    <li><a href="<?= url('index.php') ?>"><?= $en?'Home':'Inicio' ?></a></li>
    <li><span class="current"><?= $tab === 'dashboard' ? 'Dashboard' : ucfirst($tab) ?></span></li>
  </ul>
</div>

<div class="admin-layout">
  <!-- ═══════ SIDEBAR ═══════ -->
  <aside class="admin-sidebar" role="navigation" aria-label="Menú de administración">
    <div class="admin-sidebar-title">
      <h3><?= $en?'Control Panel':'Panel de Control' ?></h3>
      <p><?= $en?'Bookia Administration':'Administración Bookia' ?></p>
    </div>
    <ul class="admin-nav">
      <li><a href="?tab=dashboard"     class="<?= $tab==='dashboard'?'active':'' ?>"><span class="nav-icon">📊</span> Dashboard</a></li>
      <li><a href="?tab=libros"        class="<?= $tab==='libros'?'active':'' ?>"><span class="nav-icon">📚</span> <?= $en?'Books':'Libros' ?> <span class="admin-nav-badge"><?= $stats['libros'] ?></span></a></li>
      <li><a href="?tab=reservas"      class="<?= $tab==='reservas'?'active':'' ?>"><span class="nav-icon">🔖</span> <?= $en?'Reservations':'Reservas' ?> <span class="admin-nav-badge"><?= $stats['pendientes'] ?></span></a></li>
      <li><a href="?tab=usuarios"      class="<?= $tab==='usuarios'?'active':'' ?>"><span class="nav-icon">👥</span> <?= $en?'Users':'Usuarios' ?></a></li>
      <li style="margin-top:16px;border-top:1px solid rgba(193,154,107,.2);padding-top:12px">
        <a href="?tab=seguridad"     class="<?= $tab==='seguridad'?'active':'' ?>"><span class="nav-icon">🔒</span> <?= $en?'Security':'Seguridad' ?></a>
      </li>
      <li><a href="?tab=preferencias"  class="<?= $tab==='preferencias'?'active':'' ?>"><span class="nav-icon">⚙️</span> <?= $en?'Preferences':'Preferencias' ?></a></li>
      <?php if (is_superadmin()): ?>
      <li style="margin-top:8px">
        <a href="pentest.php" style="color:#f85149;font-weight:700"><span class="nav-icon">🔐</span> Pruebas Penetración</a>
      </li>
      <?php endif; ?>
    </ul>
  </aside>

  <!-- ═══════ CONTENIDO PRINCIPAL ═══════ -->
  <main class="admin-main">
    <?php if ($msg): ?>
      <div class="msg <?= str_contains($msg,'❌')?'msg-error':'msg-success' ?>" style="margin-bottom:16px">
        <span class="msg-icon"><?= str_contains($msg,'❌')?'✕':'✓' ?></span><?= e($msg) ?>
      </div>
    <?php endif; ?>

    <!-- ══ DASHBOARD ══ -->
    <?php if ($tab === 'dashboard'): ?>
      <div class="admin-page-header">
        <div>
          <h2>📊 Dashboard</h2>
          <p><?= $en?'Welcome':'Bienvenido' ?>, <strong><?= e($u['nombre']) ?></strong> · <?= $en?'General system overview':'Resumen general del sistema' ?></p>
        </div>
      </div>

      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon blue">📚</div>
          <div class="stat-info"><h4><?= $stats['libros'] ?></h4><p><?= $en?'Total books':'Total de libros' ?></p></div>
        </div>
        <div class="stat-card">
          <div class="stat-icon green">✅</div>
          <div class="stat-info"><h4><?= $stats['disponibles'] ?></h4><p><?= $en?'Available books':'Libros disponibles' ?></p></div>
        </div>
        <div class="stat-card">
          <div class="stat-icon orange">👥</div>
          <div class="stat-info"><h4><?= $stats['usuarios'] ?></h4><p><?= $en?'Registered users':'Usuarios registrados' ?></p></div>
        </div>
        <div class="stat-card">
          <div class="stat-icon purple">🔖</div>
          <div class="stat-info"><h4><?= $stats['reservas'] ?></h4><p><?= $en?'Total reservations':'Total reservas' ?></p></div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#ccfbf1">⏳</div>
          <div class="stat-info"><h4><?= $stats['pendientes'] ?></h4><p><?= $en?'Pending reservations':'Reservas pendientes' ?></p></div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#fee2e2">🚫</div>
          <div class="stat-info"><h4><?= $stats['agotados'] ?></h4><p><?= $en?'Out-of-stock books':'Libros agotados' ?></p></div>
        </div>
      </div>

      <!-- Reservas recientes -->
      <div class="table-card">
        <div class="table-card-header">
          <h3>🕒 <?= $en?'Recent reservations':'Reservas recientes' ?></h3>
          <a href="?tab=reservas" class="btn btn-sm btn-ghost"><?= $en?'View all →':'Ver todas →' ?></a>
        </div>
        <div class="table-responsive">
          <table>
            <thead>
              <tr>
                <th><?= $en?'Book':'Libro' ?></th>
                <th><?= $en?'User':'Usuario' ?></th>
                <th><?= $en?'Reservation date':'Fecha Reserva' ?></th>
                <th><?= $en?'Pick-up':'Recogida' ?></th>
                <th><?= $en?'Status':'Estado' ?></th>
                <th><?= $en?'Code':'Código' ?></th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($reservasRecientes)): ?>
                <tr><td colspan="6" style="text-align:center;padding:24px;color:#9CA3AF"><?= $en?'No reservations yet.':'No hay reservas aún.' ?></td></tr>
              <?php else: ?>
                <?php foreach ($reservasRecientes as $r): ?>
                  <tr>
                    <td>
                      <strong><?= e($r['titulo_libro'] ?? '—') ?></strong>
                      <br><small style="color:#6B7280"><?= e($r['autor_libro'] ?? '') ?></small>
                    </td>
                    <td><?= e($r['nombre_usuario'] ?? '—') ?></td>
                    <td><?= e(substr($r['fecha_reserva']??'',0,10)) ?></td>
                    <td><?= e($r['fecha_recogida']??'—') ?></td>
                    <td><?= estadoPill($r['estado']) ?></td>
                    <td><code style="font-size:11px;background:#f3f4f6;padding:3px 7px;border-radius:5px;font-weight:700;color:#6B0F2A"><?= e($r['codigo_recogida']??'—') ?></code></td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    <!-- ══ LIBROS ══ -->
    <?php elseif ($tab === 'libros'): ?>
      <div class="admin-page-header">
        <div><h2>📚 <?= $en?'Book Management':'Gestión de Libros' ?></h2><p><?= $stats['libros'] ?> <?= $en?'books in catalogue':'libros en catálogo' ?></p></div>
        <a href="?tab=libros&new=1" class="btn btn-sm">➕ <?= $en?'New book':'Nuevo libro' ?></a>
      </div>

      <?php if (isset($_GET['new']) || $libroEdit): ?>
        <div class="table-card" style="margin-bottom:24px">
          <div class="table-card-header"><h3><?= $libroEdit ? ($en?'Edit book':'Editar libro') : ($en?'New book':'Nuevo libro') ?></h3></div>
          <form method="POST" class="admin-form">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="<?= $libroEdit ? 'edit_libro' : 'add_libro' ?>">
            <?php if ($libroEdit): ?><input type="hidden" name="id" value="<?= e($libroEdit['id']) ?>"><?php endif; ?>
            <div class="form-row">
              <div class="form-group"><label><?= $en?'Title':'Título' ?> <span class="required">*</span></label><input type="text" name="titulo" value="<?= e($libroEdit['titulo']??'') ?>" required></div>
              <div class="form-group"><label><?= $en?'Author':'Autor' ?> <span class="required">*</span></label><input type="text" name="autor" value="<?= e($libroEdit['autor']??'') ?>" required></div>
            </div>
            <div class="form-row">
              <div class="form-group"><label><?= $en?'Genre':'Género' ?></label>
                <select name="genero"><?php foreach($generosList as $g): ?><option <?= ($libroEdit['genero']??'')===$g?'selected':'' ?>><?= e($g) ?></option><?php endforeach; ?></select>
              </div>
              <div class="form-row" style="gap:10px">
                <div class="form-group"><label><?= $en?'Year':'Año' ?></label><input type="number" name="anio" value="<?= e($libroEdit['anio']??'') ?>" min="0" max="2099"></div>
                <div class="form-group"><label><?= $en?'Available':'Disponibles' ?></label><input type="number" name="disponibles" value="<?= e($libroEdit['disponibles']??'0') ?>" min="0" required></div>
              </div>
            </div>
            <div class="form-group"><label><?= $en?'Image (URL)':'Imagen (URL)' ?></label><input type="url" name="imagen" value="<?= e($libroEdit['imagen']??'') ?>" placeholder="https://..."></div>
            <div class="form-group"><label>ISBN</label><input type="text" name="isbn" value="<?= e($libroEdit['isbn']??'') ?>"></div>
            <div class="form-group"><label><?= $en?'Description':'Descripción' ?></label><textarea name="descripcion" rows="3"><?= e($libroEdit['descripcion']??'') ?></textarea></div>
            <div style="display:flex;gap:10px;padding:0 0 16px">
              <button type="submit" class="btn btn-sm">💾 <?= $en?'Save':'Guardar' ?></button>
              <a href="?tab=libros" class="btn btn-ghost btn-sm"><?= $en?'Cancel':'Cancelar' ?></a>
            </div>
          </form>
        </div>
      <?php endif; ?>

      <div class="table-card">
        <div class="table-card-header">
          <h3><?= $en?'Full catalogue':'Catálogo completo' ?></h3>
          <div class="table-toolbar">
            <div class="search-box" style="min-width:210px">
              <span class="search-icon">🔍</span>
              <input type="search" id="search-libros" placeholder="<?= $en?'Title, author, ISBN...':'Título, autor, ISBN...' ?>" oninput="filtrarTabla('tabla-libros-body', this.value, 0)">
            </div>
          </div>
        </div>
        <div class="table-responsive">
          <table>
            <thead><tr><th><?= $en?'Title / Author':'Título / Autor' ?></th><th><?= $en?'Genre':'Género' ?></th><th><?= $en?'Year':'Año' ?></th><th><?= $en?'Available':'Disponibles' ?></th><th><?= $en?'Actions':'Acciones' ?></th></tr></thead>
            <tbody id="tabla-libros-body">
              <?php foreach ($libros as $l): ?>
                <tr>
                  <td><div class="libro-td-info">
                    <?php if ($l['imagen']): ?><img src="<?= e($l['imagen']) ?>" class="libro-thumb" alt="" onerror="this.style.display='none'"><?php endif; ?>
                    <div class="libro-td-text"><strong><?= e($l['titulo']) ?></strong><small><?= e($l['autor']) ?></small></div>
                  </div></td>
                  <td><span class="pill pill-blue"><?= e($l['genero']) ?></span></td>
                  <td><?= $l['anio'] ?></td>
                  <td><span class="pill <?= (int)$l['disponibles']===0?'pill-red':((int)$l['disponibles']<=2?'pill-yellow':'pill-green') ?>"><?= (int)$l['disponibles'] ?></span></td>
                  <td>
                    <div class="table-actions">
                      <a href="?tab=libros&edit=<?= e($l['id']) ?>" class="btn btn-sm btn-ghost">✏️</a>
                      <form method="POST" style="display:inline" onsubmit="return confirm('<?= $en?'Delete this book?':'¿Eliminar este libro?' ?>')">
            <?= csrf_field() ?>
                        <input type="hidden" name="action" value="del_libro">
                        <input type="hidden" name="id" value="<?= e($l['id']) ?>">
                        <button type="submit" class="btn btn-sm btn-danger">🗑</button>
                      </form>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>

    <!-- ══ RESERVAS ══ -->
    <?php elseif ($tab === 'reservas'): ?>
      <div class="admin-page-header">
        <div><h2>🔖 <?= $en?'Reservation Management':'Gestión de Reservas' ?></h2><p><?= $stats['reservas'] ?> <?= $en?'total reservations':'reservas totales' ?> · <?= $stats['pendientes'] ?> <?= $en?'pending':'pendientes' ?></p></div>
      </div>
      <div class="table-card">
        <div class="table-card-header">
          <h3><?= $en?'All reservations':'Todas las reservas' ?></h3>
          <div class="table-toolbar">
            <div class="search-box" style="min-width:200px">
              <span class="search-icon">🔍</span>
              <input type="search" id="search-reservas" placeholder="<?= $en?'Book or user...':'Libro o usuario...' ?>" oninput="filtrarTabla('tabla-reservas-body', this.value, 0)">
            </div>
            <select onchange="filtrarPorEstado(this.value)" style="font-size:13px;padding:8px 12px;border:1.5px solid #e5e7eb;border-radius:8px">
              <option value=""><?= $en?'All statuses':'Todos los estados' ?></option>
              <option value="pendiente">⏳ <?= $en?'Pending':'Pendiente' ?></option>
              <option value="lista">✅ <?= $en?'Ready':'Lista' ?></option>
              <option value="recogida">📦 <?= $en?'Picked up':'Recogida' ?></option>
              <option value="cancelada">❌ <?= $en?'Cancelled':'Cancelada' ?></option>
            </select>
          </div>
        </div>
        <div class="table-responsive">
          <table>
            <thead><tr><th><?= $en?'Book':'Libro' ?></th><th><?= $en?'User':'Usuario' ?></th><th><?= $en?'Reservation date':'Fecha Reserva' ?></th><th><?= $en?'Pick-up':'Recogida' ?></th><th><?= $en?'Code':'Código' ?></th><th><?= $en?'Status':'Estado' ?></th><th><?= $en?'Actions':'Acciones' ?></th></tr></thead>
            <tbody id="tabla-reservas-body">
              <?php foreach ($reservas as $r): ?>
                <tr>
                  <td><strong><?= e($r['titulo_libro']??'—') ?></strong><br><small style="color:#6B7280"><?= e($r['autor_libro']??'') ?></small></td>
                  <td><?= e($r['nombre_usuario'] ?? '—') ?></td>
                  <td><?= e(substr($r['fecha_reserva']??'',0,10)) ?></td>
                  <td><?= e($r['fecha_recogida']??'—') ?></td>
                  <td><code style="font-size:11px;background:#f3f4f6;padding:3px 7px;border-radius:5px;font-weight:700;color:#6B0F2A"><?= e($r['codigo_recogida']??'—') ?></code></td>
                  <td>
                    <form method="POST" style="display:inline">
            <?= csrf_field() ?>
                      <input type="hidden" name="action" value="edit_reserva">
                      <input type="hidden" name="id" value="<?= e($r['id']) ?>">
                      <select name="estado" onchange="this.form.submit()" style="font-size:12px;padding:4px 8px;border-radius:6px;border:1px solid #e5e7eb">
                        <?php foreach ($estadosList as $es): ?>
                          <option value="<?= $es ?>" <?= $r['estado']===$es?'selected':'' ?>><?= $es ?></option>
                        <?php endforeach; ?>
                      </select>
                    </form>
                  </td>
                  <td>
                    <form method="POST" style="display:inline" onsubmit="return confirm('<?= $en?'Delete reservation?':'¿Eliminar reserva?' ?>')">
            <?= csrf_field() ?>
                      <input type="hidden" name="action" value="del_reserva">
                      <input type="hidden" name="id" value="<?= e($r['id']) ?>">
                      <button type="submit" class="btn btn-sm btn-danger">🗑</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>

    <!-- ══ USUARIOS ══ -->
    <?php elseif ($tab === 'usuarios'): ?>
      <div class="admin-page-header">
        <div><h2>👥 <?= $en?'User Management':'Gestión de Usuarios' ?></h2><p><?= $stats['usuarios'] ?> <?= $en?'registered users':'usuarios registrados' ?></p></div>
        <a href="?tab=usuarios&new=1" class="btn btn-sm">➕ <?= $en?'Add user':'Agregar usuario' ?></a>
      </div>

      <?php if (isset($_GET['new']) || $userEdit): ?>
        <div class="table-card" style="margin-bottom:24px">
          <div class="table-card-header"><h3><?= $userEdit ? ($en?'Edit user':'Editar usuario') : ($en?'New user':'Nuevo usuario') ?></h3></div>
          <form method="POST" class="admin-form">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="<?= $userEdit ? 'edit_user' : 'add_user' ?>">
            <?php if ($userEdit): ?><input type="hidden" name="id" value="<?= e($userEdit['id']) ?>"><?php endif; ?>
            <div class="form-row">
              <div class="form-group"><label><?= $en?'Name':'Nombre' ?> <span class="required">*</span></label><input type="text" name="nombre" value="<?= e($userEdit['nombre']??'') ?>" required></div>
              <div class="form-group"><label>Email <span class="required">*</span></label><input type="email" name="email" value="<?= e($userEdit['email']??'') ?>" required></div>
            </div>
            <div class="form-row">
              <div class="form-group"><label><?= $en?'Phone':'Teléfono' ?></label><input type="tel" name="telefono" value="<?= e($userEdit['telefono']??'') ?>"></div>
              <div class="form-group"><label><?= $en?'Role':'Rol' ?></label>
                <select name="rol" <?= !is_superadmin()?'disabled title="Solo SUPERADMIN puede cambiar roles"':'' ?>>
                  <option value="usuario"     <?= ($userEdit['rol']??'')==='usuario'    ?'selected':'' ?>>👤 Usuario</option>
                  <option value="editor"      <?= ($userEdit['rol']??'')==='editor'     ?'selected':'' ?>>✏️ Editor</option>
                  <option value="admin"       <?= ($userEdit['rol']??'')==='admin'      ?'selected':'' ?>>🛡️ Admin</option>
                  <?php if (is_superadmin()): ?>
                  <option value="superadmin"  <?= ($userEdit['rol']??'')==='superadmin' ?'selected':'' ?>>⭐ Superadmin</option>
                  <?php endif; ?>
                </select>
                <?php if (!is_superadmin()): ?><small style="color:#888">Solo SUPERADMIN puede cambiar roles (RBAC)</small><?php endif; ?>
              </div>
            </div>
            <div class="form-group"><label><?= $en?'Password':'Contraseña' ?> <?= $userEdit ? ($en?'(leave blank to keep current)':'(dejar vacío para no cambiar)') : '<span class="required">*</span>' ?></label><input type="password" name="password" <?= $userEdit?'':'required' ?> placeholder="<?= $en?'Minimum 8 characters':'Mínimo 8 caracteres' ?>"></div>
            <div style="display:flex;gap:10px;padding:0 0 16px">
              <button type="submit" class="btn btn-sm">💾 <?= $en?'Save':'Guardar' ?></button>
              <a href="?tab=usuarios" class="btn btn-ghost btn-sm"><?= $en?'Cancel':'Cancelar' ?></a>
            </div>
          </form>
        </div>
      <?php endif; ?>

      <div class="table-card">
        <div class="table-card-header">
          <h3><?= $en?'Registered users':'Usuarios registrados' ?></h3>
          <div class="table-toolbar">
            <div class="search-box" style="min-width:220px">
              <span class="search-icon">🔍</span>
              <input type="search" placeholder="<?= $en?'Name or email...':'Nombre o correo...' ?>" oninput="filtrarTabla('tabla-usuarios-body', this.value, 0)">
            </div>
          </div>
        </div>
        <div class="table-responsive">
          <table>
            <thead><tr><th><?= $en?'Name':'Nombre' ?></th><th>Email</th><th><?= $en?'Phone':'Teléfono' ?></th><th><?= $en?'Role':'Rol' ?></th><th><?= $en?'Actions':'Acciones' ?></th></tr></thead>
            <tbody id="tabla-usuarios-body">
              <?php foreach ($usuarios as $us): ?>
                <tr>
                  <td><strong><?= e($us['nombre']) ?></strong></td>
                  <td><?= e($us['email']) ?></td>
                  <td><?= e($us['telefono']??'—') ?></td>
                  <td>
                    <?php
                      $pill_class = match($us['rol']) {
                          'superadmin' => 'pill-red',
                          'admin'      => 'pill-purple',
                          'editor'     => 'pill-orange',
                          default      => 'pill-blue',
                      };
                      $rol_icon = match($us['rol']) {
                          'superadmin' => '⭐',
                          'admin'      => '🛡️',
                          'editor'     => '✏️',
                          default      => '👤',
                      };
                    ?>
                    <span class="pill <?= $pill_class ?>"><?= $rol_icon ?> <?= e($us['rol']) ?></span>
                  </td>
                  <td>
                    <div class="table-actions">
                      <a href="?tab=usuarios&edit=<?= e($us['id']) ?>" class="btn btn-sm btn-ghost">✏️</a>
                      <?php if ($us['id'] !== $u['id']): ?>
                        <form method="POST" style="display:inline" onsubmit="return confirm('<?= $en?'Close all active sessions for '.e($us['nombre']).'? The user will be redirected to login.':'¿Cerrar todas las sesiones activas de '.e($us['nombre']).'? El usuario será redirigido al login.' ?>')">
            <?= csrf_field() ?>
                          <input type="hidden" name="action" value="revocar_sesiones_usuario">
                          <input type="hidden" name="usuario_id" value="<?= e($us['id']) ?>">
                          <button type="submit" class="btn btn-sm btn-warning" title="<?= $en?'Close active sessions':'Cerrar sesiones activas' ?>">🔒</button>
                        </form>
                        <form method="POST" style="display:inline" onsubmit="return confirm('<?= $en?'Delete this user?':'¿Eliminar este usuario?' ?>')">
            <?= csrf_field() ?>
                          <input type="hidden" name="action" value="del_user">
                          <input type="hidden" name="id" value="<?= e($us['id']) ?>">
                          <button type="submit" class="btn btn-sm btn-danger">🗑</button>
                        </form>
                      <?php endif; ?>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>

    <!-- ══ SEGURIDAD ══ -->
    <?php elseif ($tab === 'seguridad'): ?>
      <div class="form-content-header" style="border-radius:0">
        <h2>🔑 <?= $en?'Change password':'Cambiar contraseña' ?></h2>
        <p><?= $en?'Use at least 8 characters.':'Usa al menos 8 caracteres.' ?></p>
      </div>
      <div style="padding:24px;max-width:440px">
        <form method="POST"><?= csrf_field() ?>
          <input type="hidden" name="action" value="cambiar_password_admin">
          <div class="form-group"><label><?= $en?'Current password':'Contraseña actual' ?> <span class="required">*</span></label>
            <input type="password" name="password_actual" required style="width:100%;padding:10px 12px;border:1.5px solid #e5e7eb;border-radius:8px;font-size:14px">
          </div>
          <div class="form-group"><label><?= $en?'New password':'Nueva contraseña' ?> <span class="required">*</span></label>
            <input type="password" name="password_nueva" required minlength="8" style="width:100%;padding:10px 12px;border:1.5px solid #e5e7eb;border-radius:8px;font-size:14px">
          </div>
          <div class="form-group"><label><?= $en?'Confirm new password':'Confirmar nueva contraseña' ?> <span class="required">*</span></label>
            <input type="password" name="password_conf" required minlength="8" style="width:100%;padding:10px 12px;border:1.5px solid #e5e7eb;border-radius:8px;font-size:14px">
          </div>
          <button type="submit" class="btn btn-primary">🔑 <?= $en?'Update password':'Actualizar contraseña' ?></button>
        </form>
      </div>

      <div class="form-content-header" style="border-radius:0;margin-top:8px">
        <h2>💻 <?= $en?'Active sessions':'Sesiones activas' ?></h2>
        <p><?= count($_adm_sesiones) ?> <?= $en?'active session':'sesión activa' ?><?= count($_adm_sesiones)!==1?'s':'' ?>.</p>
      </div>
      <div style="padding:24px">
        <?php if (count($_adm_sesiones) > 1): ?>
        <form method="POST" style="margin-bottom:20px" onsubmit="return confirm('<?= $en?'Close all other sessions?':'¿Cerrar todas las otras sesiones?' ?>')">
          <?= csrf_field() ?><input type="hidden" name="action" value="cerrar_otras_admin">
          <button type="submit" class="btn btn-danger btn-sm">🚫 <?= $en?'Close all other sessions':'Cerrar todas las otras sesiones' ?></button>
        </form>
        <?php endif; ?>
        <?php foreach ($_adm_sesiones as $ses):
          $esActual = ($ses['id'] === $_adm_sid);
          $ua = $ses['user_agent'];
          $icon = (stripos($ua,'mobile')!==false||stripos($ua,'android')!==false)?'📱':'💻';
        ?>
        <div style="display:flex;align-items:center;gap:16px;padding:16px;border:1.5px solid <?= $esActual?'#6B0F2A':'#e5e7eb' ?>;border-radius:12px;margin-bottom:10px;background:<?= $esActual?'#fdf2f4':'#fff' ?>">
          <span style="font-size:28px"><?= $icon ?></span>
          <div style="flex:1;min-width:0">
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
              <strong style="font-size:13px"><?= $esActual?($en?'✅ This session':'✅ Esta sesión'):($en?'Another session':'Otra sesión') ?></strong>
              <?php if ($esActual): ?><span class="pill pill-green" style="font-size:11px"><?= $en?'Current':'Actual' ?></span><?php endif; ?>
            </div>
            <div style="font-size:12px;color:#6B7280;margin-top:3px">
              IP: <code><?= e($ses['ip']?:($en?'Unknown':'Desconocida')) ?></code> &bull;
              <?= $en?'Last access':'Último acceso' ?>: <?= e(date('d/m/Y H:i', strtotime($ses['last_active']))) ?><br>
              <span style="word-break:break-all"><?= e(mb_substr($ua?:($en?'Unknown agent':'Agente desconocido'),0,100)) ?></span>
            </div>
          </div>
          <?php if (!$esActual): ?>
          <form method="POST" onsubmit="return confirm('<?= $en?'Close this session?':'¿Cerrar esta sesión?' ?>')">
            <?= csrf_field() ?><input type="hidden" name="action" value="cerrar_sesion_admin">
            <input type="hidden" name="session_id" value="<?= e($ses['id']) ?>">
            <button type="submit" class="btn btn-danger btn-sm"><?= $en?'Close':'Cerrar' ?></button>
          </form>
          <?php endif; ?>
        </div>
        <?php endforeach; ?>
      </div>

    <!-- ══ PREFERENCIAS ══ -->
    <?php elseif ($tab === 'preferencias'): ?>
      <div class="admin-page-header">
        <div>
          <h2 style="font-size:22px;font-weight:800;margin-bottom:4px">⚙️ <?= $en?'Preferences':'Preferencias' ?></h2>
          <p style="color:#6B7280;font-size:14px"><?= $en?'Customize your administrator experience':'Personaliza tu experiencia como administrador' ?></p>
        </div>
      </div>

      <form method="POST" style="max-width:680px">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="preferencias">

        <!-- Apariencia -->
        <div class="card" style="margin-bottom:20px;padding:28px 32px;border-radius:16px">
          <h3 style="font-size:15px;font-weight:700;margin-bottom:4px;display:flex;align-items:center;gap:8px">
            🎨 <?= $en?'Appearance':'Apariencia' ?>
          </h3>
          <p style="font-size:13px;color:#6B7280;margin-bottom:20px"><?= $en?'Choose your visual theme':'Elige tu tema visual' ?></p>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">

            <label style="cursor:pointer">
              <input type="radio" name="tema_oscuro" value="0" <?= empty($u['tema_oscuro'])?'checked':'' ?> style="display:none" class="pref-radio">
              <div class="pref-card <?= empty($u['tema_oscuro'])?'pref-selected':'' ?>" style="border:2px solid <?= empty($u['tema_oscuro'])?'#6B0F2A':'#e5e7eb' ?>;border-radius:12px;padding:20px;text-align:center;transition:all .2s;<?= empty($u['tema_oscuro'])?'box-shadow:0 0 0 3px rgba(107,15,42,0.12)':'' ?>">
                <div style="font-size:32px;margin-bottom:10px">☀️</div>
                <div style="font-weight:700;font-size:14px;margin-bottom:4px"><?= $en?'Light mode':'Modo claro' ?></div>
                <div style="font-size:12px;color:#9CA3AF"><?= $en?'Bright & clean':'Claro y limpio' ?></div>
              </div>
            </label>

            <label style="cursor:pointer">
              <input type="radio" name="tema_oscuro" value="1" <?= !empty($u['tema_oscuro'])?'checked':'' ?> style="display:none" class="pref-radio">
              <div class="pref-card <?= !empty($u['tema_oscuro'])?'pref-selected':'' ?>" style="border:2px solid <?= !empty($u['tema_oscuro'])?'#6B0F2A':'#e5e7eb' ?>;border-radius:12px;padding:20px;text-align:center;transition:all .2s;<?= !empty($u['tema_oscuro'])?'box-shadow:0 0 0 3px rgba(107,15,42,0.12)':'' ?>">
                <div style="font-size:32px;margin-bottom:10px">🌙</div>
                <div style="font-weight:700;font-size:14px;margin-bottom:4px"><?= $en?'Dark mode':'Modo oscuro' ?></div>
                <div style="font-size:12px;color:#9CA3AF"><?= $en?'Easy on the eyes':'Reduce fatiga visual' ?></div>
              </div>
            </label>

          </div>
        </div>

        <!-- Idioma -->
        <div class="card" style="margin-bottom:28px;padding:28px 32px;border-radius:16px">
          <h3 style="font-size:15px;font-weight:700;margin-bottom:4px;display:flex;align-items:center;gap:8px">
            🌐 <?= $en?'Language':'Idioma' ?>
          </h3>
          <p style="font-size:13px;color:#6B7280;margin-bottom:20px"><?= $en?'Interface language':'Idioma de la interfaz' ?></p>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">

            <label style="cursor:pointer">
              <input type="radio" name="idioma" value="es" <?= ($u['idioma']??'es')==='es'?'checked':'' ?> style="display:none" class="pref-radio">
              <div class="pref-card <?= ($u['idioma']??'es')==='es'?'pref-selected':'' ?>" style="border:2px solid <?= ($u['idioma']??'es')==='es'?'#6B0F2A':'#e5e7eb' ?>;border-radius:12px;padding:20px;text-align:center;transition:all .2s;<?= ($u['idioma']??'es')==='es'?'box-shadow:0 0 0 3px rgba(107,15,42,0.12)':'' ?>">
                <div style="font-size:32px;margin-bottom:10px">🇲🇽</div>
                <div style="font-weight:700;font-size:14px;margin-bottom:4px">Español</div>
                <div style="font-size:12px;color:#9CA3AF">Interfaz en español</div>
              </div>
            </label>

            <label style="cursor:pointer">
              <input type="radio" name="idioma" value="en" <?= ($u['idioma']??'es')==='en'?'checked':'' ?> style="display:none" class="pref-radio">
              <div class="pref-card <?= ($u['idioma']??'es')==='en'?'pref-selected':'' ?>" style="border:2px solid <?= ($u['idioma']??'es')==='en'?'#6B0F2A':'#e5e7eb' ?>;border-radius:12px;padding:20px;text-align:center;transition:all .2s;<?= ($u['idioma']??'es')==='en'?'box-shadow:0 0 0 3px rgba(107,15,42,0.12)':'' ?>">
                <div style="font-size:32px;margin-bottom:10px">🇺🇸</div>
                <div style="font-weight:700;font-size:14px;margin-bottom:4px">English</div>
                <div style="font-size:12px;color:#9CA3AF">Interface in English</div>
              </div>
            </label>

          </div>
        </div>

        <div style="display:flex;justify-content:flex-end">
          <button type="submit" class="btn" style="padding:12px 36px;font-size:15px;font-weight:700">
            💾 <?= $en?'Save preferences':'Guardar preferencias' ?>
          </button>
        </div>
      </form>

      <script>
      (function(){
        document.querySelectorAll('.pref-radio').forEach(function(radio){
          radio.addEventListener('change', function(){
            var name = this.name;
            document.querySelectorAll('input[name="'+name+'"]').forEach(function(r){
              var card = r.closest('label').querySelector('.pref-card');
              card.style.border = '2px solid #e5e7eb';
              card.style.boxShadow = '';
            });
            var sel = this.closest('label').querySelector('.pref-card');
            sel.style.border = '2px solid #6B0F2A';
            sel.style.boxShadow = '0 0 0 3px rgba(107,15,42,0.12)';
          });
        });
      })();
      </script>

    <?php endif; ?>
  </main>
</div>

<script src="<?= url('js/animations.js') ?>"></script>
<script src="<?= url('js/carousel.js') ?>"></script>
<script>
// Hamburguesa navbar
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.menu-toggle');
  const nav    = document.querySelector('.navbar > ul');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', nav.classList.contains('open'));
    });
    document.addEventListener('click', e => {
      if (!e.target.closest('.navbar')) nav.classList.remove('open');
    });
    document.querySelectorAll('.has-submenu > a').forEach(a => {
      a.addEventListener('click', e => {
        if (window.innerWidth <= 768) { e.preventDefault(); a.parentElement.classList.toggle('open'); }
      });
    });
  }
  if (typeof BookiaAnimations !== 'undefined') BookiaAnimations.init();
});

// Filtro de búsqueda en tablas
function filtrarTabla(tbodyId, query, colIdx) {
  const q = query.toLowerCase();
  document.querySelectorAll('#' + tbodyId + ' tr').forEach(tr => {
    const texto = tr.cells[colIdx]?.textContent.toLowerCase() || '';
    tr.style.display = texto.includes(q) ? '' : 'none';
  });
}

// Filtro por estado en reservas
function filtrarPorEstado(estado) {
  document.querySelectorAll('#tabla-reservas-body tr').forEach(tr => {
    if (!estado) { tr.style.display = ''; return; }
    const estadoCell = tr.cells[5]?.textContent.toLowerCase() || '';
    tr.style.display = estadoCell.includes(estado) ? '' : 'none';
  });
}
</script>
</body>
</html>
