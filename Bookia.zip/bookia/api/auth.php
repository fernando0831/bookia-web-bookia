<?php
/**
 * BOOKIA — api/auth.php
 * Endpoints: login, registro, sesión actual, logout
 *
 * POST /api/auth.php?action=login
 * POST /api/auth.php?action=registro
 * GET  /api/auth.php?action=session
 * POST /api/auth.php?action=logout
 */

require_once __DIR__ . '/config.php';
setCorsHeaders();
session_start();

$action = $_GET['action'] ?? '';

// ── LOGIN ──────────────────────────────────────────────────
if ($action === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $body  = getBody();
    $email = trim($body['email'] ?? '');
    $pass  = $body['password'] ?? '';

    if (!$email || !$pass) {
        jsonResponse(['ok' => false, 'msg' => 'Correo y contraseña son requeridos'], 400);
    }

    $db   = getDB();
    $stmt = $db->prepare('SELECT * FROM usuarios WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($pass, $user['password_hash'])) {
        jsonResponse(['ok' => false, 'msg' => 'Credenciales incorrectas'], 401);
    }

    // Guardar sesión PHP
    $_SESSION['bookia_user'] = [
        'id'     => $user['id'],
        'nombre' => $user['nombre'],
        'email'  => $user['email'],
        'rol'    => $user['rol'],
    ];

    jsonResponse(['ok' => true, 'user' => $_SESSION['bookia_user']]);
}

// ── REGISTRO ───────────────────────────────────────────────
if ($action === 'registro' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $body     = getBody();
    $nombre   = trim($body['nombre']   ?? '');
    $email    = trim($body['email']    ?? '');
    $telefono = trim($body['telefono'] ?? '');
    $pass     = $body['password'] ?? '';

    if (!$nombre || !$email || !$pass) {
        jsonResponse(['ok' => false, 'msg' => 'Nombre, correo y contraseña son requeridos'], 400);
    }
    if (strlen($pass) < 8) {
        jsonResponse(['ok' => false, 'msg' => 'La contraseña debe tener al menos 8 caracteres'], 400);
    }

    $db = getDB();

    // Verificar email duplicado
    $check = $db->prepare('SELECT id FROM usuarios WHERE email = ? LIMIT 1');
    $check->execute([$email]);
    if ($check->fetch()) {
        jsonResponse(['ok' => false, 'msg' => 'Este correo ya está registrado'], 409);
    }

    $id   = uuid();
    $hash = password_hash($pass, PASSWORD_DEFAULT);

    $stmt = $db->prepare(
        'INSERT INTO usuarios (id, nombre, email, telefono, rol, password_hash) VALUES (?,?,?,?,?,?)'
    );
    $stmt->execute([$id, $nombre, $email, $telefono, 'usuario', $hash]);

    $user = ['id' => $id, 'nombre' => $nombre, 'email' => $email, 'rol' => 'usuario'];
    jsonResponse(['ok' => true, 'user' => $user], 201);
}

// ── SESIÓN ACTUAL ──────────────────────────────────────────
if ($action === 'session' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    if (!empty($_SESSION['bookia_user'])) {
        jsonResponse(['ok' => true, 'user' => $_SESSION['bookia_user']]);
    }
    jsonResponse(['ok' => false, 'user' => null]);
}

// ── LOGOUT ─────────────────────────────────────────────────
if ($action === 'logout' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION = [];
    session_destroy();
    jsonResponse(['ok' => true]);
}

jsonResponse(['ok' => false, 'msg' => 'Acción no reconocida'], 400);
