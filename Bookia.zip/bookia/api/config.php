<?php
/**
 * BOOKIA — api/config.php
 * Configuración de conexión a MySQL (XAMPP)
 * Ajusta DB_USER y DB_PASS si tu XAMPP tiene contraseña
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'bookia');
define('DB_USER', 'root');
define('DB_PASS', '');       // En XAMPP por defecto es vacío
define('DB_CHARSET', 'utf8mb4');

/**
 * Devuelve una conexión PDO lista para usar.
 * Lanza excepción si no puede conectar.
 */
function getDB(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $dsn = sprintf(
        'mysql:host=%s;dbname=%s;charset=%s',
        DB_HOST, DB_NAME, DB_CHARSET
    );
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
    return $pdo;
}

/**
 * Headers CORS y JSON para todos los endpoints.
 * Permite peticiones desde localhost (XAMPP).
 */
function setCorsHeaders(): void {
    header('Content-Type: application/json; charset=UTF-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

/**
 * Responde con JSON y código HTTP, luego termina.
 */
function jsonResponse(mixed $data, int $status = 200): never {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * Lee y decodifica el body JSON de la petición.
 */
function getBody(): array {
    $raw = file_get_contents('php://input');
    return json_decode($raw ?: '{}', true) ?? [];
}

/**
 * Genera un UUID v4 simple.
 */
function uuid(): string {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}

/**
 * Genera código de recogida estilo BKA-XX00-X0X
 */
function generarCodigo(): string {
    $letras = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    $nums   = '0123456789';
    $l = fn() => $letras[random_int(0, strlen($letras) - 1)];
    $n = fn() => $nums[random_int(0, 9)];
    return "BKA-{$l()}{$l()}{$n()}{$n()}-{$l()}{$n()}{$l()}";
}
