<?php
/**
 * BOOKIA — api/libros.php
 * CRUD completo de libros
 *
 * GET    /api/libros.php              → listar (soporta ?q=&genero=&sortBy=&sortDir=)
 * GET    /api/libros.php?id=X         → obtener uno
 * POST   /api/libros.php              → crear
 * PUT    /api/libros.php?id=X         → actualizar
 * DELETE /api/libros.php?id=X         → eliminar
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/../includes/jwt.php';
require_once __DIR__ . '/../includes/middleware.php';

setCorsHeaders();
aplicar_security_headers();
rate_limit('api_libros', 100, 60);

// Helper RBAC para JWT en API
function rbac_jwt(string $rol_minimo): array {
    $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (preg_match('/^Bearer\s+(.+)$/i', $auth, $m)) {
        $p = JWT::decode($m[1], JWT_SECRET);
        if ($p) {
            $j = ['usuario'=>1,'editor'=>2,'admin'=>3,'superadmin'=>4];
            if (($j[$p['rol']??'']??0) >= ($j[$rol_minimo]??999)) return $p;
            http_response_code(403);
            die(json_encode(['ok'=>false,'msg'=>"Rol requerido: $rol_minimo"]));
        }
    }
    http_response_code(401);
    die(json_encode(['ok'=>false,'msg'=>'Token JWT requerido para esta operación']));
}

$method = $_SERVER['REQUEST_METHOD'];
$id     = $_GET['id'] ?? null;
$db     = getDB();

// ── GET: listar o uno ──────────────────────────────────────
if ($method === 'GET') {
    if ($id) {
        $stmt = $db->prepare('SELECT * FROM libros WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $libro = $stmt->fetch();
        if (!$libro) jsonResponse(['ok' => false, 'msg' => 'Libro no encontrado'], 404);
        jsonResponse(['ok' => true, 'data' => mapLibro($libro)]);
    }

    // Filtros opcionales
    $q       = '%' . trim($_GET['q']      ?? '') . '%';
    $genero  = $_GET['genero']  ?? '';
    $sortBy  = in_array($_GET['sortBy']  ?? '', ['titulo','autor','anio','disponibles']) ? $_GET['sortBy'] : 'titulo';
    $sortDir = strtoupper($_GET['sortDir'] ?? '') === 'DESC' ? 'DESC' : 'ASC';

    $where  = 'WHERE (titulo LIKE ? OR autor LIKE ? OR isbn LIKE ?)';
    $params = [$q, $q, $q];

    if ($genero) {
        $where  .= ' AND genero = ?';
        $params[] = $genero;
    }

    $sql  = "SELECT * FROM libros $where ORDER BY $sortBy $sortDir";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $libros = array_map('mapLibro', $stmt->fetchAll());
    jsonResponse(['ok' => true, 'data' => $libros, 'total' => count($libros)]);
}

// ── POST: crear ────────────────────────────────────────────
if ($method === 'POST') {
    rbac_jwt('editor'); // RBAC: editor o superior
    $body = getBody();
    detectar_sql_injection($body); // Anti SQL Injection
    detectar_xss($body);           // Anti XSS
    [$titulo, $autor, $genero, $anio, $disponibles, $descripcion, $imagen, $isbn] = extraerCampos($body);

    if (!$titulo || !$autor) {
        jsonResponse(['ok' => false, 'msg' => 'Título y autor son obligatorios'], 400);
    }

    $newId = uuid();
    $stmt  = $db->prepare(
        'INSERT INTO libros (id, titulo, autor, genero, anio, disponibles, descripcion, imagen, isbn)
         VALUES (?,?,?,?,?,?,?,?,?)'
    );
    $stmt->execute([$newId, $titulo, $autor, $genero, $anio, $disponibles, $descripcion, $imagen, $isbn]);

    $libro = $db->prepare('SELECT * FROM libros WHERE id = ?');
    $libro->execute([$newId]);
    jsonResponse(['ok' => true, 'data' => mapLibro($libro->fetch())], 201);
}

// ── PUT: actualizar ────────────────────────────────────────
if ($method === 'PUT') {
    rbac_jwt('editor'); // RBAC: editor o superior
    if (!$id) jsonResponse(['ok' => false, 'msg' => 'ID requerido'], 400);
    $body = getBody();
    detectar_sql_injection($body);
    [$titulo, $autor, $genero, $anio, $disponibles, $descripcion, $imagen, $isbn] = extraerCampos($body);

    $stmt = $db->prepare(
        'UPDATE libros SET titulo=?, autor=?, genero=?, anio=?, disponibles=?,
         descripcion=?, imagen=?, isbn=? WHERE id=?'
    );
    $stmt->execute([$titulo, $autor, $genero, $anio, $disponibles, $descripcion, $imagen, $isbn, $id]);

    if ($stmt->rowCount() === 0) {
        // Puede ser que no cambió nada — verificar que existe
        $check = $db->prepare('SELECT id FROM libros WHERE id = ?');
        $check->execute([$id]);
        if (!$check->fetch()) jsonResponse(['ok' => false, 'msg' => 'Libro no encontrado'], 404);
    }

    $updated = $db->prepare('SELECT * FROM libros WHERE id = ?');
    $updated->execute([$id]);
    jsonResponse(['ok' => true, 'data' => mapLibro($updated->fetch())]);
}

// ── DELETE: eliminar ───────────────────────────────────────
if ($method === 'DELETE') {
    rbac_jwt('admin'); // RBAC: admin o superior
    if (!$id) jsonResponse(['ok' => false, 'msg' => 'ID requerido'], 400);

    $stmt = $db->prepare('DELETE FROM libros WHERE id = ?');
    $stmt->execute([$id]);

    if ($stmt->rowCount() === 0) jsonResponse(['ok' => false, 'msg' => 'Libro no encontrado'], 404);
    jsonResponse(['ok' => true, 'msg' => 'Libro eliminado']);
}

jsonResponse(['ok' => false, 'msg' => 'Método no permitido'], 405);

// ── Helpers ────────────────────────────────────────────────

/** Normaliza un row de BD al formato que espera el frontend */
function mapLibro(array $row): array {
    return [
        'id'          => $row['id'],
        'titulo'      => $row['titulo'],
        'autor'       => $row['autor'],
        'genero'      => $row['genero'],
        'anio'        => (int)$row['anio'],
        'disponibles' => (int)$row['disponibles'],
        'descripcion' => $row['descripcion'] ?? '',
        'imagen'      => $row['imagen']      ?? '',
        'isbn'        => $row['isbn']        ?? '',
        'createdAt'   => strtotime($row['created_at']) * 1000,
    ];
}

function extraerCampos(array $body): array {
    return [
        trim($body['titulo']      ?? ''),
        trim($body['autor']       ?? ''),
        trim($body['genero']      ?? 'Ficción'),
        isset($body['anio'])       ? (int)$body['anio']       : null,
        isset($body['disponibles'])? (int)$body['disponibles'] : 0,
        trim($body['descripcion'] ?? ''),
        trim($body['imagen']      ?? ''),
        trim($body['isbn']        ?? ''),
    ];
}
