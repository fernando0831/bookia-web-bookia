<?php
/**
 * BOOKIA — Microservicio 3: Auditoría y Monitoreo
 * Práctica 2 Unidad 3 — IDGS 8B
 *
 * Microservicio independiente de registro y monitoreo de seguridad.
 * Solo accesible para admin+ con JWT.
 *
 * Rutas:
 *   GET  /api/ms_auditoria.php                   → últimos 100 eventos
 *   GET  /api/ms_auditoria.php?evento=LOGIN       → filtrar por evento
 *   GET  /api/ms_auditoria.php?ip=192.168.1.1    → filtrar por IP
 *   GET  /api/ms_auditoria.php?accion=resumen     → resumen estadístico
 *   GET  /api/ms_auditoria.php?accion=alertas     → eventos críticos recientes
 *   DELETE /api/ms_auditoria.php?dias=30          → limpiar logs antiguos (superadmin)
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/jwt.php';
require_once __DIR__ . '/../includes/middleware.php';
require_once __DIR__ . '/config.php';

setCorsHeaders();
aplicar_security_headers();
rate_limit('ms_auditoria', 30, 60); // más restrictivo: 30 req/min

// ── Auth JWT ──────────────────────────────────────────────────────────────

function auth_admin_jwt(): array {
    $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!preg_match('/^Bearer\s+(.+)$/i', $auth, $m)) {
        http_response_code(401);
        die(json_encode(['ok'=>false,'msg'=>'Token JWT requerido','ms'=>'auditoria']));
    }
    $p = JWT::decode($m[1], JWT_SECRET);
    if (!$p) {
        http_response_code(401);
        die(json_encode(['ok'=>false,'msg'=>'Token inválido o expirado','ms'=>'auditoria']));
    }
    if (!in_array($p['rol'] ?? '', ['admin','superadmin'])) {
        http_response_code(403);
        die(json_encode(['ok'=>false,'msg'=>'Se requiere rol admin o superadmin','ms'=>'auditoria']));
    }
    return $p;
}

$payload = auth_admin_jwt();
$es_superadmin = ($payload['rol'] ?? '') === 'superadmin';

$method = $_SERVER['REQUEST_METHOD'];
$accion = $_GET['accion'] ?? null;
$pdo    = getDB();

// ══════════════════════════════════════════════════════════════════════════════
// EVENTOS CRÍTICOS DE SEGURIDAD (para alertas)
// ══════════════════════════════════════════════════════════════════════════════

const EVENTOS_CRITICOS = [
    'SQL_INJECTION_DETECTADO',
    'XSS_DETECTADO',
    'RATE_LIMIT_EXCEDIDO',
    'RATE_LIMIT_BLOQUEADO',
    'ACCESO_DENEGADO',
    'SESSION_UA_CAMBIO',
    'PENTEST_EJECUTADO',
    'USUARIO_ELIMINADO',
];

// ══════════════════════════════════════════════════════════════════════════════
// GET
// ══════════════════════════════════════════════════════════════════════════════

if ($method === 'GET') {

    // Resumen estadístico
    if ($accion === 'resumen') {
        $total     = $pdo->query('SELECT COUNT(*) FROM audit_log')->fetchColumn();
        $hoy       = $pdo->query("SELECT COUNT(*) FROM audit_log WHERE DATE(created_at) = CURDATE()")->fetchColumn();
        $por_evento = $pdo->query(
            'SELECT evento, COUNT(*) as total FROM audit_log GROUP BY evento ORDER BY total DESC LIMIT 15'
        )->fetchAll();
        $por_ip = $pdo->query(
            'SELECT ip, COUNT(*) as total FROM audit_log GROUP BY ip ORDER BY total DESC LIMIT 10'
        )->fetchAll();
        $criticos_hoy = $pdo->prepare(
            'SELECT COUNT(*) FROM audit_log WHERE evento IN (' .
            implode(',', array_fill(0, count(EVENTOS_CRITICOS), '?')) .
            ') AND DATE(created_at) = CURDATE()'
        );
        $criticos_hoy->execute(EVENTOS_CRITICOS);

        jsonResponse([
            'ok'   => true,
            'ms'   => 'auditoria',
            'data' => [
                'total_eventos'    => (int)$total,
                'eventos_hoy'      => (int)$hoy,
                'criticos_hoy'     => (int)$criticos_hoy->fetchColumn(),
                'por_evento'       => $por_evento,
                'top_ips'          => $por_ip,
            ],
        ]);
    }

    // Alertas — eventos críticos recientes
    if ($accion === 'alertas') {
        $placeholders = implode(',', array_fill(0, count(EVENTOS_CRITICOS), '?'));
        $s = $pdo->prepare(
            "SELECT al.*, u.nombre AS nombre_usuario, u.email AS email_usuario
             FROM audit_log al
             LEFT JOIN usuarios u ON al.usuario_id = u.id
             WHERE al.evento IN ($placeholders)
             ORDER BY al.created_at DESC LIMIT 50"
        );
        $s->execute(EVENTOS_CRITICOS);
        $alertas = $s->fetchAll();
        jsonResponse([
            'ok'    => true,
            'ms'    => 'auditoria',
            'total' => count($alertas),
            'data'  => $alertas,
        ]);
    }

    // Listar eventos (con filtros opcionales)
    $where  = '1=1';
    $params = [];

    if (!empty($_GET['evento'])) {
        $where .= ' AND al.evento = ?';
        $params[] = $_GET['evento'];
    }
    if (!empty($_GET['ip'])) {
        $where .= ' AND al.ip = ?';
        $params[] = $_GET['ip'];
    }
    if (!empty($_GET['usuario_id'])) {
        $where .= ' AND al.usuario_id = ?';
        $params[] = $_GET['usuario_id'];
    }
    if (!empty($_GET['desde'])) {
        $where .= ' AND al.created_at >= ?';
        $params[] = $_GET['desde'];
    }
    if (!empty($_GET['hasta'])) {
        $where .= ' AND al.created_at <= ?';
        $params[] = $_GET['hasta'];
    }

    $limite = min((int)($_GET['limite'] ?? 100), 500);
    $offset = max((int)($_GET['offset'] ?? 0), 0);

    $s = $pdo->prepare(
        "SELECT al.*, u.nombre AS nombre_usuario
         FROM audit_log al
         LEFT JOIN usuarios u ON al.usuario_id = u.id
         WHERE $where
         ORDER BY al.created_at DESC
         LIMIT $limite OFFSET $offset"
    );
    $s->execute($params);
    $eventos = $s->fetchAll();

    $total_s = $pdo->prepare("SELECT COUNT(*) FROM audit_log al WHERE $where");
    $total_s->execute($params);

    jsonResponse([
        'ok'    => true,
        'ms'    => 'auditoria',
        'total' => (int)$total_s->fetchColumn(),
        'data'  => $eventos,
    ]);
}

// ══════════════════════════════════════════════════════════════════════════════
// DELETE — limpiar logs antiguos (solo superadmin)
// ══════════════════════════════════════════════════════════════════════════════

if ($method === 'DELETE') {
    if (!$es_superadmin) {
        http_response_code(403);
        die(json_encode(['ok'=>false,'msg'=>'Solo SUPERADMIN puede eliminar logs','ms'=>'auditoria']));
    }
    $dias = max((int)($_GET['dias'] ?? 90), 7); // mínimo 7 días retenidos
    $s = $pdo->prepare('DELETE FROM audit_log WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)');
    $s->execute([$dias]);
    $eliminados = $s->rowCount();

    // Registrar la limpieza
    $pdo->prepare(
        'INSERT INTO audit_log (id,usuario_id,evento,detalle,ip,created_at) VALUES (?,?,?,?,?,NOW())'
    )->execute([uuid(), $payload['id'], 'AUDIT_LIMPIEZA', "Eliminados $eliminados registros > $dias días", ip_real()]);

    jsonResponse(['ok'=>true,'ms'=>'auditoria','eliminados'=>$eliminados,'dias'=>$dias]);
}

jsonResponse(['ok'=>false,'msg'=>'Método no permitido','ms'=>'auditoria'], 405);
