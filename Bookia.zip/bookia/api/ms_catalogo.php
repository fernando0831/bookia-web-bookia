<?php
/**
 * BOOKIA — Microservicio 1: Catálogo
 * Práctica 2 Unidad 3 — IDGS 8B
 *
 * Microservicio independiente para gestión del catálogo de libros.
 * Patrón: Repository + Singleton (conexión BD) + Factory (objetos Libro)
 *
 * Rutas:
 *   GET  /api/ms_catalogo.php              → listar libros (público)
 *   GET  /api/ms_catalogo.php?id=X         → detalle de libro
 *   GET  /api/ms_catalogo.php?accion=stats → estadísticas del catálogo
 *   POST /api/ms_catalogo.php              → agregar libro (requiere JWT editor+)
 *   PUT  /api/ms_catalogo.php?id=X         → editar libro  (requiere JWT editor+)
 *   DELETE /api/ms_catalogo.php?id=X       → eliminar libro (requiere JWT admin+)
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/jwt.php';
require_once __DIR__ . '/../includes/middleware.php';
require_once __DIR__ . '/config.php';

setCorsHeaders();
if (session_status() === PHP_SESSION_NONE) session_start();

// ── Aplicar security headers ─────────────────────────────────────────────
aplicar_security_headers();

// ── Rate limiting: 120 req/min por IP ──────────────────────────────────
rate_limit('ms_catalogo', 120, 60);

$method = $_SERVER['REQUEST_METHOD'];
$id     = $_GET['id']     ?? null;
$accion = $_GET['accion'] ?? null;

// ══════════════════════════════════════════════════════════════════════════════
// PATRÓN SINGLETON — Conexión a BD
// ══════════════════════════════════════════════════════════════════════════════

final class CatalogoDB {
    private static ?PDO $instancia = null;

    private function __construct() {}

    public static function obtener(): PDO {
        if (self::$instancia === null) {
            self::$instancia = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET,
                DB_USER, DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
        }
        return self::$instancia;
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// PATRÓN FACTORY — Creación de objetos Libro
// ══════════════════════════════════════════════════════════════════════════════

class LibroFactory {
    /**
     * Crea un array normalizado de libro desde un row de BD.
     */
    public static function desdeRow(array $row): array {
        return [
            'id'          => $row['id'],
            'titulo'      => $row['titulo'],
            'autor'       => $row['autor'],
            'genero'      => $row['genero'],
            'anio'        => (int)($row['anio'] ?? 0),
            'disponibles' => (int)($row['disponibles'] ?? 0),
            'descripcion' => $row['descripcion'] ?? '',
            'imagen'      => $row['imagen']      ?? '',
            'isbn'        => $row['isbn']        ?? '',
            'createdAt'   => isset($row['created_at']) ? strtotime($row['created_at']) * 1000 : null,
        ];
    }

    /**
     * Crea un libro desde datos de entrada (POST/PUT).
     */
    public static function desdeInput(array $body): array {
        return [
            'titulo'      => trim($body['titulo']      ?? ''),
            'autor'       => trim($body['autor']       ?? ''),
            'genero'      => trim($body['genero']      ?? 'Ficción'),
            'anio'        => isset($body['anio'])        ? (int)$body['anio']        : null,
            'disponibles' => isset($body['disponibles']) ? (int)$body['disponibles'] : 0,
            'descripcion' => trim($body['descripcion'] ?? ''),
            'imagen'      => trim($body['imagen']      ?? ''),
            'isbn'        => trim($body['isbn']        ?? ''),
        ];
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// PATRÓN REPOSITORY — Acceso a datos de libros
// ══════════════════════════════════════════════════════════════════════════════

class LibroRepository {
    private PDO $db;

    public function __construct() {
        $this->db = CatalogoDB::obtener();
    }

    public function buscar(string $q = '', string $genero = '', string $sortBy = 'titulo', string $sortDir = 'ASC'): array {
        $q      = '%' . $q . '%';
        $where  = 'WHERE (titulo LIKE ? OR autor LIKE ? OR isbn LIKE ?)';
        $params = [$q, $q, $q];
        if ($genero) { $where .= ' AND genero = ?'; $params[] = $genero; }
        $sortBy  = in_array($sortBy, ['titulo','autor','anio','disponibles']) ? $sortBy : 'titulo';
        $sortDir = $sortDir === 'DESC' ? 'DESC' : 'ASC';
        $stmt = $this->db->prepare("SELECT * FROM libros $where ORDER BY $sortBy $sortDir");
        $stmt->execute($params);
        return array_map([LibroFactory::class, 'desdeRow'], $stmt->fetchAll());
    }

    public function porId(string $id): ?array {
        $s = $this->db->prepare('SELECT * FROM libros WHERE id = ? LIMIT 1');
        $s->execute([$id]);
        $r = $s->fetch();
        return $r ? LibroFactory::desdeRow($r) : null;
    }

    public function crear(array $datos): array {
        $id = uuid();
        $this->db->prepare(
            'INSERT INTO libros (id,titulo,autor,genero,anio,disponibles,descripcion,imagen,isbn) VALUES(?,?,?,?,?,?,?,?,?)'
        )->execute([$id, $datos['titulo'], $datos['autor'], $datos['genero'], $datos['anio'],
                    $datos['disponibles'], $datos['descripcion'], $datos['imagen'], $datos['isbn']]);
        return $this->porId($id);
    }

    public function actualizar(string $id, array $datos): ?array {
        $this->db->prepare(
            'UPDATE libros SET titulo=?,autor=?,genero=?,anio=?,disponibles=?,descripcion=?,imagen=?,isbn=? WHERE id=?'
        )->execute([$datos['titulo'], $datos['autor'], $datos['genero'], $datos['anio'],
                    $datos['disponibles'], $datos['descripcion'], $datos['imagen'], $datos['isbn'], $id]);
        return $this->porId($id);
    }

    public function eliminar(string $id): bool {
        $s = $this->db->prepare('DELETE FROM libros WHERE id = ?');
        $s->execute([$id]);
        return $s->rowCount() > 0;
    }

    public function estadisticas(): array {
        $total    = $this->db->query('SELECT COUNT(*) FROM libros')->fetchColumn();
        $generos  = $this->db->query('SELECT genero, COUNT(*) as total FROM libros GROUP BY genero ORDER BY total DESC')->fetchAll();
        $disp     = $this->db->query('SELECT SUM(disponibles) FROM libros')->fetchColumn();
        $reciente = $this->db->query('SELECT titulo, autor FROM libros ORDER BY created_at DESC LIMIT 5')->fetchAll();
        return [
            'total_libros'      => (int)$total,
            'total_disponibles' => (int)$disp,
            'por_genero'        => $generos,
            'recientes'         => $reciente,
        ];
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// AUTENTICACIÓN JWT PARA OPERACIONES PROTEGIDAS
// ══════════════════════════════════════════════════════════════════════════════

function payload_jwt(): ?array {
    $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!preg_match('/^Bearer\s+(.+)$/i', $auth, $m)) return null;
    return JWT::decode($m[1], JWT_SECRET);
}

function require_jwt_rol(string $rol_minimo): array {
    $payload = payload_jwt();
    if (!$payload) {
        http_response_code(401);
        die(json_encode(['ok' => false, 'msg' => 'Token JWT requerido', 'ms' => 'catalogo']));
    }
    $jerarquia = ['usuario'=>1,'editor'=>2,'admin'=>3,'superadmin'=>4];
    $nivel_payload = $jerarquia[$payload['rol'] ?? ''] ?? 0;
    $nivel_minimo  = $jerarquia[$rol_minimo]           ?? 999;
    if ($nivel_payload < $nivel_minimo) {
        http_response_code(403);
        die(json_encode(['ok' => false, 'msg' => "Rol requerido: $rol_minimo. Tu rol: {$payload['rol']}", 'ms' => 'catalogo']));
    }
    return $payload;
}

// ══════════════════════════════════════════════════════════════════════════════
// ROUTER
// ══════════════════════════════════════════════════════════════════════════════

$repo = new LibroRepository();

// GET — listar / detalle / estadísticas (público)
if ($method === 'GET') {
    if ($accion === 'stats') {
        jsonResponse(['ok' => true, 'data' => $repo->estadisticas(), 'ms' => 'catalogo']);
    }
    if ($id) {
        $libro = $repo->porId($id);
        if (!$libro) jsonResponse(['ok' => false, 'msg' => 'Libro no encontrado', 'ms' => 'catalogo'], 404);
        jsonResponse(['ok' => true, 'data' => $libro, 'ms' => 'catalogo']);
    }
    $libros = $repo->buscar(
        trim($_GET['q'] ?? ''),
        $_GET['genero'] ?? '',
        $_GET['sortBy']  ?? 'titulo',
        $_GET['sortDir'] ?? 'ASC'
    );
    jsonResponse(['ok' => true, 'data' => $libros, 'total' => count($libros), 'ms' => 'catalogo']);
}

// POST — crear (editor+)
if ($method === 'POST') {
    require_jwt_rol('editor');
    $datos = LibroFactory::desdeInput(getBody());
    detectar_sql_injection($datos);
    detectar_xss($datos);
    if (!$datos['titulo'] || !$datos['autor']) {
        jsonResponse(['ok' => false, 'msg' => 'Título y autor son obligatorios', 'ms' => 'catalogo'], 400);
    }
    $libro = $repo->crear($datos);
    jsonResponse(['ok' => true, 'data' => $libro, 'ms' => 'catalogo'], 201);
}

// PUT — actualizar (editor+)
if ($method === 'PUT') {
    require_jwt_rol('editor');
    if (!$id) jsonResponse(['ok' => false, 'msg' => 'ID requerido', 'ms' => 'catalogo'], 400);
    $datos = LibroFactory::desdeInput(getBody());
    detectar_sql_injection($datos);
    $libro = $repo->actualizar($id, $datos);
    if (!$libro) jsonResponse(['ok' => false, 'msg' => 'Libro no encontrado', 'ms' => 'catalogo'], 404);
    jsonResponse(['ok' => true, 'data' => $libro, 'ms' => 'catalogo']);
}

// DELETE — eliminar (admin+)
if ($method === 'DELETE') {
    require_jwt_rol('admin');
    if (!$id) jsonResponse(['ok' => false, 'msg' => 'ID requerido', 'ms' => 'catalogo'], 400);
    $ok = $repo->eliminar($id);
    if (!$ok) jsonResponse(['ok' => false, 'msg' => 'Libro no encontrado', 'ms' => 'catalogo'], 404);
    jsonResponse(['ok' => true, 'msg' => 'Libro eliminado', 'ms' => 'catalogo']);
}

jsonResponse(['ok' => false, 'msg' => 'Método no permitido', 'ms' => 'catalogo'], 405);
