<?php
/**
 * BOOKIA — Microservicio 2: Reservas
 * Práctica 2 Unidad 3 — IDGS 8B
 *
 * Microservicio independiente para gestión de reservas.
 * Patrón: MVC (Controller separado) + Repository + ABAC
 *
 * Rutas:
 *   GET  /api/ms_reservas.php              → mis reservas (JWT usuario)
 *   GET  /api/ms_reservas.php?todas=1      → todas las reservas (JWT admin+)
 *   GET  /api/ms_reservas.php?id=X         → una reserva (ABAC: propia o admin)
 *   POST /api/ms_reservas.php              → crear reserva (JWT usuario)
 *   PUT  /api/ms_reservas.php?id=X         → cambiar estado (JWT admin+)
 *   DELETE /api/ms_reservas.php?id=X       → cancelar (ABAC: propia o admin)
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/jwt.php';
require_once __DIR__ . '/../includes/middleware.php';
require_once __DIR__ . '/config.php';

setCorsHeaders();
aplicar_security_headers();
rate_limit('ms_reservas', 60, 60);

$method = $_SERVER['REQUEST_METHOD'];
$id     = $_GET['id']    ?? null;
$todas  = !empty($_GET['todas']);

// ══════════════════════════════════════════════════════════════════════════════
// AUTENTICACIÓN JWT (requerida en todos los endpoints)
// ══════════════════════════════════════════════════════════════════════════════

function obtener_payload(): array {
    $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!preg_match('/^Bearer\s+(.+)$/i', $auth, $m)) {
        http_response_code(401);
        die(json_encode(['ok' => false, 'msg' => 'Autenticación requerida', 'ms' => 'reservas']));
    }
    $p = JWT::decode($m[1], JWT_SECRET);
    if (!$p) {
        http_response_code(401);
        die(json_encode(['ok' => false, 'msg' => 'Token inválido o expirado', 'ms' => 'reservas']));
    }
    return $p;
}

function es_admin_jwt(array $p): bool {
    return in_array($p['rol'] ?? '', ['admin', 'superadmin']);
}

// ══════════════════════════════════════════════════════════════════════════════
// PATRÓN REPOSITORY — Acceso a datos de reservas
// ══════════════════════════════════════════════════════════════════════════════

class ReservasRepository {
    private PDO $db;

    public function __construct() {
        $this->db = getDB();
    }

    public function porUsuario(string $uid): array {
        $s = $this->db->prepare(
            'SELECT r.*, l.imagen FROM reservas r
             LEFT JOIN libros l ON r.libro_id = l.id
             WHERE r.usuario_id = ? ORDER BY r.created_at DESC'
        );
        $s->execute([$uid]);
        return array_map([$this, 'mapear'], $s->fetchAll());
    }

    public function todas(): array {
        $s = $this->db->query(
            'SELECT r.*, u.nombre AS nombre_usuario, u.email AS email_usuario, l.imagen
             FROM reservas r
             LEFT JOIN usuarios u ON r.usuario_id = u.id
             LEFT JOIN libros l ON r.libro_id = l.id
             ORDER BY r.created_at DESC'
        );
        return array_map([$this, 'mapear'], $s->fetchAll());
    }

    public function porId(string $id): ?array {
        $s = $this->db->prepare('SELECT r.*, u.nombre AS nombre_usuario FROM reservas r LEFT JOIN usuarios u ON r.usuario_id=u.id WHERE r.id=? LIMIT 1');
        $s->execute([$id]);
        $r = $s->fetch();
        return $r ? $this->mapear($r) : null;
    }

    public function crear(array $datos, string $uid): array {
        $id     = uuid();
        $codigo = generarCodigo();
        $this->db->prepare(
            'INSERT INTO reservas (id,usuario_id,libro_id,titulo_libro,autor_libro,fecha_recogida,notas,codigo_recogida)
             VALUES (?,?,?,?,?,?,?,?)'
        )->execute([$id, $uid, $datos['libro_id'], $datos['titulo_libro'], $datos['autor_libro'],
                    $datos['fecha_recogida'] ?? null, $datos['notas'] ?? '', $codigo]);

        // Descontar disponibles
        $this->db->prepare('UPDATE libros SET disponibles = disponibles - 1 WHERE id = ? AND disponibles > 0')
                 ->execute([$datos['libro_id']]);

        return $this->porId($id);
    }

    public function cambiarEstado(string $id, string $estado): ?array {
        $estados = ['pendiente','lista','recogida','cancelada'];
        if (!in_array($estado, $estados)) return null;
        $this->db->prepare('UPDATE reservas SET estado=? WHERE id=?')->execute([$estado, $id]);
        return $this->porId($id);
    }

    public function cancelar(string $id): bool {
        // Devolver disponibilidad al libro
        $r = $this->porId($id);
        if (!$r) return false;
        $this->db->prepare('UPDATE libros SET disponibles = disponibles + 1 WHERE id = ?')
                 ->execute([$r['libro_id']]);
        $this->db->prepare('UPDATE reservas SET estado=\'cancelada\' WHERE id=?')->execute([$id]);
        return true;
    }

    private function mapear(array $row): array {
        return [
            'id'             => $row['id'],
            'usuario_id'     => $row['usuario_id'],
            'nombre_usuario' => $row['nombre_usuario'] ?? null,
            'email_usuario'  => $row['email_usuario']  ?? null,
            'libro_id'       => $row['libro_id'],
            'titulo_libro'   => $row['titulo_libro'],
            'autor_libro'    => $row['autor_libro'],
            'imagen'         => $row['imagen'] ?? '',
            'fecha_reserva'  => $row['fecha_reserva'],
            'fecha_recogida' => $row['fecha_recogida'] ?? null,
            'estado'         => $row['estado'],
            'notas'          => $row['notas'] ?? '',
            'codigo_recogida'=> $row['codigo_recogida'],
            'createdAt'      => strtotime($row['created_at']) * 1000,
        ];
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// ROUTER (patrón MVC: Controller)
// ══════════════════════════════════════════════════════════════════════════════

$repo    = new ReservasRepository();
$payload = obtener_payload();
$uid     = $payload['id'];
$es_admin = es_admin_jwt($payload);

// GET
if ($method === 'GET') {
    if ($id) {
        $reserva = $repo->porId($id);
        if (!$reserva) jsonResponse(['ok'=>false,'msg'=>'Reserva no encontrada','ms'=>'reservas'], 404);
        // ABAC: solo el dueño o admin puede ver
        if (!$es_admin && $reserva['usuario_id'] !== $uid) {
            http_response_code(403);
            die(json_encode(['ok'=>false,'msg'=>'Solo puedes ver tus propias reservas (ABAC)','ms'=>'reservas']));
        }
        jsonResponse(['ok'=>true,'data'=>$reserva,'ms'=>'reservas']);
    }
    if ($todas && $es_admin) {
        $lista = $repo->todas();
    } else {
        $lista = $repo->porUsuario($uid);
    }
    jsonResponse(['ok'=>true,'data'=>$lista,'total'=>count($lista),'ms'=>'reservas']);
}

// POST — crear reserva
if ($method === 'POST') {
    $body = getBody();
    detectar_sql_injection($body);
    $required = ['libro_id','titulo_libro','autor_libro'];
    foreach ($required as $campo) {
        if (empty($body[$campo])) {
            jsonResponse(['ok'=>false,'msg'=>"Campo requerido: $campo",'ms'=>'reservas'], 400);
        }
    }
    $reserva = $repo->crear($body, $uid);
    jsonResponse(['ok'=>true,'data'=>$reserva,'ms'=>'reservas'], 201);
}

// PUT — cambiar estado (admin+)
if ($method === 'PUT') {
    if (!$es_admin) {
        http_response_code(403);
        die(json_encode(['ok'=>false,'msg'=>'Solo admin puede cambiar estados','ms'=>'reservas']));
    }
    if (!$id) jsonResponse(['ok'=>false,'msg'=>'ID requerido','ms'=>'reservas'], 400);
    $body  = getBody();
    $estado = $body['estado'] ?? '';
    $reserva = $repo->cambiarEstado($id, $estado);
    if (!$reserva) jsonResponse(['ok'=>false,'msg'=>'Estado inválido o reserva no encontrada','ms'=>'reservas'], 400);
    jsonResponse(['ok'=>true,'data'=>$reserva,'ms'=>'reservas']);
}

// DELETE — cancelar (ABAC: propia o admin)
if ($method === 'DELETE') {
    if (!$id) jsonResponse(['ok'=>false,'msg'=>'ID requerido','ms'=>'reservas'], 400);
    $reserva = $repo->porId($id);
    if (!$reserva) jsonResponse(['ok'=>false,'msg'=>'Reserva no encontrada','ms'=>'reservas'], 404);
    // ABAC
    if (!$es_admin && $reserva['usuario_id'] !== $uid) {
        http_response_code(403);
        die(json_encode(['ok'=>false,'msg'=>'Solo puedes cancelar tus propias reservas (ABAC)','ms'=>'reservas']));
    }
    $repo->cancelar($id);
    jsonResponse(['ok'=>true,'msg'=>'Reserva cancelada','ms'=>'reservas']);
}

jsonResponse(['ok'=>false,'msg'=>'Método no permitido','ms'=>'reservas'], 405);
