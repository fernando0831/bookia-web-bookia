<?php
/**
 * BOOKIA — api/reservas.php
 * CRUD de reservas + acciones especiales
 *
 * GET    /api/reservas.php                    → listar (admin) o propias si ?usuario_id=
 * GET    /api/reservas.php?id=X               → obtener una
 * POST   /api/reservas.php                    → crear reserva
 * PUT    /api/reservas.php?id=X               → actualizar estado/fecha/notas
 * DELETE /api/reservas.php?id=X               → eliminar
 */

require_once __DIR__ . '/config.php';
setCorsHeaders();

$method = $_SERVER['REQUEST_METHOD'];
$id     = $_GET['id'] ?? null;
$db     = getDB();

// ── GET ────────────────────────────────────────────────────
if ($method === 'GET') {
    if ($id) {
        $stmt = $db->prepare('SELECT * FROM reservas WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $r = $stmt->fetch();
        if (!$r) jsonResponse(['ok' => false, 'msg' => 'Reserva no encontrada'], 404);
        jsonResponse(['ok' => true, 'data' => mapReserva($r)]);
    }

    $q          = '%' . trim($_GET['q']     ?? '') . '%';
    $estado     = $_GET['estado']      ?? '';
    $usuarioId  = $_GET['usuario_id']  ?? '';
    $sortBy     = in_array($_GET['sortBy'] ?? '', ['fecha_reserva','fecha_recogida','estado']) ? $_GET['sortBy'] : 'fecha_reserva';
    $sortDir    = strtoupper($_GET['sortDir'] ?? '') === 'ASC' ? 'ASC' : 'DESC';

    $where  = 'WHERE (titulo_libro LIKE ? OR autor_libro LIKE ?)';
    $params = [$q, $q];

    if ($estado)    { $where .= ' AND estado = ?';      $params[] = $estado; }
    if ($usuarioId) { $where .= ' AND usuario_id = ?';  $params[] = $usuarioId; }

    $stmt = $db->prepare("SELECT * FROM reservas $where ORDER BY $sortBy $sortDir");
    $stmt->execute($params);
    $lista = array_map('mapReserva', $stmt->fetchAll());
    jsonResponse(['ok' => true, 'data' => $lista, 'total' => count($lista)]);
}

// ── POST: crear ────────────────────────────────────────────
if ($method === 'POST') {
    $body       = getBody();
    $usuarioId  = trim($body['usuarioId']    ?? '');
    $libroId    = trim($body['libroId']      ?? '');
    $fecha      = trim($body['fechaRecogida']?? '');
    $notas      = trim($body['notas']        ?? '');

    if (!$usuarioId || !$libroId) {
        jsonResponse(['ok' => false, 'msg' => 'usuarioId y libroId son requeridos'], 400);
    }

    // Verificar libro existe y tiene disponibles
    $lStmt = $db->prepare('SELECT * FROM libros WHERE id = ? LIMIT 1');
    $lStmt->execute([$libroId]);
    $libro = $lStmt->fetch();
    if (!$libro) jsonResponse(['ok' => false, 'msg' => 'Libro no encontrado'], 404);
    if ((int)$libro['disponibles'] <= 0) jsonResponse(['ok' => false, 'msg' => 'Libro sin disponibilidad'], 409);

    // Verificar que no tenga ya este libro activo
    $dupStmt = $db->prepare(
        "SELECT id FROM reservas WHERE usuario_id=? AND libro_id=? AND estado IN ('pendiente','lista') LIMIT 1"
    );
    $dupStmt->execute([$usuarioId, $libroId]);
    if ($dupStmt->fetch()) jsonResponse(['ok' => false, 'msg' => 'Ya tienes este libro reservado'], 409);

    // Si no viene fecha, poner mañana
    if (!$fecha) {
        $fecha = date('Y-m-d', strtotime('+1 day'));
    }

    $newId  = uuid();
    $codigo = generarCodigo();

    // Transacción: insertar reserva + decrementar disponibles
    $db->beginTransaction();
    try {
        $ins = $db->prepare(
            'INSERT INTO reservas (id, usuario_id, libro_id, titulo_libro, autor_libro, fecha_recogida, estado, notas, codigo_recogida)
             VALUES (?,?,?,?,?,?,?,?,?)'
        );
        $ins->execute([$newId, $usuarioId, $libroId, $libro['titulo'], $libro['autor'], $fecha, 'pendiente', $notas, $codigo]);

        $db->prepare('UPDATE libros SET disponibles = disponibles - 1 WHERE id = ?')->execute([$libroId]);
        $db->commit();
    } catch (Exception $e) {
        $db->rollBack();
        jsonResponse(['ok' => false, 'msg' => 'Error al crear reserva: ' . $e->getMessage()], 500);
    }

    $r = $db->prepare('SELECT * FROM reservas WHERE id = ?');
    $r->execute([$newId]);
    jsonResponse(['ok' => true, 'data' => mapReserva($r->fetch())], 201);
}

// ── PUT: actualizar ────────────────────────────────────────
if ($method === 'PUT') {
    if (!$id) jsonResponse(['ok' => false, 'msg' => 'ID requerido'], 400);
    $body = getBody();

    // Obtener estado anterior para ajustar disponibles si cancela
    $prevStmt = $db->prepare('SELECT * FROM reservas WHERE id = ? LIMIT 1');
    $prevStmt->execute([$id]);
    $prev = $prevStmt->fetch();
    if (!$prev) jsonResponse(['ok' => false, 'msg' => 'Reserva no encontrada'], 404);

    $nuevoEstado  = $body['estado']        ?? $prev['estado'];
    $fechaRecog   = $body['fechaRecogida'] ?? $prev['fecha_recogida'];
    $notas        = $body['notas']         ?? $prev['notas'];

    $estadosValidos = ['pendiente','lista','recogida','cancelada'];
    if (!in_array($nuevoEstado, $estadosValidos)) {
        jsonResponse(['ok' => false, 'msg' => 'Estado inválido'], 400);
    }

    $db->beginTransaction();
    try {
        $upd = $db->prepare('UPDATE reservas SET estado=?, fecha_recogida=?, notas=? WHERE id=?');
        $upd->execute([$nuevoEstado, $fechaRecog, $notas, $id]);

        // Si se cancela desde estado activo → devolver disponible al libro
        $activosAnteriores = ['pendiente', 'lista'];
        if ($nuevoEstado === 'cancelada' && in_array($prev['estado'], $activosAnteriores)) {
            $db->prepare('UPDATE libros SET disponibles = disponibles + 1 WHERE id = ?')
               ->execute([$prev['libro_id']]);
        }

        $db->commit();
    } catch (Exception $e) {
        $db->rollBack();
        jsonResponse(['ok' => false, 'msg' => 'Error al actualizar: ' . $e->getMessage()], 500);
    }

    $updated = $db->prepare('SELECT * FROM reservas WHERE id = ?');
    $updated->execute([$id]);
    jsonResponse(['ok' => true, 'data' => mapReserva($updated->fetch())]);
}

// ── DELETE ─────────────────────────────────────────────────
if ($method === 'DELETE') {
    if (!$id) jsonResponse(['ok' => false, 'msg' => 'ID requerido'], 400);

    $stmt = $db->prepare('DELETE FROM reservas WHERE id = ?');
    $stmt->execute([$id]);
    if ($stmt->rowCount() === 0) jsonResponse(['ok' => false, 'msg' => 'Reserva no encontrada'], 404);
    jsonResponse(['ok' => true, 'msg' => 'Reserva eliminada']);
}

jsonResponse(['ok' => false, 'msg' => 'Método no permitido'], 405);

// ── Helper ─────────────────────────────────────────────────
function mapReserva(array $row): array {
    return [
        'id'             => $row['id'],
        'usuarioId'      => $row['usuario_id'],
        'libroId'        => $row['libro_id'],
        'tituloLibro'    => $row['titulo_libro'],
        'autorLibro'     => $row['autor_libro'],
        'fechaReserva'   => $row['fecha_reserva'],
        'fechaRecogida'  => $row['fecha_recogida'] ?? '',
        'estado'         => $row['estado'],
        'notas'          => $row['notas'] ?? '',
        'codigoRecogida' => $row['codigo_recogida'],
        'createdAt'      => strtotime($row['created_at']) * 1000,
    ];
}
