<?php
/**
 * BOOKIA — api/tokens.php
 * POST ?action=login      → access_token + refresh_token
 * POST ?action=refresh    → nuevo access_token
 * GET  ?action=verify     → verifica Bearer token
 * POST ?action=revoke     → revoca refresh (anti token-replay)
 * POST ?action=mfa_send   → genera/envía OTP
 * POST ?action=mfa_verify → valida OTP
 */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../api/config.php';
require_once __DIR__ . '/../includes/auth.php';

setCorsHeaders();
if (session_status() === PHP_SESSION_NONE) session_start();
$action = $_GET['action'] ?? '';

if ($action === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $b = getBody(); $email = trim($b['email']??''); $pass = $b['password']??'';
    if (!$email||!$pass) jsonResponse(['ok'=>false,'msg'=>'email y password requeridos'],400);
    $pdo = getDB();
    if (cuenta_bloqueada($pdo,$email)) jsonResponse(['ok'=>false,'msg'=>'Cuenta bloqueada '.BLOQUEO_MIN.' min.'],429);
    $s = $pdo->prepare('SELECT * FROM usuarios WHERE email=? LIMIT 1');
    $s->execute([$email]); $user = $s->fetch();
    if (!$user||!password_verify($pass,$user['password_hash'])) {
        registrar_intento_fallido($pdo,$email);
        jsonResponse(['ok'=>false,'msg'=>'Credenciales incorrectas'],401);
    }
    resetear_intentos($pdo,$user['id']);
    session_regenerate_id(true);
    registrar_sesion($pdo,$user['id']);
    $tokens = emitir_tokens($pdo,$user);
    jsonResponse(['ok'=>true,'user'=>['id'=>$user['id'],'nombre'=>$user['nombre'],'rol'=>$user['rol']]] + $tokens);
}

if ($action === 'refresh' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $b = getBody(); $rt = $b['refresh_token']??'';
    if (!$rt) jsonResponse(['ok'=>false,'msg'=>'refresh_token requerido'],400);
    $pdo = getDB(); $result = renovar_access_token($pdo,$rt);
    if (!$result) jsonResponse(['ok'=>false,'msg'=>'Token inválido, expirado o revocado'],401);
    jsonResponse(['ok'=>true]+$result);
}

if ($action === 'verify' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $payload = bearer_payload();
    if (!$payload) jsonResponse(['ok'=>false,'msg'=>'Token inválido o expirado'],401);
    jsonResponse(['ok'=>true,'payload'=>$payload]);
}

if ($action === 'revoke' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $b = getBody(); $rt = $b['refresh_token']??'';
    $pdo = getDB();
    if ($rt) { $hash = hash('sha256',$rt); $pdo->prepare('UPDATE refresh_tokens SET revocado=1 WHERE token_hash=?')->execute([$hash]); }
    $payload = bearer_payload();
    if ($payload) $pdo->prepare('UPDATE refresh_tokens SET revocado=1 WHERE session_id=?')->execute([$payload['sid']??'']);
    jsonResponse(['ok'=>true,'msg'=>'Token(s) revocado(s). Anti token-replay activo.']);
}

if ($action === 'mfa_send' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $b = getBody(); $uid = $b['usuario_id']??'';
    $tipo = in_array($b['tipo']??'',['email','sms','voz'])?$b['tipo']:'email';
    if (!$uid) jsonResponse(['ok'=>false,'msg'=>'usuario_id requerido'],400);
    $pdo = getDB(); $s = $pdo->prepare('SELECT * FROM usuarios WHERE id=? LIMIT 1');
    $s->execute([$uid]); $user = $s->fetch();
    if (!$user) jsonResponse(['ok'=>false,'msg'=>'Usuario no encontrado'],404);
    $codigo = generar_otp($pdo,$uid,$tipo);
    if ($tipo==='email') Mailer::enviar($user['email'],'Código MFA — Bookia',Mailer::htmlMFA($user['nombre'],$codigo));
    elseif ($tipo==='sms') Mailer::sms($user['telefono']??'N/A',"Tu código Bookia: $codigo");
    else Mailer::llamada($user['telefono']??'N/A',$codigo);
    jsonResponse(['ok'=>true,'msg'=>"OTP enviado por $tipo",'codigo_demo'=>$codigo]);
}

if ($action === 'mfa_verify' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $b = getBody(); $uid = $b['usuario_id']??''; $codigo = $b['codigo']??'';
    $tipo = in_array($b['tipo']??'',['email','sms','voz'])?$b['tipo']:'email';
    if (!$uid||!$codigo) jsonResponse(['ok'=>false,'msg'=>'usuario_id y codigo requeridos'],400);
    $pdo = getDB();
    if (validar_otp($pdo,$uid,$codigo,$tipo)) jsonResponse(['ok'=>true,'msg'=>'OTP válido']);
    else jsonResponse(['ok'=>false,'msg'=>'OTP incorrecto o expirado'],401);
}

jsonResponse(['ok'=>false,'msg'=>'Acción no reconocida'],400);
