<?php
/**
 * BOOKIA — api/usuarios.php
 * CRUD de usuarios (solo admins excepto perfil propio)
 *
 * GET    /api/usuarios.php            → listar (admin)
 * GET    /api/usuarios.php?id=X       → obtener uno
 * POST   /api/usuarios.php            → crear (admin)
 * PUT    /api/usuarios.php?id=X       → actualizar
 * DELETE /api/usuarios.php?id=X       → eliminar (admin)
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/../includes/jwt.php';
require_once __DIR__ . '/../includes/middleware.php';

setCorsHeaders();
aplicar_security_headers();
rate_limit('api_usuarios', 50, 60);
session_start();

// RBAC para API de usuarios
function require_admin_jwt(): array {
    $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (preg_match('/^Bearer\s+(.+)$/i', $auth, $m)) {
        $p = JWT::decode($m[1], JWT_SECRET);
        if ($p && in_array($p['rol'] ?? '', ['admin','superadmin'])) return $p;
        if ($p) { http_response_code(403); die(json_encode(['ok'=>false,'msg'=>'Se requiere rol admin'])); }
    }
    http_response_code(401);
    die(json_encode(['ok'=>false,'msg'=>'Token JWT de admin requerido']));
}

$method = $_SERVER['REQUEST_METHOD'];
$id     = $_GET['id'] ?? null;
$db     = getDB();

// ── GET: listar o uno ──────────────────────────────────────
if ($method === 'GET') {
    if ($id) {
        $stmt = $db->prepare('SELECT * FROM usuarios WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $u = $stmt->fetch();
        if (!$u) jsonResponse(['ok' => false, 'msg' => 'Usuario no encontrado'], 404);
        jsonResponse(['ok' => true, 'data' => mapUsuario($u)]);
    }

    $q   = '%' . trim($_GET['q']   ?? '') . '%';
    $rol = $_GET['rol'] ?? '';

    $where  = 'WHERE (nombre LIKE ? OR email LIKE ?)';
    $params = [$q, $q];
    if ($rol) { $where .= ' AND rol = ?'; $params[] = $rol; }

    $stmt = $db->prepare("SELECT * FROM usuarios $where ORDER BY nombre ASC");
    $stmt->execute($params);
    $lista = array_map('mapUsuario', $stmt->fetchAll());
    jsonResponse(['ok' => true, 'data' => $lista, 'total' => count($lista)]);
}

// ── POST: crear ────────────────────────────────────────────
if ($method === 'POST') {
    $admin_payload = require_admin_jwt(); // RBAC: solo admin+
    $body     = getBody();
    detectar_sql_injection($body);
    detectar_xss($body);
    // Solo superadmin puede crear admins
    if (in_array($body['rol']??'', ['admin','superadmin']) && ($admin_payload['rol']??'') !== 'superadmin') {
        jsonResponse(['ok'=>false,'msg'=>'Solo SUPERADMIN puede crear admins'], 403);
    }
    $nombre   = trim($body['nombre']   ?? '');
    $email    = trim($body['email']    ?? '');
    $telefono = trim($body['telefono'] ?? '');
    $rol      = in_array($body['rol'] ?? '', ['admin','usuario']) ? $body['rol'] : 'usuario';
    $pass     = $body['password'] ?? '';

    if (!$nombre || !$email || !$pass) {
        jsonResponse(['ok' => false, 'msg' => 'Nombre, correo y contraseña son requeridos'], 400);
    }

    $check = $db->prepare('SELECT id FROM usuarios WHERE email = ?');
    $check->execute([$email]);
    if ($check->fetch()) jsonResponse(['ok' => false, 'msg' => 'Correo ya registrado'], 409);

    $newId = uuid();
    $hash  = password_hash($pass, PASSWORD_DEFAULT);
    $stmt  = $db->prepare(
        'INSERT INTO usuarios (id, nombre, email, telefono, rol, password_hash) VALUES (?,?,?,?,?,?)'
    );
    $stmt->execute([$newId, $nombre, $email, $telefono, $rol, $hash]);

    $u = $db->prepare('SELECT * FROM usuarios WHERE id = ?');
    $u->execute([$newId]);
    jsonResponse(['ok' => true, 'data' => mapUsuario($u->fetch())], 201);
}

// ── PUT: actualizar ────────────────────────────────────────
if ($method === 'PUT') {
    if (!$id) jsonResponse(['ok' => false, 'msg' => 'ID requerido'], 400);
    $body     = getBody();
    $nombre   = trim($body['nombre']   ?? '');
    $telefono = trim($body['telefono'] ?? '');
    $rol      = in_array($body['rol'] ?? '', ['admin','usuario']) ? $body['rol'] : null;

    // Actualizar campos base
    if ($rol) {
        $stmt = $db->prepare('UPDATE usuarios SET nombre=?, telefono=?, rol=? WHERE id=?');
        $stmt->execute([$nombre, $telefono, $rol, $id]);
    } else {
        $stmt = $db->prepare('UPDATE usuarios SET nombre=?, telefono=? WHERE id=?');
        $stmt->execute([$nombre, $telefono, $id]);
    }

    // Actualizar contraseña si viene
    if (!empty($body['password']) && strlen($body['password']) >= 8) {
        $hash = password_hash($body['password'], PASSWORD_DEFAULT);
        $db->prepare('UPDATE usuarios SET password_hash=? WHERE id=?')->execute([$hash, $id]);
    }

    $updated = $db->prepare('SELECT * FROM usuarios WHERE id = ?');
    $updated->execute([$id]);
    $u = $updated->fetch();
    if (!$u) jsonResponse(['ok' => false, 'msg' => 'Usuario no encontrado'], 404);
    jsonResponse(['ok' => true, 'data' => mapUsuario($u)]);
}

// ── DELETE ─────────────────────────────────────────────────
if ($method === 'DELETE') {
    require_admin_jwt(); // RBAC: solo admin+
    if (!$id) jsonResponse(['ok' => false, 'msg' => 'ID requerido'], 400);

    $stmt = $db->prepare('DELETE FROM usuarios WHERE id = ?');
    $stmt->execute([$id]);
    if ($stmt->rowCount() === 0) jsonResponse(['ok' => false, 'msg' => 'Usuario no encontrado'], 404);
    jsonResponse(['ok' => true, 'msg' => 'Usuario eliminado']);
}

jsonResponse(['ok' => false, 'msg' => 'Método no permitido'], 405);

// ── Helper ─────────────────────────────────────────────────
function mapUsuario(array $row): array {
    return [
        'id'        => $row['id'],
        'nombre'    => $row['nombre'],
        'email'     => $row['email'],
        'telefono'  => $row['telefono'] ?? '',
        'rol'       => $row['rol'],
        'avatar'    => $row['avatar']   ?? '',
        'createdAt' => strtotime($row['created_at']) * 1000,
    ];
}
