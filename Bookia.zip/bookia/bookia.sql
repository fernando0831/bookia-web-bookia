-- ============================================================
--  BOOKIA — Base de Datos
--  Instalar: phpMyAdmin > Importar > bookia.sql
--  Contraseña de todos los usuarios: Bookia2026
-- ============================================================
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS `bookia` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `bookia`;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `reservas`;
DROP TABLE IF EXISTS `libros`;
DROP TABLE IF EXISTS `usuarios`;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE `usuarios` (
  `id`            CHAR(36)     NOT NULL,
  `nombre`        VARCHAR(120) NOT NULL,
  `email`         VARCHAR(180) NOT NULL,
  `telefono`      VARCHAR(20)  DEFAULT NULL,
  `rol`           ENUM('usuario','admin') NOT NULL DEFAULT 'usuario',
  `password_hash` VARCHAR(255) NOT NULL,
  `avatar`        VARCHAR(500) DEFAULT NULL,
  `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME     DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `libros` (
  `id`          CHAR(36)     NOT NULL,
  `titulo`      VARCHAR(255) NOT NULL,
  `autor`       VARCHAR(180) NOT NULL,
  `genero`      VARCHAR(60)  NOT NULL DEFAULT 'Ficción',
  `anio`        SMALLINT     DEFAULT NULL,
  `disponibles` SMALLINT     NOT NULL DEFAULT 0,
  `descripcion` TEXT         DEFAULT NULL,
  `imagen`      VARCHAR(500) DEFAULT NULL,
  `isbn`        VARCHAR(30)  DEFAULT NULL,
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  DATETIME     DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_genero` (`genero`),
  KEY `idx_titulo` (`titulo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `reservas` (
  `id`              CHAR(36)     NOT NULL,
  `usuario_id`      CHAR(36)     NOT NULL,
  `libro_id`        CHAR(36)     NOT NULL,
  `titulo_libro`    VARCHAR(255) NOT NULL,
  `autor_libro`     VARCHAR(180) NOT NULL,
  `fecha_reserva`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_recogida`  DATE         DEFAULT NULL,
  `estado`          ENUM('pendiente','lista','recogida','cancelada') NOT NULL DEFAULT 'pendiente',
  `notas`           TEXT         DEFAULT NULL,
  `codigo_recogida` VARCHAR(20)  NOT NULL,
  `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      DATETIME     DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_usuario` (`usuario_id`),
  KEY `idx_libro`   (`libro_id`),
  CONSTRAINT `fk_ru` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rl` FOREIGN KEY (`libro_id`)   REFERENCES `libros`(`id`)   ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- USUARIOS — contraseña: Bookia2026 (hash bcrypt real)
-- ============================================================
INSERT INTO `usuarios` (`id`,`nombre`,`email`,`telefono`,`rol`,`password_hash`) VALUES
('u-admin-001','Admin Bookia', 'admin@bookia.com', '4491234567','admin',  '$2y$12$inQDsAyK12icO4t4EPNUROIRIT26WZxanqIyiKhUmpdiyU25fkaDa'),
('u-admin-002','Angela Ropón', 'angela@bookia.com','4499876543','admin',  '$2y$12$dHRjNF0sxm10i11eLetLuOV0HS1i7WSEjI0VHEQCPZcjleiypPQ.a'),
('u-user-001', 'María García', 'maria@example.com','4491112233','usuario','$2y$12$wgIZ8y6VbYFqfhx4sXdFXeOXl3kM0HNFEDNIyJ5JyKqdqX7NvzCYq'),
('u-user-002', 'Juan Pérez',   'juan@example.com', '4494445566','usuario','$2y$12$WZ.pPPihszSJqIj/IREeXOhQkRnQ3OS4KQYZXBXYmTZqqnrCGeLFq');

-- ============================================================
-- LIBROS (48 libros, 8 géneros)
-- ============================================================
INSERT INTO `libros` (`id`,`titulo`,`autor`,`genero`,`anio`,`disponibles`,`descripcion`,`imagen`,`isbn`) VALUES
('lb-001','Cien años de soledad','Gabriel García Márquez','Ficción',1967,3,'La historia de los Buendía a lo largo de siete generaciones en el pueblo ficticio de Macondo.','https://covers.openlibrary.org/b/isbn/9780060883287-M.jpg','9780060883287'),
('lb-002','1984','George Orwell','Ficción',1949,5,'En una sociedad totalitaria del futuro, Winston Smith trabaja para el Partido reescribiendo la historia.','https://covers.openlibrary.org/b/isbn/9780451524935-M.jpg','9780451524935'),
('lb-003','El Alquimista','Paulo Coelho','Ficción',1988,6,'Santiago, un joven pastor andaluz, tiene un sueño recurrente con un tesoro escondido en las pirámides de Egipto.','https://covers.openlibrary.org/b/isbn/9780062315007-M.jpg','9780062315007'),
('lb-004','Don Quijote de la Mancha','Miguel de Cervantes','Ficción',1605,4,'Alonso Quijano pierde la razón y decide convertirse en caballero andante.','https://covers.openlibrary.org/b/isbn/9788420412146-M.jpg','9788420412146'),
('lb-005','Rayuela','Julio Cortázar','Ficción',1963,2,'Horacio Oliveira, un intelectual argentino en París, busca su lugar en el mundo.','https://covers.openlibrary.org/b/isbn/9788437604947-M.jpg','9788437604947'),
('lb-006','La sombra del viento','Carlos Ruiz Zafón','Ficción',2001,7,'En la Barcelona de posguerra, el joven Daniel Sempere descubre un libro olvidado.','https://covers.openlibrary.org/b/isbn/9788408046684-M.jpg','9788408046684'),
('lb-007','Sapiens','Yuval Noah Harari','No Ficción',2011,4,'Un recorrido por la historia de la humanidad desde los primeros Homo sapiens.','https://covers.openlibrary.org/b/isbn/9780062316097-M.jpg','9780062316097'),
('lb-008','El poder del ahora','Eckhart Tolle','No Ficción',1997,4,'Eckhart Tolle propone que la mayor fuente de sufrimiento humano es vivir atrapados en el pasado.','https://covers.openlibrary.org/b/isbn/9781577311522-M.jpg','9781577311522'),
('lb-009','Educated','Tara Westover','No Ficción',2018,3,'Tara Westover creció en las montañas de Idaho en una familia que desconfiaba del gobierno.','https://covers.openlibrary.org/b/isbn/9780399590504-M.jpg','9780399590504'),
('lb-010','Atomic Habits','James Clear','No Ficción',2018,5,'James Clear explica por qué los hábitos pequeños tienen un impacto enorme con el tiempo.','https://covers.openlibrary.org/b/isbn/9780735211292-M.jpg','9780735211292'),
('lb-011','Factfulness','Hans Rosling','No Ficción',2018,3,'Hans Rosling demuestra con datos que el mundo está mucho mejor de lo que creemos.','https://covers.openlibrary.org/b/isbn/9781250107817-M.jpg','9781250107817'),
('lb-012','El hombre en busca de sentido','Viktor Frankl','No Ficción',1946,6,'Viktor Frankl sobrevivió a los campos de concentración y desarrolló la logoterapia.','https://covers.openlibrary.org/b/isbn/9780807014271-M.jpg','9780807014271'),
('lb-013','El Principito','Antoine de Saint-Exupéry','Infantil',1943,8,'Un aviador en el Sahara conoce a un pequeño príncipe venido de un asteroide lejano.','https://covers.openlibrary.org/b/isbn/9780156012195-M.jpg','9780156012195'),
('lb-014','Harry Potter y la piedra filosofal','J.K. Rowling','Infantil',1997,10,'Harry Potter cumple once años y descubre que es un mago.','https://covers.openlibrary.org/b/isbn/9780590353427-M.jpg','9780590353427'),
('lb-015','Matilda','Roald Dahl','Infantil',1988,5,'Matilda es una niña extraordinariamente inteligente ignorada por sus padres.','https://covers.openlibrary.org/b/isbn/9780140344295-M.jpg','9780140344295'),
('lb-016','Momo','Michael Ende','Infantil',1973,4,'Momo es una niña que vive en un anfiteatro y tiene el don de escuchar.','https://covers.openlibrary.org/b/isbn/9788420420417-M.jpg','9788420420417'),
('lb-017','Las crónicas de Narnia','C.S. Lewis','Infantil',1950,6,'Cuatro niños descubren que un armario lleva a Narnia, un mundo mágico.','https://covers.openlibrary.org/b/isbn/9780064471190-M.jpg','9780064471190'),
('lb-018','Donde viven los monstruos','Maurice Sendak','Infantil',1963,7,'Max es enviado a su habitación y su cuarto se transforma en un bosque.','https://covers.openlibrary.org/b/isbn/9780060254926-M.jpg','9780060254926'),
('lb-019','El nombre de la rosa','Umberto Eco','Misterio',1980,3,'Fray Guillermo llega a una abadía y se encuentra con una serie de muertes inexplicables.','https://covers.openlibrary.org/b/isbn/9780151446476-M.jpg','9780151446476'),
('lb-020','El código Da Vinci','Dan Brown','Misterio',2003,5,'El curador del Louvre aparece muerto con un extraño mensaje junto a su cuerpo.','https://covers.openlibrary.org/b/isbn/9780307474278-M.jpg','9780307474278'),
('lb-021','Asesinato en el Orient Express','Agatha Christie','Misterio',1934,4,'Hércules Poirot investiga el asesinato de un pasajero en el lujoso Orient Express.','https://covers.openlibrary.org/b/isbn/9780062073501-M.jpg','9780062073501'),
('lb-022','La chica del tren','Paula Hawkins','Misterio',2015,4,'Rachel observa desde el tren una pareja perfecta — hasta que la mujer desaparece.','https://covers.openlibrary.org/b/isbn/9781594634024-M.jpg','9781594634024'),
('lb-023','Sherlock Holmes: Estudio en escarlata','Arthur Conan Doyle','Misterio',1887,6,'El Dr. Watson y Sherlock Holmes investigan el asesinato de un hombre.','https://covers.openlibrary.org/b/isbn/9780140439083-M.jpg','9780140439083'),
('lb-024','Gone Girl','Gillian Flynn','Misterio',2012,3,'En su quinto aniversario, Amy Dunne desaparece de su casa en Missouri.','https://covers.openlibrary.org/b/isbn/9780307588371-M.jpg','9780307588371'),
('lb-025','Dune','Frank Herbert','Ciencia Ficción',1965,4,'En un futuro lejano, Paul Atreides llega al planeta desértico Arrakis.','https://covers.openlibrary.org/b/isbn/9780441013593-M.jpg','9780441013593'),
('lb-026','Fundación','Isaac Asimov','Ciencia Ficción',1951,3,'Hari Seldon desarrolla la psicohistoria para preservar el conocimiento humano.','https://covers.openlibrary.org/b/isbn/9780553293357-M.jpg','9780553293357'),
('lb-027','El juego de Ender','Orson Scott Card','Ciencia Ficción',1985,5,'Ender Wiggin, un niño superdotado, es entrenado para salvar a la humanidad.','https://covers.openlibrary.org/b/isbn/9780812550702-M.jpg','9780812550702'),
('lb-028','Un mundo feliz','Aldous Huxley','Ciencia Ficción',1932,4,'La humanidad vive en un Estado Mundial donde las personas son fabricadas en laboratorios.','https://covers.openlibrary.org/b/isbn/9780060929879-M.jpg','9780060929879'),
('lb-029','Fahrenheit 451','Ray Bradbury','Ciencia Ficción',1953,5,'Guy Montag es un bombero en una sociedad futura donde los libros están prohibidos.','https://covers.openlibrary.org/b/isbn/9781451673319-M.jpg','9781451673319'),
('lb-030','Solaris','Stanisław Lem','Ciencia Ficción',1961,2,'El psicólogo Kelvin llega a una estación espacial que orbita el misterioso planeta Solaris.','https://covers.openlibrary.org/b/isbn/9780156837507-M.jpg','9780156837507'),
('lb-031','Orgullo y prejuicio','Jane Austen','Romance',1813,5,'Elizabeth Bennet y el aparentemente arrogante Sr. Darcy se conocen en un baile.','https://covers.openlibrary.org/b/isbn/9780141439518-M.jpg','9780141439518'),
('lb-032','Cumbres borrascosas','Emily Brontë','Romance',1847,4,'Heathcliff crece amando con devoción salvaje a Catherine.','https://covers.openlibrary.org/b/isbn/9780141439556-M.jpg','9780141439556'),
('lb-033','Lo que el viento se llevó','Margaret Mitchell','Romance',1936,3,'Scarlett O''Hara ve cómo la Guerra Civil destruye su mundo privilegiado.','https://covers.openlibrary.org/b/isbn/9781451635621-M.jpg','9781451635621'),
('lb-034','El tiempo entre costuras','María Dueñas','Romance',2009,6,'Sira Quiroga se reinventa como costurera de alto nivel en Tetuán.','https://covers.openlibrary.org/b/isbn/9788484835219-M.jpg','9788484835219'),
('lb-035','Me Before You','Jojo Moyes','Romance',2012,7,'Louisa Clark trabaja como cuidadora de Will Traynor, un exitoso financiero tetrapléjico.','https://covers.openlibrary.org/b/isbn/9780143124542-M.jpg','9780143124542'),
('lb-036','Bajo la misma estrella','John Green','Romance',2012,8,'Hazel y Augustus, jóvenes con cáncer, se conocen en un grupo de apoyo.','https://covers.openlibrary.org/b/isbn/9780525478812-M.jpg','9780525478812'),
('lb-037','El arte de la guerra','Sun Tzu','Historia',-500,6,'Los principios de estrategia escritos por Sun Tzu hace más de 2500 años.','https://covers.openlibrary.org/b/isbn/9780195014761-M.jpg','9780195014761'),
('lb-038','Ana Frank: Diario','Ana Frank','Historia',1947,5,'Ana Frank escondió a su familia judía en Ámsterdam durante la ocupación nazi.','https://covers.openlibrary.org/b/isbn/9780553296983-M.jpg','9780553296983'),
('lb-039','La Ilíada','Homero','Historia',-750,3,'Poema épico que narra los últimos 51 días del décimo año de la Guerra de Troya.','https://covers.openlibrary.org/b/isbn/9780226469409-M.jpg','9780226469409'),
('lb-040','Breve historia del tiempo','Stephen Hawking','Historia',1988,5,'Stephen Hawking explica para el público general los grandes misterios del cosmos.','https://covers.openlibrary.org/b/isbn/9780553380163-M.jpg','9780553380163'),
('lb-041','Guns, Germs, and Steel','Jared Diamond','Historia',1997,4,'Por qué unas civilizaciones conquistaron a otras y no al revés.','https://covers.openlibrary.org/b/isbn/9780393317558-M.jpg','9780393317558'),
('lb-042','En busca del tiempo perdido','Marcel Proust','Historia',1913,2,'El narrador rememora su infancia en Combray y sus años de juventud parisina.','https://covers.openlibrary.org/b/isbn/9780300185430-M.jpg','9780300185430'),
('lb-043','Los 7 hábitos de la gente altamente efectiva','Stephen Covey','Autoayuda',1989,6,'Siete principios fundamentales para ser más efectivo en la vida.','https://covers.openlibrary.org/b/isbn/9780743269513-M.jpg','9780743269513'),
('lb-044','El poder del hábito','Charles Duhigg','Autoayuda',2012,5,'Exploración de la neurociencia detrás de los hábitos y cómo cambiarlos.','https://covers.openlibrary.org/b/isbn/9780812981605-M.jpg','9780812981605'),
('lb-045','Mindset','Carol S. Dweck','Autoayuda',2006,4,'La distinción entre la mentalidad fija y la mentalidad de crecimiento.','https://covers.openlibrary.org/b/isbn/9780345472328-M.jpg','9780345472328'),
('lb-046','Cómo ganar amigos e influir sobre las personas','Dale Carnegie','Autoayuda',1936,7,'Principios prácticos para mejorar las relaciones personales y profesionales.','https://covers.openlibrary.org/b/isbn/9780671027032-M.jpg','9780671027032'),
('lb-047','Fluir (Flow)','Mihaly Csikszentmihalyi','Autoayuda',1990,3,'El estado de flow: concentración total donde el tiempo se detiene.','https://covers.openlibrary.org/b/isbn/9780061339202-M.jpg','9780061339202'),
('lb-048','El monje que vendió su Ferrari','Robin S. Sharma','Autoayuda',1997,5,'Julian Mantle, exitoso abogado, reconstruye su vida tras un infarto.','https://covers.openlibrary.org/b/isbn/9780062515474-M.jpg','9780062515474');

-- ============================================================
-- RESERVAS DE EJEMPLO
-- ============================================================
INSERT INTO `reservas` (`id`,`usuario_id`,`libro_id`,`titulo_libro`,`autor_libro`,`fecha_recogida`,`estado`,`codigo_recogida`) VALUES
('rv-001','u-user-001','lb-001','Cien años de soledad','Gabriel García Márquez',DATE_ADD(CURDATE(),INTERVAL 1 DAY),'pendiente','BKA-MN42-K7P'),
('rv-002','u-user-001','lb-007','Sapiens','Yuval Noah Harari',DATE_ADD(CURDATE(),INTERVAL 2 DAY),'lista','BKA-RT89-X2Q'),
('rv-003','u-user-002','lb-013','El Principito','Antoine de Saint-Exupéry',DATE_ADD(CURDATE(),INTERVAL 3 DAY),'recogida','BKA-JL55-B4W');

-- ============================================================
-- TABLAS PRÁCTICA — AUTENTICACIÓN AVANZADA
-- ============================================================

-- Ampliar rol y agregar columnas de seguridad a usuarios
ALTER TABLE `usuarios`
  MODIFY `rol` ENUM('usuario','editor','admin') NOT NULL DEFAULT 'usuario';

ALTER TABLE `usuarios`
  ADD COLUMN `mfa_activo`         TINYINT(1)   NOT NULL DEFAULT 0           AFTER `rol`,
  ADD COLUMN `pregunta_secreta`   VARCHAR(255) DEFAULT NULL                  AFTER `mfa_activo`,
  ADD COLUMN `respuesta_secreta`  VARCHAR(255) DEFAULT NULL                  AFTER `pregunta_secreta`,
  ADD COLUMN `tema_oscuro`        TINYINT(1)   NOT NULL DEFAULT 0            AFTER `respuesta_secreta`,
  ADD COLUMN `idioma`             VARCHAR(10)  NOT NULL DEFAULT 'es'         AFTER `tema_oscuro`,
  ADD COLUMN `intentos_fallidos`  SMALLINT     NOT NULL DEFAULT 0            AFTER `idioma`,
  ADD COLUMN `bloqueado_hasta`    DATETIME     DEFAULT NULL                  AFTER `intentos_fallidos`;

-- Sesiones activas (multisesión)
CREATE TABLE IF NOT EXISTS `sessions` (
  `id`          CHAR(128)    NOT NULL,
  `usuario_id`  CHAR(36)     NOT NULL,
  `ip`          VARCHAR(45)  NOT NULL DEFAULT '',
  `user_agent`  VARCHAR(500) NOT NULL DEFAULT '',
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_active` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `activa`      TINYINT(1)   NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_ses_uid` (`usuario_id`),
  CONSTRAINT `fk_ses_u` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Refresh tokens JWT
CREATE TABLE IF NOT EXISTS `refresh_tokens` (
  `id`          CHAR(36)     NOT NULL,
  `usuario_id`  CHAR(36)     NOT NULL,
  `token_hash`  CHAR(64)     NOT NULL,
  `session_id`  CHAR(128)    DEFAULT NULL,
  `expires_at`  DATETIME     NOT NULL,
  `revocado`    TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rt_hash` (`token_hash`),
  KEY `idx_rt_uid` (`usuario_id`),
  CONSTRAINT `fk_rt_u` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Códigos MFA/OTP
CREATE TABLE IF NOT EXISTS `mfa_codes` (
  `id`          CHAR(36)    NOT NULL,
  `usuario_id`  CHAR(36)    NOT NULL,
  `codigo`      CHAR(6)     NOT NULL,
  `tipo`        ENUM('email','sms','voz') NOT NULL DEFAULT 'email',
  `usado`       TINYINT(1)  NOT NULL DEFAULT 0,
  `intentos`    TINYINT     NOT NULL DEFAULT 0,
  `expires_at`  DATETIME    NOT NULL,
  `created_at`  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_mfa_uid` (`usuario_id`),
  CONSTRAINT `fk_mfa_u` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tokens de recuperación de contraseña
CREATE TABLE IF NOT EXISTS `password_resets` (
  `id`          CHAR(36)    NOT NULL,
  `usuario_id`  CHAR(36)    NOT NULL,
  `token_hash`  CHAR(64)    NOT NULL,
  `tipo`        ENUM('email','sms','voz') NOT NULL DEFAULT 'email',
  `usado`       TINYINT(1)  NOT NULL DEFAULT 0,
  `expires_at`  DATETIME    NOT NULL,
  `created_at`  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pr_hash` (`token_hash`),
  KEY `idx_pr_uid` (`usuario_id`),
  CONSTRAINT `fk_pr_u` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Usuario editor de ejemplo
INSERT IGNORE INTO `usuarios` (`id`,`nombre`,`email`,`telefono`,`rol`,`password_hash`) VALUES
('u-editor-001','Carlos Editor','carlos@bookia.com','4491234000','editor',
 '$2y$12$inQDsAyK12icO4t4EPNUROIRIT26WZxanqIyiKhUmpdiyU25fkaDa');

-- ============================================================
-- PRÁCTICA 2 UNIDAD 3 — NUEVOS CAMBIOS
-- ============================================================

-- 1. Ampliar rol ENUM para incluir superadmin
ALTER TABLE `usuarios`
  MODIFY `rol` ENUM('usuario','editor','admin','superadmin') NOT NULL DEFAULT 'usuario';

-- 2. Tabla de auditoría (registro de accesos y eventos)
CREATE TABLE IF NOT EXISTS `audit_log` (
  `id`          CHAR(36)      NOT NULL,
  `usuario_id`  CHAR(36)      DEFAULT NULL,
  `evento`      VARCHAR(100)  NOT NULL,
  `detalle`     TEXT          DEFAULT NULL,
  `ip`          VARCHAR(45)   NOT NULL DEFAULT '',
  `user_agent`  VARCHAR(300)  DEFAULT NULL,
  `url`         VARCHAR(500)  DEFAULT NULL,
  `created_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_al_uid`    (`usuario_id`),
  KEY `idx_al_evento` (`evento`),
  KEY `idx_al_ip`     (`ip`),
  KEY `idx_al_fecha`  (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Usuario SUPERADMIN
INSERT IGNORE INTO `usuarios` (`id`,`nombre`,`email`,`telefono`,`rol`,`password_hash`) VALUES
('u-superadmin-001','Super Admin','superadmin@bookia.com','4490000000','superadmin',
 '$2y$12$inQDsAyK12icO4t4EPNUROIRIT26WZxanqIyiKhUmpdiyU25fkaDa');

-- Contraseña de todos los usuarios: Bookia2026
