<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/session.php';

$u      = session_user();
$idioma = $u['idioma'] ?? 'es';
$pageTitle = $idioma === 'en' ? 'Catalogue — Bookia' : 'Catálogo — Bookia';

// Filtros
$busqueda = trim($_GET['q'] ?? '');
$genero   = trim($_GET['g'] ?? '');
$orden    = $_GET['orden'] ?? 'titulo';

// Construir query
$where  = [];
$params = [];
if ($busqueda) {
    $where[]  = '(titulo LIKE ? OR autor LIKE ?)';
    $params[] = "%$busqueda%";
    $params[] = "%$busqueda%";
}
if ($genero) {
    $where[]  = 'genero = ?';
    $params[] = $genero;
}

$whereSQL = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$orderSQL = match($orden) {
    'autor'       => 'autor ASC, titulo ASC',
    'anio'        => 'anio DESC, titulo ASC',
    'disponibles' => 'disponibles DESC, titulo ASC',
    default       => 'genero ASC, titulo ASC',
};

$libros  = [];
$generos = [];
try {
    $pdo     = db();
    $libros  = $pdo->prepare("SELECT * FROM libros $whereSQL ORDER BY $orderSQL");
    $libros->execute($params);
    $libros  = $libros->fetchAll();
    $generos = $pdo->query('SELECT DISTINCT genero FROM libros ORDER BY genero')->fetchAll(PDO::FETCH_COLUMN);
} catch (Exception $e) {
    $dbError = true;
}

// Agrupar por género
$porGenero = [];
foreach ($libros as $l) {
    $porGenero[$l['genero']][] = $l;
}

$generoIconos = [
    'Ficción'         => '📖',
    'No Ficción'      => '🧪',
    'Infantil'        => '🌟',
    'Misterio'        => '🔍',
    'Ciencia Ficción' => '🚀',
    'Romance'         => '💕',
    'Historia'        => '🏛️',
    'Autoayuda'       => '✨',
];

require_once __DIR__ . '/includes/header.php';
?>

<!-- Breadcrumb -->
<div class="breadcrumbs">
  <ul>
    <li><a href="<?= url('index.php') ?>"><?= $idioma==='en'?'Home':'Inicio' ?></a></li>
    <li><span class="current"><?= $idioma==='en'?'Catalogue':'Catálogo' ?></span></li>
  </ul>
</div>

<section class="catalogo">
  <div class="catalogo-header">
    <h2>📚 <?= $idioma==='en'?'Book Catalogue':'Catálogo de Libros' ?></h2>
    <p><?= $idioma==='en'?'Explore our complete collection':'Explora nuestra colección completa' ?></p>
  </div>

  <!-- Filtros -->
  <form method="GET" action="<?= url('catalogo.php') ?>" class="filtros-bar">
    <div class="search-box">
      <span class="search-icon">🔍</span>
      <input type="text" name="q" placeholder="<?= $idioma==='en'?'Search by title or author...':'Buscar por título o autor...' ?>"
             value="<?= e($busqueda) ?>">
    </div>
    <select name="g">
      <option value=""><?= $idioma==='en'?'All genres':'Todos los géneros' ?></option>
      <?php foreach ($generos as $g): ?>
        <option value="<?= e($g) ?>" <?= $genero === $g ? 'selected' : '' ?>><?= e($g) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="orden">
      <option value="titulo"       <?= $orden==='titulo'       ? 'selected':'' ?>><?= $idioma==='en'?'Sort by title':'Ordenar por título' ?></option>
      <option value="autor"        <?= $orden==='autor'        ? 'selected':'' ?>><?= $idioma==='en'?'Sort by author':'Ordenar por autor' ?></option>
      <option value="anio"         <?= $orden==='anio'         ? 'selected':'' ?>><?= $idioma==='en'?'Most recent':'Más recientes' ?></option>
      <option value="disponibles"  <?= $orden==='disponibles'  ? 'selected':'' ?>><?= $idioma==='en'?'Most available':'Más disponibles' ?></option>
    </select>
    <button type="submit" class="btn btn-sm"><?= $idioma==='en'?'Filter':'Filtrar' ?></button>
    <?php if ($busqueda || $genero): ?>
      <a href="<?= url('catalogo.php') ?>" class="btn btn-ghost btn-sm">✕ <?= $idioma==='en'?'Clear':'Limpiar' ?></a>
    <?php endif; ?>
    <span class="filtros-stats"><?= count($libros) ?> <?= $idioma==='en'?'book':'libro' ?><?= count($libros)!==1?'s':'' ?> <?= $idioma==='en'?'found':'encontrado' ?><?= count($libros)!==1&&$idioma!=='en'?'s':'' ?></span>
  </form>

  <?php if (isset($dbError)): ?>
    <div class="msg msg-error"><span class="msg-icon">⚠</span> <?= $idioma==='en'?'Database error. Check MySQL is running in XAMPP.':'Error de base de datos. Verifica que MySQL esté activo en XAMPP.' ?></div>
  <?php elseif (empty($libros)): ?>
    <div class="empty-state">
      <div class="empty-icon">📚</div>
      <h4><?= $idioma==='en'?'No books found':'No se encontraron libros' ?></h4>
      <p><?= $idioma==='en'?'Try different search filters.':'Intenta con otros filtros de búsqueda.' ?></p>
    </div>
  <?php else: ?>
    <?php foreach ($porGenero as $gen => $booksG): ?>
      <section class="categoria-section" id="cat-<?= e(strtolower(str_replace(' ','-',$gen))) ?>">
        <div class="categoria-header">
          <div class="categoria-icon"><?= $generoIconos[$gen] ?? '📚' ?></div>
          <h3><?= e($gen) ?></h3>
          <span class="cat-badge"><?= count($booksG) ?> <?= $idioma==='en'?'books':'libros' ?></span>
        </div>
        <div class="grid">
          <?php foreach ($booksG as $libro): ?>
            <?php
              $disp      = (int)$libro['disponibles'];
              $dispLabel = $idioma==='en' ? ($disp===0?'Out of stock':"$disp available") : ($disp===0?'Agotado':"$disp disponibles");
              $dispClass = $disp === 0 ? 'agotado' : ($disp <= 2 ? 'poco' : '');
              $badgeText = $idioma==='en' ? ($disp===0?'Out of stock':($disp<=2?'Last copies':'')) : ($disp===0?'Agotado':($disp<=2?'Últimas copias':''));
            ?>
            <div class="libro" data-detail-libro='<?= htmlspecialchars(json_encode(["id"=>$libro["id"],"titulo"=>$libro["titulo"],"autor"=>$libro["autor"],"genero"=>$libro["genero"],"anio"=>$libro["anio"],"disponibles"=>$libro["disponibles"],"descripcion"=>$libro["descripcion"],"imagen"=>$libro["imagen"],"isbn"=>$libro["isbn"]??""]), ENT_QUOTES) ?>' style="cursor:pointer">
              <div class="libro-cover">
                <?php if ($libro['imagen']): ?>
                  <img src="<?= e($libro['imagen']) ?>" alt="<?= e($libro['titulo']) ?>" loading="lazy"
                       data-isbn="<?= e($libro['isbn'] ?? '') ?>"
                       onerror="
                         var isbn=this.dataset.isbn;
                         if(isbn&&!this.dataset.fallback){
                           this.dataset.fallback='1';
                           this.src='https://books.google.com/books/content?vid=ISBN'+isbn+'&printsec=frontcover&img=1&zoom=1';
                         } else {
                           this.style.display='none';
                           this.parentElement.style.background='linear-gradient(135deg,#6B0F2A,#8B1A3A)';
                         }
                       ">
                <?php else: ?>
                  <div style="width:100%;height:100%;background:linear-gradient(135deg,#6B0F2A,#8B1A3A);display:flex;align-items:center;justify-content:center;font-size:40px;color:rgba(255,255,255,0.5)">📚</div>
                <?php endif; ?>
                <?php if ($badgeText): ?>
                  <span class="libro-badge <?= $dispClass ?>"><?= $badgeText ?></span>
                <?php endif; ?>
              </div>
              <div class="libro-body">
                <h3><?= e($libro['titulo']) ?></h3>
                <p class="libro-autor">✍️ <?= e($libro['autor']) ?></p>
                <div class="libro-meta">
                  <span class="libro-tag"><?= e($libro['genero']) ?></span>
                  <?php if ($libro['anio']): ?><span class="libro-tag"><?= (int)$libro['anio'] ?></span><?php endif; ?>
                </div>
                <?php if ($libro['descripcion']): ?>
                  <p class="libro-desc"><?= e(mb_substr($libro['descripcion'],0,80)) ?>…</p>
                <?php endif; ?>
                <p class="libro-disponibles">📚 <strong class="<?= $dispClass ?>"><?= $dispLabel ?></strong></p>
                <?php if ($disp > 0): ?>
                  <?php if (is_logged_in()): ?>
                    <a href="<?= url('reservar.php?libro=' . urlencode($libro['id'])) ?>" class="btn" style="width:100%;justify-content:center;text-align:center">📌 <?= $idioma==='en'?'Reserve':'Reservar' ?></a>
                  <?php else: ?>
                    <a href="<?= url('login.php') ?>" class="btn btn-ghost" style="width:100%;justify-content:center;text-align:center">🔐 <?= $idioma==='en'?'Log in':'Iniciar sesión' ?></a>
                  <?php endif; ?>
                <?php else: ?>
                  <button disabled class="btn btn-ghost" style="width:100%;cursor:not-allowed;opacity:.6">🚫 <?= $idioma==='en'?'Unavailable':'No disponible' ?></button>
                <?php endif; ?>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </section>
    <?php endforeach; ?>
  <?php endif; ?>
</section>

<?php
$extraScript = '<script src="js/cache.js"></script><script src="js/dom.js"></script><script src="js/api.js"></script><script src="js/data.js"></script><script src="js/ui.js"></script><script src="js/app.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function() {
  document.querySelectorAll("[data-detail-libro]").forEach(function(card) {
    card.addEventListener("click", function(e) {
      if (e.target.closest("a") || e.target.closest("button")) return;
      try {
        var libro = JSON.parse(this.dataset.detailLibro);
        if (window.BookiaUI && window.BookiaUI.openLibroDetail) {
          window.BookiaUI.openLibroDetail(libro);
        }
      } catch(err) { console.error(err); }
    });
  });
});
</script>';
require_once __DIR__ . '/includes/footer.php'; ?>
