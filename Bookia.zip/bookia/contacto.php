<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/session.php';

$u      = session_user();
$idioma = $u['idioma'] ?? 'es';
$pageTitle = $idioma === 'en' ? 'Contact Us — Bookia' : 'Contáctanos — Bookia';

$_ct_en = $idioma === 'en';
$extraScript = '<script src="js/dom.js"></script>
<script src="js/data.js"></script>
<script src="js/ui.js"></script>
<script src="js/app.js"></script>
<script>
const BookiaCaptcha = {
  a: 0, b: 0, op: \'+\', verified: false,
  lang: \'' . $idioma . '\',
  init() {
    const ops = [\'opa\', \'-\', \'×\'];
    this.op = ops[Math.floor(Math.random()*3)];
    if (this.op === \'×\') { this.a = Math.floor(Math.random()*9)+1; this.b = Math.floor(Math.random()*9)+1; }
    else if (this.op === \'-\') { this.a = Math.floor(Math.random()*15)+10; this.b = Math.floor(Math.random()*this.a); }
    else { this.op=\'+\'; this.a = Math.floor(Math.random()*20)+1; this.b = Math.floor(Math.random()*20)+1; }
    document.getElementById(\'captchaA\').textContent = this.a;
    document.getElementById(\'captchaOp\').textContent = this.op;
    document.getElementById(\'captchaB\').textContent = this.b;
    document.getElementById(\'captchaAns\').value = \'\';
    this.verified = false;
    const box = document.getElementById(\'captchaBox\');
    if (box) { box.classList.remove(\'verified\',\'error\'); }
    const chk = document.getElementById(\'captchaCheckMark\');
    if (chk) chk.textContent = \'\';
  },
  show() {
    const ch = document.getElementById(\'captchaChallenge\');
    const box = document.getElementById(\'captchaBox\');
    if (!this.verified) { ch.classList.add(\'active\'); box.classList.add(\'active\'); }
  },
  verify() {
    const ans = parseInt(document.getElementById(\'captchaAns\').value);
    const expected = this.op===\'+\' ? this.a+this.b : this.op===\'-\' ? this.a-this.b : this.a*this.b;
    const box = document.getElementById(\'captchaBox\');
    const chk = document.getElementById(\'captchaCheckMark\');
    const err = document.getElementById(\'captcha-error\');
    if (ans === expected) {
      this.verified = true;
      box.classList.remove(\'error\'); box.classList.add(\'verified\');
      document.getElementById(\'captchaChallenge\').classList.remove(\'active\');
      if(chk) chk.textContent = \'✓\';
      if(err) { err.textContent=\'\'; err.style.display=\'none\'; }
    } else {
      box.classList.add(\'error\'); box.classList.remove(\'verified\');
      if(err) { err.textContent=this.lang===\'en\'?\'Incorrect answer. Try again.\':\'Respuesta incorrecta. Intenta de nuevo.\'; err.style.display=\'flex\'; }
      setTimeout(() => this.init(), 1200);
    }
  },
  isVerified() { return this.verified; }
};
document.addEventListener(\'DOMContentLoaded\', () => {
  BookiaCaptcha.init();
  if (typeof BookiaAnimations !== \'undefined\') BookiaAnimations.init();
  ContactoController.init();
  const box = document.getElementById(\'captchaBox\');
  if (box) {
    box.addEventListener(\'click\', () => BookiaCaptcha.show());
    box.addEventListener(\'keydown\', e => { if(e.key===\'Enter\'||e.key===\' \') BookiaCaptcha.show(); });
  }
  const ans = document.getElementById(\'captchaAns\');
  if (ans) { ans.addEventListener(\'keydown\', e => { if(e.key===\'Enter\') BookiaCaptcha.verify(); }); }
});
</script>';

require_once __DIR__ . '/includes/header.php';
?>

<style>
  .contacto-hero {
    background: linear-gradient(135deg, #4a0a1c 0%, #6B0F2A 50%, #8B1A3A 100%);
    color: #fff;
    padding: 56px 40px 48px;
    text-align: center;
    position: relative;
    overflow: hidden;
  }
  .contacto-hero::before {
    content: '';
    position: absolute;
    width: 300px; height: 300px;
    border-radius: 50%;
    border: 1.5px solid rgba(255,255,255,.1);
    top: -80px; right: -80px;
    pointer-events: none;
  }
  .contacto-hero::after {
    content: '';
    position: absolute;
    width: 200px; height: 200px;
    border-radius: 50%;
    background: rgba(255,255,255,.04);
    bottom: -60px; left: -60px;
    pointer-events: none;
  }
  .contacto-hero h1 { font-size: 34px; font-weight: 900; margin-bottom: 10px; position: relative; }
  .contacto-hero p { font-size: 16px; opacity: .85; max-width: 480px; margin: 0 auto; position: relative; }

  .contacto-grid {
    max-width: 1100px;
    margin: -32px auto 60px;
    padding: 0 28px;
    display: grid;
    grid-template-columns: 1fr 1.5fr;
    gap: 28px;
    align-items: start;
  }
  @media (max-width: 768px) { .contacto-grid { grid-template-columns: 1fr; margin-top: -16px; } }

  .card-info { background: #fff; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,.1); overflow: hidden; }
  .card-info-header { background: linear-gradient(135deg, #6B0F2A, #8B1A3A); padding: 24px 28px; color: #fff; }
  .card-info-header h3 { font-size: 17px; font-weight: 800; margin-bottom: 4px; }
  .card-info-header p { font-size: 13px; opacity: .8; }
  .card-info-body { padding: 24px 28px; }

  .info-item {
    display: flex; align-items: flex-start; gap: 14px;
    padding: 14px 0; border-bottom: 1px solid #f3f4f6; transition: background .15s;
  }
  .info-item:last-of-type { border-bottom: none; }
  .info-icono {
    width: 40px; height: 40px; border-radius: 10px;
    background: linear-gradient(135deg, rgba(107,15,42,.1), rgba(193,154,107,.1));
    display: flex; align-items: center; justify-content: center;
    font-size: 18px; flex-shrink: 0;
  }
  .info-titulo { font-size: 13px; font-weight: 700; color: #111827; }
  .info-detalle { font-size: 13px; color: var(--color-muted); line-height: 1.5; }

  .mini-mapa {
    margin-top: 20px; border-radius: 12px; overflow: hidden;
    border: 1px solid #e5e7eb;
    background: linear-gradient(135deg, #f3f4f6, #e5e7eb);
    height: 140px; display: flex; align-items: center; justify-content: center;
    color: #9CA3AF; font-size: 13px; gap: 8px; position: relative;
  }
  .mini-mapa::before {
    content: '📍'; font-size: 32px; position: absolute;
    top: 50%; left: 50%; transform: translate(-50%, -60%);
    animation: bounce-pin 1.5s ease-in-out infinite;
  }
  @keyframes bounce-pin {
    0%, 100% { transform: translate(-50%, -60%); }
    50%       { transform: translate(-50%, -75%); }
  }

  .redes { display: flex; gap: 10px; margin-top: 18px; }
  .red-btn {
    width: 38px; height: 38px; border-radius: 10px;
    border: 1.5px solid #e5e7eb; background: #fff;
    display: flex; align-items: center; justify-content: center;
    font-size: 18px; cursor: pointer; transition: all .2s; text-decoration: none;
  }
  .red-btn:hover { border-color: var(--color-primary); background: rgba(107,15,42,.05); transform: translateY(-2px); }

  .card-form { background: #fff; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,.1); overflow: hidden; }
  .card-form-header { padding: 24px 32px 16px; border-bottom: 1px solid #f3f4f6; }
  .card-form-header h2 { font-size: 20px; font-weight: 800; color: #111827; }
  .card-form-header p { font-size: 13px; color: var(--color-muted); margin-top: 4px; }
  .card-form-body { padding: 24px 32px 32px; }

  .form-2col { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
  .form-2col .form-full { grid-column: 1 / -1; }
  @media (max-width: 500px) { .form-2col { grid-template-columns: 1fr; } }

  textarea#cmensaje {
    width: 100%; min-height: 110px; resize: vertical;
    border: 1.5px solid #e5e7eb; border-radius: 10px;
    padding: 10px 14px; font-size: 14px; font-family: inherit;
    color: #374151; transition: border-color .2s, box-shadow .2s; box-sizing: border-box;
  }
  textarea#cmensaje:focus { outline: none; border-color: var(--color-primary); box-shadow: 0 0 0 3px rgba(107,15,42,.08); }

  select#casunto {
    width: 100%; height: 46px; border: 1.5px solid #e5e7eb;
    border-radius: 10px; padding: 0 14px; font-size: 14px;
    background: #fff; cursor: pointer; color: #374151; transition: border-color .2s;
  }
  select#casunto:focus { outline: none; border-color: var(--color-primary); }

  /* ── DARK MODE ── */
  html[data-theme="dark"] body { background: #0f0f14 !important; color: #e8e0d0 !important; }
  html[data-theme="dark"] .card-info,
  html[data-theme="dark"] .card-form  { background: #1a1a24 !important; box-shadow: 0 4px 24px rgba(0,0,0,.5) !important; }
  html[data-theme="dark"] .card-form-header { border-bottom-color: #2e2e3e !important; }
  html[data-theme="dark"] .card-form-header h2 { color: #e8e0d0 !important; }
  html[data-theme="dark"] .card-form-header p  { color: #9ca3af !important; }
  html[data-theme="dark"] .info-titulo  { color: #e8e0d0 !important; }
  html[data-theme="dark"] .info-item    { border-bottom-color: #2e2e3e !important; }
  html[data-theme="dark"] .mini-mapa   { background: linear-gradient(135deg,#1a1a24,#2e2e3e) !important; border-color: #2e2e3e !important; }
  html[data-theme="dark"] .red-btn     { background: #1a1a24 !important; border-color: #2e2e3e !important; }
  html[data-theme="dark"] textarea#cmensaje,
  html[data-theme="dark"] select#casunto { background: #1e1e2c !important; color: #e8e0d0 !important; border-color: #2e2e3e !important; }
  html[data-theme="dark"] .contacto-grid { background: transparent !important; }
</style>

  <div class="contacto-hero" data-reveal>
    <h1>✉️ <?= $_ct_en?'How can we help you?':'¿Cómo podemos ayudarte?' ?></h1>
    <p><?= $_ct_en?'We are here to answer your questions about reservations, catalogue, or anything else.':'Estamos aquí para resolver tus dudas sobre reservas, catálogo o cualquier otra cosa.' ?></p>
  </div>

  <div class="contacto-grid">

    <div data-reveal data-delay="0">
      <div class="card-info">
        <div class="card-info-header">
          <h3>📍 <?= $_ct_en?'Contact information':'Información de contacto' ?></h3>
          <p>Librería Bookia · Aguascalientes, MX</p>
        </div>
        <div class="card-info-body">
          <div class="info-item">
            <div class="info-icono">📍</div>
            <div>
              <div class="info-titulo"><?= $_ct_en?'Address':'Dirección' ?></div>
              <div class="info-detalle">Av. López Mateos 123, Centro<br>Aguascalientes, Ags. 20000</div>
            </div>
          </div>
          <div class="info-item">
            <div class="info-icono">📞</div>
            <div>
              <div class="info-titulo"><?= $_ct_en?'Phone':'Teléfono' ?></div>
              <div class="info-detalle">(449) 123-4567</div>
            </div>
          </div>
          <div class="info-item">
            <div class="info-icono">✉️</div>
            <div>
              <div class="info-titulo"><?= $_ct_en?'Email':'Correo electrónico' ?></div>
              <div class="info-detalle">contacto@bookia.com</div>
            </div>
          </div>
          <div class="info-item">
            <div class="info-icono">⏰</div>
            <div>
              <div class="info-titulo"><?= $_ct_en?'Business hours':'Horario de atención' ?></div>
              <div class="info-detalle"><?= $_ct_en?'Mon – Fri: 9:00 – 20:00<br>Saturday: 10:00 – 18:00<br>Sunday: Closed':'Lun – Vie: 9:00 – 20:00<br>Sábado: 10:00 – 18:00<br>Domingo: Cerrado' ?></div>
            </div>
          </div>
          <div class="mini-mapa">
            <span style="margin-top:60px;font-size:12px;color:#9CA3AF">Aguascalientes, MX</span>
          </div>
          <div class="redes">
            <a href="#" class="red-btn" title="Facebook">📘</a>
            <a href="#" class="red-btn" title="Instagram">📷</a>
            <a href="#" class="red-btn" title="Twitter/X">🐦</a>
            <a href="#" class="red-btn" title="WhatsApp">💬</a>
          </div>
        </div>
      </div>
    </div>

    <div data-reveal data-delay="100">
      <div class="card-form">
        <div class="card-form-header">
          <h2>✉ <?= $_ct_en?'Send us a message':'Envíanos un mensaje' ?></h2>
          <p><?= $_ct_en?'We will respond within 24 hours.':'Te responderemos en menos de 24 horas' ?></p>
        </div>
        <div class="card-form-body">
          <div id="contacto-msg"></div>
          <form id="contactoForm" novalidate>
            <div class="form-2col">
              <div class="form-group">
                <label for="cnombre"><?= $_ct_en?'Name':'Nombre' ?> <span class="required">*</span></label>
                <input type="text" id="cnombre" name="cnombre" placeholder="<?= $_ct_en?'Your name':'Tu nombre' ?>" required
                       value="<?= is_logged_in() ? e(session_user()['nombre']) : '' ?>">
                <p class="field-error" id="cnombre-error" role="alert"></p>
              </div>
              <div class="form-group">
                <label for="cemail"><?= $_ct_en?'Email':'Correo' ?> <span class="required">*</span></label>
                <input type="email" id="cemail" name="cemail" placeholder="tu@correo.com" required
                       value="<?= is_logged_in() ? e(session_user()['email']) : '' ?>">
                <p class="field-error" id="cemail-error" role="alert"></p>
              </div>
              <div class="form-group form-full">
                <label for="casunto"><?= $_ct_en?'Subject':'Asunto' ?> <span class="required">*</span></label>
                <select id="casunto" name="casunto" required>
                  <option value=""><?= $_ct_en?'— Select a subject —':'— Selecciona un asunto —' ?></option>
                  <option value="reserva"><?= $_ct_en?'Reservation inquiry':'Consulta sobre reserva' ?></option>
                  <option value="catalogo"><?= $_ct_en?'Catalogue inquiry':'Consulta sobre catálogo' ?></option>
                  <option value="pickup"><?= $_ct_en?'Pick-up information':'Información pick-up' ?></option>
                  <option value="devolucion"><?= $_ct_en?'Returns':'Devoluciones' ?></option>
                  <option value="otro"><?= $_ct_en?'Other':'Otro' ?></option>
                </select>
                <p class="field-error" id="casunto-error" role="alert"></p>
              </div>
              <div class="form-group form-full">
                <label for="cmensaje"><?= $_ct_en?'Message':'Mensaje' ?> <span class="required">*</span></label>
                <textarea id="cmensaje" name="cmensaje" placeholder="<?= $_ct_en?'Write your message here…':'Escribe tu mensaje aquí…' ?>" required></textarea>
                <p class="field-error" id="cmensaje-error" role="alert"></p>
              </div>
              <div class="form-group form-full" id="captcha-group">
                <label><?= $_ct_en?'Security verification':'Verificación de seguridad' ?> <span class="required">*</span></label>
                <div class="captcha-box" id="captchaBox" role="button" tabindex="0" aria-label="<?= $_ct_en?'CAPTCHA verification':'Verificación CAPTCHA' ?>">
                  <div class="captcha-checkbox" id="captchaCheck">
                    <span id="captchaCheckMark"></span>
                  </div>
                  <span class="captcha-label"><?= $_ct_en?"I'm not a robot":'No soy un robot' ?></span>
                  <div class="captcha-brand">
                    <span style="font-size:18px">🛡️</span>
                    <span>Bookia</span>
                    <span>Verify</span>
                  </div>
                </div>
                <div class="captcha-challenge" id="captchaChallenge">
                  <p><?= $_ct_en?'Solve to verify:':'Resuelve para verificar:' ?></p>
                  <div class="captcha-math">
                    <span id="captchaA">?</span>
                    <span id="captchaOp">+</span>
                    <span id="captchaB">?</span>
                    <span>=</span>
                    <input type="number" id="captchaAns" class="captcha-math-input"
                           placeholder="?" min="0" max="99" autocomplete="off">
                  </div>
                  <button type="button" class="captcha-submit" onclick="BookiaCaptcha.verify()">
                    ✓ <?= $_ct_en?'Verify':'Verificar' ?>
                  </button>
                </div>
                <p class="field-error" id="captcha-error" role="alert"></p>
              </div>
              <div class="form-full">
                <button type="submit" class="btn btn-primary"
                        style="width:100%;justify-content:center;padding:14px;font-size:15px">
                  <?= $_ct_en?'Send message →':'Enviar mensaje →' ?>
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>

  </div>

<?php require_once __DIR__ . "/includes/footer.php"; ?>
