<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/session.php';
$_dsh_u = session_user();
$_dsh_tema = 0; $_dsh_idioma = 'es';
if ($_dsh_u) {
    try {
        $pref = db()->prepare('SELECT tema_oscuro, idioma FROM usuarios WHERE id=? LIMIT 1');
        $pref->execute([$_dsh_u['id']]);
        $row = $pref->fetch();
        if ($row) { $_dsh_tema = (int)$row['tema_oscuro']; $_dsh_idioma = $row['idioma']; }
    } catch (Exception $e) {}
}
$_dsh_en = $_dsh_idioma === 'en';
?>
<!DOCTYPE html>
<html lang="<?= $_dsh_idioma ?>" data-theme="<?= $_dsh_tema ? 'dark' : 'light' ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $_dsh_en ? "Dashboard — Bookia" : "Panel — Bookia" ?></title>
  <link rel="stylesheet" href="styles/estilos.css">
  <link rel="stylesheet" href="styles/base.css">
  <link rel="stylesheet" href="styles/animations.css">
  <style>
    /* ══════════════════════════════════════════════════
       LAYOUT PRINCIPAL DEL DASHBOARD
    ══════════════════════════════════════════════════ */
    .dash-wrap {
      max-width: 1240px;
      margin: 0 auto;
      padding: 32px 20px;
    }

    /* ── Encabezado superior ─────────────────────────── */
    .dash-encabezado {
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 16px;
      margin-bottom: 24px;
    }
    .dash-titulo { font-size: 24px; font-weight: 800; color: var(--color-primary); }
    .dash-subtitulo { font-size: 13px; color: var(--color-muted); margin-top: 4px; max-width: 480px; }

    /* Grupo de botones de acción */
    .dash-acciones {
      display: flex;
      align-items: center;
      gap: 10px;
      flex-wrap: wrap;
    }

    /* ── Tarjetas de estadísticas ─────────────────────── */
    .estadisticas {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 16px;
      margin-bottom: 24px;
    }
    .estadistica-item {
      background: #fff;
      border-radius: 14px;
      padding: 20px 22px;
      box-shadow: 0 1px 4px rgba(0,0,0,.06);
      border: 1px solid var(--color-border);
      display: flex;
      align-items: center;
      gap: 14px;
      transition: transform .2s, box-shadow .2s;
    }
    .estadistica-item:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(107,15,42,.1);
    }
    .estadistica-icono {
      font-size: 28px;
      width: 52px; height: 52px;
      display: flex; align-items: center; justify-content: center;
      background: linear-gradient(135deg, rgba(107,15,42,.1), rgba(193,154,107,.1));
      border-radius: 12px;
      flex-shrink: 0;
    }
    .estadistica-item__numero {
      font-size: 26px;
      font-weight: 800;
      color: var(--color-primary);
      line-height: 1;
    }
    .estadistica-item__etiqueta {
      font-size: 12px;
      color: var(--color-muted);
      margin-top: 3px;
    }

    /* ── Barra de búsqueda y filtros ──────────────────── */
    .barra-controles {
      display: flex;
      align-items: center;
      gap: 10px;
      flex-wrap: wrap;
      margin-bottom: 20px;
      background: #fff;
      border: 1px solid var(--color-border);
      border-radius: 12px;
      padding: 10px 14px;
      box-shadow: 0 1px 3px rgba(0,0,0,.05);
    }
    .caja-busqueda {
      display: flex;
      align-items: center;
      gap: 8px;
      flex: 1;
      min-width: 200px;
    }
    .caja-busqueda input {
      border: none;
      outline: none;
      background: none;
      font-size: 14px;
      width: 100%;
      color: #111827;
    }
    .caja-busqueda input::placeholder { color: #9CA3AF; }
    .filtro-select {
      height: 36px;
      border: 1.5px solid var(--color-border);
      border-radius: 8px;
      padding: 0 12px;
      font-size: 13px;
      background: #f9fafb;
      cursor: pointer;
      color: #374151;
      transition: border-color .2s;
    }
    .filtro-select:focus { border-color: var(--color-primary); outline: none; }
    .contador-resultados {
      font-size: 12px;
      color: var(--color-muted);
      white-space: nowrap;
      padding: 4px 10px;
      background: #f3f4f6;
      border-radius: 20px;
    }

    /* ── Layout de dos columnas ───────────────────────── */
    .columnas {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
    }
    @media (max-width: 768px) { .columnas { grid-template-columns: 1fr; } }

    /* ── Panel genérico ───────────────────────────────── */
    .panel {
      background: #fff;
      border-radius: 14px;
      box-shadow: 0 1px 4px rgba(0,0,0,.06);
      border: 1px solid var(--color-border);
      overflow: hidden;
    }
    .panel__encabezado {
      padding: 14px 18px;
      border-bottom: 1px solid var(--color-border);
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: linear-gradient(to right, rgba(107,15,42,.03), transparent);
    }
    .panel__titulo {
      font-size: 14px;
      font-weight: 700;
      color: var(--color-primary);
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .panel__cuerpo {
      padding: 0;
      max-height: 440px;
      overflow-y: auto;
      scroll-behavior: smooth;
    }
    /* Scrollbar personalizado */
    .panel__cuerpo::-webkit-scrollbar { width: 4px; }
    .panel__cuerpo::-webkit-scrollbar-track { background: #f9fafb; }
    .panel__cuerpo::-webkit-scrollbar-thumb { background: #d1d5db; border-radius: 4px; }

    /* ── Badge contador ───────────────────────────────── */
    .panel-badge {
      background: var(--color-primary);
      color: #fff;
      font-size: 11px;
      font-weight: 700;
      padding: 2px 8px;
      border-radius: 20px;
      min-width: 22px;
      text-align: center;
      opacity: 0;
      transition: opacity .3s;
    }

    /* ── Ítem de usuario ──────────────────────────────── */
    .usuario-item {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 11px 18px;
      border-bottom: 1px solid #f3f4f6;
      transition: background .15s;
      cursor: default;
    }
    .usuario-item:hover { background: #fdf8f0; }
    .usuario-item:last-child { border-bottom: none; }
    .usuario-avatar {
      width: 40px; height: 40px;
      border-radius: 50%;
      background: linear-gradient(135deg, var(--color-primary), #8B1A3A);
      color: #fff;
      display: flex; align-items: center; justify-content: center;
      font-weight: 800; font-size: 15px;
      flex-shrink: 0;
      box-shadow: 0 2px 6px rgba(107,15,42,.25);
    }
    .usuario-info { flex: 1; min-width: 0; }
    .usuario-nombre  { font-size: 13px; font-weight: 700; color: #111827; }
    .usuario-correo  { font-size: 11px; color: var(--color-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .usuario-empresa { font-size: 11px; color: var(--color-accent); margin-top: 2px; font-weight: 600; }
    .usuario-ciudad  { font-size: 10px; color: #9CA3AF; }

    /* ── Ítem de publicación ──────────────────────────── */
    .publicacion-item { border-bottom: 1px solid #f3f4f6; }
    .publicacion-item:last-child { border-bottom: none; }

    /* Cabecera clicable de cada publicación */
    .publicacion-cabecera {
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 10px;
      padding: 12px 18px;
      cursor: pointer;
      transition: background .15s;
    }
    .publicacion-cabecera:hover { background: #fdf8f0; }

    .publicacion-num {
      font-size: 10px;
      font-weight: 800;
      color: var(--color-accent);
      background: rgba(193,154,107,.12);
      padding: 2px 6px;
      border-radius: 4px;
      flex-shrink: 0;
      margin-top: 2px;
    }
    .publicacion-titulo {
      font-size: 13px; font-weight: 700; color: #111827;
      line-height: 1.4; text-transform: capitalize;
    }
    .publicacion-cuerpo {
      font-size: 12px; color: var(--color-muted); margin-top: 3px;
      display: -webkit-box; -webkit-line-clamp: 2;
      -webkit-box-orient: vertical; overflow: hidden;
      line-height: 1.5;
    }
    .publicacion-meta {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-top: 5px;
    }
    .publicacion-autor {
      font-size: 11px; color: var(--color-accent);
      font-weight: 700;
    }

    /* ── Botón de comentarios ─────────────────────────── */
    /* Este botón SÍ funciona: abre/cierra los comentarios */
    .btn-comentarios {
      flex-shrink: 0;
      display: inline-flex;
      align-items: center;
      gap: 5px;
      font-size: 11px;
      padding: 6px 12px;
      border: 1.5px solid var(--color-border);
      border-radius: 20px;
      background: none;
      cursor: pointer;
      color: var(--color-muted);
      transition: all .2s;
      white-space: nowrap;
      font-weight: 600;
    }
    .btn-comentarios:hover {
      border-color: var(--color-primary);
      color: var(--color-primary);
      background: rgba(107,15,42,.04);
    }
    /* Estado activo: publicación expandida */
    .btn-comentarios.activo {
      background: var(--color-primary);
      color: #fff;
      border-color: var(--color-primary);
      box-shadow: 0 2px 8px rgba(107,15,42,.25);
    }
    /* Contador de comentarios dentro del botón */
    .btn-comentarios .contador-com {
      background: rgba(255,255,255,.25);
      border-radius: 10px;
      padding: 0 5px;
      font-size: 10px;
    }
    .btn-comentarios:not(.activo) .contador-com {
      background: #f3f4f6;
      color: #374151;
    }
    /* Indicador de carga dentro del botón */
    .btn-comentarios .spin-mini {
      width: 10px; height: 10px;
      border: 1.5px solid currentColor;
      border-top-color: transparent;
      border-radius: 50%;
      animation: spin .6s linear infinite;
      display: none;
    }
    .btn-comentarios.cargando .spin-mini { display: inline-block; }

    /* ── Sección de comentarios expandible ────────────── */
    /* USA max-height + opacity — sin display:none (Parte 3.2) */
    .seccion-comentarios {
      background: #fafbff;
      border-top: 1px solid #eef0f5;
      max-height: 0;
      overflow: hidden;
      opacity: 0;
      padding: 0 18px;
      transition: max-height 0.45s cubic-bezier(0.4,0,0.2,1),
                  opacity 0.3s ease,
                  padding 0.3s ease;
    }
    .seccion-comentarios.abierta {
      max-height: 700px;
      opacity: 1;
      padding: 14px 18px;
    }

    /* Cabecera interna de la sección de comentarios */
    .comentarios-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 10px;
      padding-bottom: 8px;
      border-bottom: 1px solid #e5e7eb;
    }
    .comentarios-titulo {
      font-size: 12px;
      font-weight: 700;
      color: #374151;
      display: flex;
      align-items: center;
      gap: 5px;
    }

    /* Ítem individual de comentario */
    .comentario-item {
      display: flex;
      gap: 10px;
      padding: 9px 0;
      border-bottom: 1px solid #f0f0f5;
    }
    .comentario-item:last-child { border-bottom: none; }
    .comentario-avatar {
      width: 32px; height: 32px;
      border-radius: 50%;
      background: linear-gradient(135deg, #e5e7eb, #d1d5db);
      color: var(--color-primary);
      display: flex; align-items: center; justify-content: center;
      font-weight: 800; font-size: 12px;
      flex-shrink: 0;
    }
    .comentario-nombre {
      font-size: 12px; font-weight: 700; color: #111827;
    }
    .comentario-correo {
      font-size: 10px; color: var(--color-muted);
    }
    .comentario-cuerpo {
      font-size: 12px; color: #4B5563;
      margin-top: 3px; line-height: 1.55;
    }

    /* Formulario rápido para añadir comentario */
    .form-nuevo-comentario {
      margin-top: 12px;
      padding-top: 10px;
      border-top: 1px dashed #e5e7eb;
      display: flex;
      gap: 8px;
      align-items: flex-end;
    }
    .form-nuevo-comentario textarea {
      flex: 1;
      border: 1.5px solid #e5e7eb;
      border-radius: 8px;
      padding: 8px 10px;
      font-size: 12px;
      resize: none;
      height: 50px;
      font-family: inherit;
      color: #374151;
      transition: border-color .2s;
    }
    .form-nuevo-comentario textarea:focus {
      outline: none;
      border-color: var(--color-primary);
    }
    .form-nuevo-comentario button {
      padding: 8px 14px;
      background: var(--color-primary);
      color: #fff;
      border: none;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
      transition: opacity .2s;
      white-space: nowrap;
      height: 50px;
    }
    .form-nuevo-comentario button:hover { opacity: .85; }

    /* ── Indicadores de carga ─────────────────────────── */
    .cargando {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 28px;
      color: var(--color-muted);
      gap: 10px;
      font-size: 13px;
    }
    .cargando-circulo {
      width: 22px; height: 22px;
      border: 2.5px solid #e5e7eb;
      border-top-color: var(--color-primary);
      border-radius: 50%;
      animation: spin .7s linear infinite;
    }
    @keyframes spin { to { transform: rotate(360deg); } }

    /* ── Banners de error ─────────────────────────────── */
    .banner-error {
      background: #FEE2E2;
      color: #991B1B;
      border: 1px solid #FECACA;
      border-radius: 10px;
      padding: 10px 16px;
      font-size: 13px;
      margin-bottom: 14px;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    /* ── Panel de tiempo real ─────────────────────────── */
    .panel-tiempo-real { margin-top: 20px; }

    .elemento-tiempo-real {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 10px 18px;
      border-bottom: 1px solid #f3f4f6;
      font-size: 13px;
      transition: background .2s;
    }
    .elemento-tiempo-real:hover { background: #fdf8f0; }
    .punto-vivo {
      width: 9px; height: 9px;
      border-radius: 50%;
      background: #16a34a;
      flex-shrink: 0;
      box-shadow: 0 0 0 3px rgba(22,163,74,.2);
      animation: pulso 2s ease-in-out infinite;
    }
    @keyframes pulso {
      0%, 100% { box-shadow: 0 0 0 3px rgba(22,163,74,.2); }
      50% { box-shadow: 0 0 0 6px rgba(22,163,74,.05); }
    }

    /* ── Insignia de estado "en vivo" ─────────────────── */
    .insignia-vivo {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 5px 12px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 700;
      background: #DCFCE7;
      color: #166534;
      transition: background .3s, color .3s;
    }

    /* ── Nota técnica (cuadro explicativo) ────────────── */
    .nota-tecnica {
      background: linear-gradient(135deg, rgba(107,15,42,.04), rgba(193,154,107,.07));
      border: 1px solid rgba(193,154,107,.3);
      border-radius: 12px;
      padding: 16px 20px;
      font-size: 12px;
      color: #6B7280;
      margin-bottom: 22px;
    }
    .nota-tecnica strong { color: var(--color-primary); }
    .nota-tecnica ul { margin: 8px 0 0 18px; }
    .nota-tecnica li { margin-bottom: 4px; line-height: 1.5; }

    /* ── Estado vacío ─────────────────────────────────── */
    .estado-vacio {
      padding: 24px 18px;
      text-align: center;
      color: var(--color-muted);
      font-size: 13px;
    }
    .estado-vacio span { font-size: 28px; display: block; margin-bottom: 6px; }
  </style>
</head>
<body>

  <!-- ═══════ BARRA DE NAVEGACIÓN ═══════ -->
  <nav class="navbar" role="navigation" aria-label="Navegación principal">
    <a href="index.php" class="logo" aria-label="Bookia inicio">
      <img src="img/logo.png" alt="Bookia" width="46" height="46">
      <span class="logo-text">BOOKIA</span>
    </a>
    <button class="menu-toggle" aria-label="Abrir menú" aria-expanded="false">☰</button>
    <ul role="menubar">
      <li role="none"><a href="index.php" role="menuitem">Inicio</a></li>
      <li class="has-submenu" role="none">
        <a href="catalogo.php" role="menuitem" aria-haspopup="true">Catálogo</a>
        <ul class="submenu" role="menu">
          <li><a href="catalogo.php">📖 Todos los libros</a></li>
          <li><a href="catalogo.php?g=Ficción">📝 Ficción</a></li>
          <li><a href="catalogo.php?g=No+Ficción">🧪 No Ficción</a></li>
          <li><a href="catalogo.php?g=Infantil">🌟 Infantil</a></li>
          <li><a href="catalogo.php?g=Misterio">🔍 Misterio</a></li>
          <li><a href="catalogo.php?g=Ciencia+Ficción">🚀 Ciencia Ficción</a></li>
          <li><a href="catalogo.php?g=Romance">💕 Romance</a></li>
          <li><a href="catalogo.php?g=Historia">🏛️ Historia</a></li>
          <li><a href="catalogo.php?g=Autoayuda">✨ Autoayuda</a></li>
        </ul>
      </li>
      <li class="has-submenu" role="none">
        <a href="servicios.php" role="menuitem" aria-haspopup="true">Servicios</a>
        <ul class="submenu" role="menu">
          <li><a href="reservar.php">📌 Reservar libro</a></li>
          <li><a href="servicios.php#recoger">🏪 Pick Up</a></li>
          <li><a href="servicios.php#devoluciones">↩ Devoluciones</a></li>
        </ul>
      </li>
      <li role="none"><a href="contacto.php" role="menuitem">Contáctanos</a></li>
      <li class="has-submenu" role="none">
        <a href="#" role="menuitem" aria-haspopup="true">Mi Cuenta</a>
        <ul class="submenu" role="menu">
          <li id="nav-profile" style="display:none"><a href="perfil.php">👤 Mi Perfil (<span id="nav-user-label"></span>)</a></li>
          <li id="nav-admin"   style="display:none"><a href="admin.php"><span class="badge-admin">Admin</span> Panel</a></li>
          <li id="nav-login"><a href="login.php" id="nav-login-link">Iniciar Sesión</a></li>
          <li id="nav-register"><a href="registro.php">Registrarse</a></li>
          <li id="nav-logout" style="display:none"><a href="#" id="btn-logout">Cerrar Sesión</a></li>
        </ul>
      </li>
    </ul>
  </nav>

  <!-- ═══════ RUTA DE NAVEGACIÓN ═══════ -->
  <nav class="breadcrumbs" aria-label="Ruta de navegación">
    <ul>
      <li><a href="index.php">Inicio</a></li>
      <li><span class="current">Dashboard</span></li>
    </ul>
  </nav>

  <!-- ═══════ CONTENIDO PRINCIPAL ═══════ -->
  <main class="dash-wrap">

    <!-- Encabezado + botones de acción -->
    <div class="dash-encabezado" data-reveal>
      <div>
        <h2 class="dash-titulo">📊 Dashboard — Actividad en Tiempo Real</h2>
        <p class="dash-subtitulo">
          Usuarios y publicaciones cargados asincrónicamente desde una API pública.
          Haz clic en "💬 Comentarios" de cualquier publicación para cargarlos y comentar.
        </p>
      </div>
      <div class="dash-acciones">
        <span class="insignia-vivo" id="insignia-estado">⏳ Conectando…</span>
        <button class="btn btn-primary btn-magnetic" id="btn-recargar">🔄 Recargar datos</button>
        <button class="btn btn-ghost" id="btn-cancelar" title="Cancela la petición HTTP en curso">✕ Cancelar</button>
      </div>
    </div>

    <!-- Cuadro explicativo de técnicas usadas -->
    <div class="nota-tecnica" data-reveal>
      <strong>¿Qué demuestra esta página?</strong> — Técnicas requeridas por la Práctica 2:
      <ul>
        <li><strong>Carga simultánea:</strong> usuarios y publicaciones se traen con <code>Promise.allSettled()</code> — si uno falla, el otro sigue</li>
        <li><strong>Caché en memoria:</strong> los datos se guardan 2 min; si recargas antes, se sirven sin llamar a la API</li>
        <li><strong>Buscador con debounce:</strong> espera 300 ms tras dejar de escribir para filtrar — sin trabajo innecesario</li>
        <li><strong>Cancelación con AbortController:</strong> el botón "Cancelar" corta la petición HTTP si está en curso</li>
        <li><strong>Comentarios bajo demanda:</strong> se piden a la API solo al hacer clic en "💬 Comentarios"</li>
        <li><strong>Tiempo real con polling:</strong> cada 12 s llega una publicación nueva con prevención de duplicados</li>
      </ul>
    </div>

    <!-- Banners de errores parciales -->
    <div id="contenedor-errores"></div>

    <!-- Tarjetas de estadísticas -->
    <div class="estadisticas" id="estadisticas">
      <div class="cargando">
        <div class="cargando-circulo"></div>Cargando estadísticas…
      </div>
    </div>

    <!-- Barra de búsqueda + filtros -->
    <div class="barra-controles" data-reveal>
      <span style="font-size:18px;color:#9CA3AF">🔍</span>
      <div class="caja-busqueda">
        <input type="search" id="buscador-global"
               placeholder="Buscar usuario o publicación…" autocomplete="off">
      </div>
      <select id="filtro-seccion" class="filtro-select">
        <option value="todos">Todos</option>
        <option value="usuarios">Solo usuarios</option>
        <option value="publicaciones">Solo publicaciones</option>
      </select>
      <select id="filtro-usuario" class="filtro-select">
        <option value="">Todos los autores</option>
      </select>
      <span id="contador-resultados" class="contador-resultados" style="display:none"></span>
    </div>

    <!-- Columnas: usuarios + publicaciones -->
    <div class="columnas">

      <!-- PANEL USUARIOS -->
      <div class="panel dash-card" data-reveal>
        <div class="panel__encabezado">
          <span class="panel__titulo">👥 Usuarios de la API</span>
          <span id="total-usuarios" class="panel-badge">0</span>
        </div>
        <div class="panel__cuerpo" id="lista-usuarios">
          <div class="cargando">
            <div class="cargando-circulo"></div>Cargando usuarios…
          </div>
        </div>
      </div>

      <!-- PANEL PUBLICACIONES + COMENTARIOS EXPANDIBLES -->
      <div class="panel dash-card" data-reveal>
        <div class="panel__encabezado">
          <span class="panel__titulo">📝 Publicaciones — clic en 💬 para comentar</span>
          <span id="total-publicaciones" class="panel-badge">0</span>
        </div>
        <div class="panel__cuerpo" id="lista-publicaciones">
          <div class="cargando">
            <div class="cargando-circulo"></div>Cargando publicaciones…
          </div>
        </div>
      </div>

    </div>

    <!-- PANEL TIEMPO REAL -->
    <div class="panel panel-tiempo-real dash-card" data-reveal style="margin-top:20px">
      <div class="panel__encabezado">
        <span class="panel__titulo">
          ⚡ Publicaciones en tiempo real
          <small style="font-size:10px;color:var(--color-muted);font-weight:400">
            — llega una nueva cada 12 s (polling inteligente)
          </small>
        </span>
        <div style="display:flex;gap:8px;align-items:center">
          <span id="contador-tiempo-real"
                style="font-size:11px;color:var(--color-muted)">0 nuevas</span>
          <button class="btn btn-sm btn-ghost" id="btn-pausar-polling">⏸ Pausar</button>
        </div>
      </div>
      <div class="panel__cuerpo" id="lista-tiempo-real" style="max-height:230px">
        <p style="padding:16px 18px;color:var(--color-muted);font-size:13px">
          Esperando la primera actualización…
        </p>
      </div>
    </div>

  </main>

  <!-- ═══════ PIE DE PÁGINA ═══════ -->
  <footer>
    <div class="footer-inner">
      <div class="footer-brand">
        <h3>📚 Book<span>ia</span></h3>
        <p>Tu librería pick-up de confianza.</p>
      </div>
      <div class="footer-links">
        <h4>Navegación</h4>
        <ul>
          <li><a href="catalogo.php">Catálogo</a></li>
          <li><a href="servicios.php">Servicios</a></li>
          <li><a href="reservar.php">Reservar</a></li>
          <li><a href="contacto.php">Contacto</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <p>&copy; Bookia 2026 · Angela Guadalupe Ropón Campos · IDGS</p>
    </div>
  </footer>

  <!-- Scripts en orden de dependencias -->
  <script src="js/dom.js"></script>
  <script src="js/cache.js"></script>
  <script src="js/api.js"></script>
  <script src="js/animations.js"></script>
  <script src="js/carousel.js"></script>
  <script src="js/data.js"></script>
  <script src="js/ui.js"></script>
  <script src="js/app.js"></script>

  <script>
  /*
   * ═══════════════════════════════════════════════════════════════
   *  CONTROLADOR DEL DASHBOARD — Práctica 2, Partes 2, 5 y 6
   *
   *  Demuestra:
   *   ✓ Carga simultánea con Promise.allSettled  (Parte 2)
   *   ✓ Caché manual en memoria con TTL          (Parte 2)
   *   ✓ Buscador con debounce                   (Parte 2)
   *   ✓ Cancelación de peticiones (AbortController) (Parte 2)
   *   ✓ Comentarios bajo demanda con caché       (Parte 2)
   *   ✓ requestAnimationFrame para DOM           (Parte 5)
   *   ✓ console.time para medir rendimiento      (Parte 5)
   *   ✓ Polling inteligente con duplicados       (Parte 6)
   *   ✓ Animación al llegar datos nuevos         (Parte 6)
   *   ✓ Notificación visual                      (Parte 6)
   * ═══════════════════════════════════════════════════════════════
   */
  (async () => {
    'use strict';

    /* ── Estado centralizado del módulo ─────────────────────────
     * Al tener todos los datos aquí, podemos filtrar y actualizar
     * sin perder información ni repetir peticiones a la API.
     * ────────────────────────────────────────────────────────── */
    const estado = {
      usuarios:            [],      // Lista completa de usuarios de la API
      publicaciones:       [],      // Lista completa de publicaciones de la API
      terminoBusqueda:     '',      // Texto actual del buscador
      seccionActiva:       'todos', // Filtro de sección: todos / usuarios / publicaciones
      filtroUsuario:       '',      // Filtro por userId específico
      temporizadorPolling: null,    // Referencia al setInterval del polling
      pollingActivo:       true,    // Control del polling de tiempo real
      idsVistos:           new Set(), // IDs procesados — evita duplicados en el polling
      comentariosAbiertos: new Set(), // IDs de publicaciones con comentarios visibles
      contadorTiempoReal:  0,       // Cuántas publicaciones nuevas han llegado en vivo
    };

    /* Atajo para obtener elemento por ID */
    const $ = id => document.getElementById(id);

    /* ─────────────────────────────────────────────────────────────
     * ESTADÍSTICAS — Tarjetas superiores
     *
     * Se usa rafBatch() para agrupar todos los cambios DOM
     * en un solo requestAnimationFrame y evitar múltiples reflows.
     * ───────────────────────────────────────────────────────────── */
    function mostrarEstadisticas() {
      const contenedor = $('estadisticas');

      /* Medir tiempo de renderizado (Parte 5: console.time) */
      console.time('[Dashboard] render:estadisticas');

      const datos = [
        { icono: '👥', numero: estado.usuarios.length,      etiqueta: 'Usuarios cargados'       },
        { icono: '📝', numero: estado.publicaciones.length, etiqueta: 'Publicaciones cargadas'   },
        { icono: '⚡', numero: BookiaCache.size(),           etiqueta: 'Registros en caché'       },
        { icono: '✅', numero: estado.idsVistos.size,        etiqueta: 'Elementos únicos vistos'  },
      ];

      /* rafBatch: agrupa cambios en un frame para minimizar reflows */
      BookiaDOM.rafBatch(() => {
        contenedor.innerHTML = datos.map(d => `
          <div class="estadistica-item dash-card">
            <div class="estadistica-icono">${d.icono}</div>
            <div>
              <div class="estadistica-item__numero">${d.numero}</div>
              <div class="estadistica-item__etiqueta">${d.etiqueta}</div>
            </div>
          </div>`).join('');
        console.timeEnd('[Dashboard] render:estadisticas');
      });
    }

    /* ─────────────────────────────────────────────────────────────
     * USUARIOS — Renderizado de la lista
     *
     * Muestra nombre, correo, empresa y ciudad de cada usuario.
     * El avatar usa la primera letra del nombre con gradiente.
     * ───────────────────────────────────────────────────────────── */
    function mostrarUsuarios(lista) {
      const contenedor = $('lista-usuarios');
      const insignia   = $('total-usuarios');

      if (!lista.length) {
        contenedor.innerHTML = `
          <div class="estado-vacio">
            <span>🔍</span>
            Sin usuarios para esa búsqueda.
          </div>`;
        return;
      }

      /* rafBatch: todos los cambios en un solo frame */
      BookiaDOM.rafBatch(() => {
        contenedor.innerHTML = lista.map(u => `
          <div class="usuario-item">
            <div class="usuario-avatar">${u.name[0].toUpperCase()}</div>
            <div class="usuario-info">
              <div class="usuario-nombre">${u.name}</div>
              <div class="usuario-correo" title="${u.email}">${u.email}</div>
              <div class="usuario-empresa">🏢 ${u.company?.name || '—'}</div>
              <div class="usuario-ciudad">📍 ${u.address?.city || '—'}</div>
            </div>
          </div>`).join('');

        /* Mostrar badge con cantidad de usuarios */
        insignia.textContent = lista.length;
        insignia.style.opacity = '1';
      });
    }

    /* ─────────────────────────────────────────────────────────────
     * PUBLICACIONES — Renderizado con botón de comentarios funcional
     *
     * Cada publicación tiene:
     *  - Número de post (#ID)
     *  - Título y extracto del cuerpo
     *  - Nombre del autor (cruzado con la lista de usuarios)
     *  - Botón "💬 Comentarios" que SÍ abre/cierra comentarios
     *
     * Los comentarios NO se cargan aquí — solo cuando el usuario
     * hace clic (lazy loading / carga bajo demanda).
     * ───────────────────────────────────────────────────────────── */
    function mostrarPublicaciones(lista) {
      const contenedor = $('lista-publicaciones');
      const insignia   = $('total-publicaciones');

      if (!lista.length) {
        contenedor.innerHTML = `
          <div class="estado-vacio">
            <span>📭</span>
            Sin publicaciones para esa búsqueda.
          </div>`;
        return;
      }

      /* Mapa userId → nombre para mostrar el autor de cada post */
      const mapaUsuarios = Object.fromEntries(
        estado.usuarios.map(u => [u.id, u.name])
      );

      BookiaDOM.rafBatch(() => {
        contenedor.innerHTML = lista.map(p => `
          <div class="publicacion-item" id="publicacion-${p.id}">

            <!-- Cabecera clicable de la publicación -->
            <div class="publicacion-cabecera">
              <span class="publicacion-num">#${p.id}</span>
              <div style="flex:1;min-width:0">
                <div class="publicacion-titulo">${p.title}</div>
                <div class="publicacion-cuerpo">${p.body}</div>
                <div class="publicacion-meta">
                  <span class="publicacion-autor">
                    ✍️ ${mapaUsuarios[p.userId] || 'Usuario ' + p.userId}
                  </span>
                </div>
              </div>
              <!--
                BOTÓN DE COMENTARIOS — funcional (Corrección de evaluación)
                Al hacer clic:
                  1. Muestra spinner mientras carga
                  2. Pide comentarios a la API (o los sirve de caché)
                  3. Los renderiza con animación escalonada
                  4. Permite añadir un comentario nuevo
              -->
              <button class="btn-comentarios" data-post-id="${p.id}" aria-expanded="false"
                      aria-controls="comentarios-${p.id}">
                <span class="spin-mini" aria-hidden="true"></span>
                💬
                <span class="contador-com">—</span>
              </button>
            </div>

            <!-- Zona de comentarios — usa max-height/opacity, sin display:none -->
            <div class="seccion-comentarios"
                 id="comentarios-${p.id}"
                 role="region"
                 aria-label="Comentarios de la publicación">
            </div>

          </div>`).join('');

        insignia.textContent = lista.length;
        insignia.style.opacity = '1';
      });

      /*
       * Evento delegado: un solo listener en el contenedor
       * para todos los botones de comentarios (eficiente, evita
       * múltiples addEventListener que provocarían memory leaks).
       *
       * Se usa 'click' en el contenedor y se verifica el target
       * para actuar solo cuando se pulsa un .btn-comentarios.
       */
      contenedor.addEventListener('click', e => {
        const btn = e.target.closest('.btn-comentarios');
        if (!btn) return;
        const postId = parseInt(btn.dataset.postId);
        alternarComentarios(postId);
      });
    }

    /* ─────────────────────────────────────────────────────────────
     * ALTERNAR COMENTARIOS — Abrir o cerrar la sección
     *
     * Primera apertura:
     *   1. Muestra spinner en el botón
     *   2. Intenta obtener de caché (BookiaCache.get)
     *   3. Si no hay caché, pide a la API (AbortController interno)
     *   4. Guarda en caché con TTL de 10 minutos
     *   5. Renderiza con animación escalonada
     *
     * Siguientes aperturas (ya en caché):
     *   - Sirve instantáneamente sin petición de red
     *
     * Cierre:
     *   - Quita clase CSS — la transición CSS hace el cierre suave
     * ───────────────────────────────────────────────────────────── */
    async function alternarComentarios(idPublicacion) {
      const seccion  = $(`comentarios-${idPublicacion}`);
      const boton    = document.querySelector(`.btn-comentarios[data-post-id="${idPublicacion}"]`);
      const estaAbierto = estado.comentariosAbiertos.has(idPublicacion);

      if (estaAbierto) {
        /* Cerrar: quitar clase — la transición CSS (max-height + opacity) hace el resto */
        seccion.classList.remove('abierta');
        boton?.classList.remove('activo');
        boton?.setAttribute('aria-expanded', 'false');
        /* Restaurar texto del botón */
        if (boton) {
          const cont = boton.querySelector('.contador-com');
          boton.innerHTML = `<span class="spin-mini" aria-hidden="true"></span>💬 <span class="contador-com">${cont?.textContent || '—'}</span>`;
        }
        estado.comentariosAbiertos.delete(idPublicacion);
        return;
      }

      /* ── Abrir: mostrar spinner mientras carga ─────────────── */
      if (boton) {
        boton.classList.add('cargando');
        const cont = boton.querySelector('.contador-com');
        boton.innerHTML = `<span class="spin-mini" aria-hidden="true" style="display:inline-block"></span> Cargando…`;
      }

      /* Mostrar la sección aunque todavía esté vacía */
      seccion.classList.add('abierta');
      boton?.setAttribute('aria-expanded', 'true');
      estado.comentariosAbiertos.add(idPublicacion);

      /* Mostrar skeleton mientras llegan los datos */
      seccion.innerHTML = `
        <div class="cargando" style="padding:16px 0">
          <div class="cargando-circulo"></div>
          Cargando comentarios…
        </div>`;

      const claveCache = `comentarios-publicacion-${idPublicacion}`;

      try {
        /* getOrFetch: primero revisa caché, si no hay hace la petición */
        console.time(`[Dashboard] comentarios:${idPublicacion}`);
        const comentarios = await BookiaCache.getOrFetch(
          claveCache,
          () => BookiaAPI.getComentarios(idPublicacion),
          10 * 60 * 1000 /* TTL: 10 minutos */
        );
        console.timeEnd(`[Dashboard] comentarios:${idPublicacion}`);

        renderizarComentarios(idPublicacion, comentarios);

        /* Actualizar botón con el conteo real de comentarios */
        if (boton) {
          boton.classList.remove('cargando');
          boton.classList.add('activo');
          boton.innerHTML = `<span class="spin-mini" aria-hidden="true"></span>🔼 <span class="contador-com">${comentarios.length}</span>`;
        }

      } catch (err) {
        /* Error al cargar: mostrar mensaje sin bloquear la UI */
        if (seccion) {
          seccion.innerHTML = `
            <div style="padding:12px 0;color:#991B1B;font-size:12px;display:flex;align-items:center;gap:6px">
              ⚠️ No se pudieron cargar los comentarios: ${err.message}
              <button onclick="alternarComentarios(${idPublicacion})"
                      style="font-size:11px;text-decoration:underline;background:none;border:none;cursor:pointer;color:inherit">
                Reintentar
              </button>
            </div>`;
        }
        if (boton) {
          boton.classList.remove('cargando', 'activo');
          boton.innerHTML = `<span class="spin-mini" aria-hidden="true"></span>💬 <span class="contador-com">!</span>`;
        }
      }
    }

    /* ─────────────────────────────────────────────────────────────
     * RENDERIZAR COMENTARIOS — Con animación escalonada
     *
     * También añade un mini formulario para escribir un comentario
     * nuevo (comentario local — no persiste en la API, pero
     * demuestra interactividad dentro de la sección expandida).
     * ───────────────────────────────────────────────────────────── */
    function renderizarComentarios(idPublicacion, comentarios) {
      const seccion = $(`comentarios-${idPublicacion}`);
      if (!seccion) return;

      seccion.innerHTML = `
        <!-- Cabecera de la sección de comentarios -->
        <div class="comentarios-header">
          <span class="comentarios-titulo">
            💬 ${comentarios.length} comentario${comentarios.length !== 1 ? 's' : ''}
            ${BookiaCache.get(`comentarios-publicacion-${idPublicacion}`) ? ' · <em style="font-weight:400;color:#9CA3AF">desde caché</em>' : ''}
          </span>
        </div>

        <!-- Lista de comentarios -->
        <div id="lista-com-${idPublicacion}">
          ${comentarios.map(c => `
            <div class="comentario-item">
              <div class="comentario-avatar">${c.name[0].toUpperCase()}</div>
              <div>
                <div class="comentario-nombre">${c.name}</div>
                <div class="comentario-correo">${c.email}</div>
                <div class="comentario-cuerpo">${c.body}</div>
              </div>
            </div>`).join('')}
        </div>

        <!-- Formulario para añadir un comentario nuevo (local) -->
        <div class="form-nuevo-comentario">
          <textarea id="nuevo-com-${idPublicacion}"
                    placeholder="Escribe un comentario…"
                    aria-label="Nuevo comentario"></textarea>
          <button onclick="agregarComentarioLocal(${idPublicacion})">
            ✉ Enviar
          </button>
        </div>`;

      /* Animación escalonada: cada comentario aparece 60 ms después del anterior */
      seccion.querySelectorAll('.comentario-item').forEach((item, i) => {
        setTimeout(() => BookiaAnimations.animateIn(item, 'fadeUp'), i * 60);
      });
    }

    /* ─────────────────────────────────────────────────────────────
     * AGREGAR COMENTARIO LOCAL
     *
     * No persiste en la API (JSONPlaceholder es de solo lectura),
     * pero simula la adición y anima la entrada del nuevo ítem.
     * Demuestra manipulación dinámica del DOM con animación.
     * ───────────────────────────────────────────────────────────── */
    window.agregarComentarioLocal = function(idPublicacion) {
      const textarea = $(`nuevo-com-${idPublicacion}`);
      const texto = textarea?.value?.trim();
      if (!texto) return;

      const lista = $(`lista-com-${idPublicacion}`);
      if (!lista) return;

      /* Crear el nuevo elemento de comentario */
      const item = document.createElement('div');
      item.className = 'comentario-item';
      item.innerHTML = `
        <div class="comentario-avatar" style="background:linear-gradient(135deg,var(--color-primary),#8B1A3A);color:#fff">T</div>
        <div>
          <div class="comentario-nombre">Tú (comentario local)</div>
          <div class="comentario-correo">${new Date().toLocaleTimeString('es-MX')}</div>
          <div class="comentario-cuerpo">${texto}</div>
        </div>`;

      /* Insertar al inicio y animar con la API de animaciones */
      lista.insertBefore(item, lista.firstChild);
      BookiaAnimations.animateIn(item, 'pop');

      /* Limpiar textarea */
      textarea.value = '';

      /* Notificación de confirmación */
      BookiaDOM.showToast('💬 Comentario añadido (local)', 'success');

      /* Actualizar contador en el botón */
      const boton = document.querySelector(`.btn-comentarios[data-post-id="${idPublicacion}"]`);
      const contEl = boton?.querySelector('.contador-com');
      if (contEl) {
        const actual = parseInt(contEl.textContent) || 0;
        contEl.textContent = actual + 1;
      }
    };

    /* ─────────────────────────────────────────────────────────────
     * ERRORES PARCIALES — Banner informativo
     *
     * Si usuarios cargaron bien pero publicaciones fallaron,
     * se muestra solo el error de publicaciones sin bloquear nada.
     * Esto es posible gracias a Promise.allSettled().
     * ───────────────────────────────────────────────────────────── */
    function mostrarErrores(errores) {
      const contenedor = $('contenedor-errores');
      if (!errores.length) { contenedor.innerHTML = ''; return; }
      contenedor.innerHTML = errores.map(e =>
        `<div class="banner-error">
           ⚠️ Error al cargar <strong>${e.recurso}</strong>: ${e.error}
         </div>`
      ).join('');
    }

    /* ─────────────────────────────────────────────────────────────
     * FILTRADO EN TIEMPO REAL
     *
     * Se ejecuta cada vez que:
     *  - El usuario escribe en el buscador (vía debounce)
     *  - Cambia el filtro de sección
     *  - Cambia el filtro de autor
     * ───────────────────────────────────────────────────────────── */
    function aplicarFiltro() {
      const busqueda = estado.terminoBusqueda.toLowerCase();
      const seccion  = estado.seccionActiva;
      const userId   = estado.filtroUsuario ? parseInt(estado.filtroUsuario) : null;

      /* Filtrar usuarios según búsqueda */
      const usuariosFiltrados = (seccion === 'publicaciones') ? [] :
        estado.usuarios.filter(u =>
          (!busqueda || u.name.toLowerCase().includes(busqueda) || u.email.toLowerCase().includes(busqueda))
        );

      /* Filtrar publicaciones según búsqueda y autor */
      const publicacionesFiltradas = (seccion === 'usuarios') ? [] :
        estado.publicaciones.filter(p =>
          (!userId || p.userId === userId) &&
          (!busqueda || p.title.toLowerCase().includes(busqueda) || p.body.toLowerCase().includes(busqueda))
        );

      /* Actualizar contador de resultados */
      const contEl = $('contador-resultados');
      if (busqueda || userId) {
        const total = usuariosFiltrados.length + publicacionesFiltradas.length;
        contEl.textContent = `${total} resultado${total !== 1 ? 's' : ''}`;
        contEl.style.display = 'inline-block';
      } else {
        contEl.style.display = 'none';
      }

      /* Renderizar resultados filtrados */
      mostrarUsuarios(seccion === 'publicaciones' ? [] : usuariosFiltrados);
      mostrarPublicaciones(seccion === 'usuarios' ? [] : publicacionesFiltradas);
    }

    /* ─────────────────────────────────────────────────────────────
     * CARGA PRINCIPAL DE DATOS
     *
     * 1. Revisa caché (TTL: 2 minutos)
     * 2. Si no hay caché, llama a BookiaAPI.cargarDashboard()
     *    que usa Promise.allSettled() para usuarios + publicaciones
     * 3. Guarda resultados en estado centralizado
     * 4. Renderiza todo
     * ───────────────────────────────────────────────────────────── */
    async function cargarDatos(forzarActualizacion = false) {
      if (forzarActualizacion) {
        BookiaCache.del('datos-dashboard');
        BookiaDOM.showToast('Recargando datos desde la API…', 'info');
      }

      try {
        console.time('[Dashboard] carga:total');

        const datos = await BookiaCache.getOrFetch(
          'datos-dashboard',
          () => BookiaAPI.cargarDashboard(),
          2 * 60 * 1000 /* TTL: 2 minutos */
        );

        console.timeEnd('[Dashboard] carga:total');

        estado.usuarios      = datos.usuarios;
        estado.publicaciones = datos.publicaciones;

        /* Registrar IDs para que el polling no duplique */
        datos.usuarios.forEach(u => estado.idsVistos.add('u-' + u.id));
        datos.publicaciones.forEach(p => estado.idsVistos.add('p-' + p.id));

        /* Poblar el filtro de autores con los nombres reales */
        const selectAutor = $('filtro-usuario');
        if (selectAutor && estado.usuarios.length) {
          const optsBefore = selectAutor.innerHTML;
          estado.usuarios.forEach(u => {
            const opt = document.createElement('option');
            opt.value = u.id;
            opt.textContent = u.name;
            selectAutor.appendChild(opt);
          });
        }

        mostrarErrores(datos.errores);
        mostrarEstadisticas();
        aplicarFiltro();
        actualizarInsignia(true);

        /* Publicar evento Pub/Sub — otros módulos pueden suscribirse */
        BookiaPubSub.publish('datos:cargados', datos);

      } catch (err) {
        if (err.message.includes('cancelada')) {
          BookiaDOM.showToast('Petición cancelada por el usuario', 'warning');
        } else {
          $('contenedor-errores').innerHTML =
            `<div class="banner-error">❌ ${err.message}</div>`;
          BookiaDOM.showToast('Error al cargar los datos', 'error');
        }
      }
    }

    /* ─────────────────────────────────────────────────────────────
     * POLLING INTELIGENTE — Parte 6
     *
     * Simula actualizaciones en tiempo real cada 12 segundos.
     * "Inteligente" porque:
     *  1. Verifica si el ID ya fue procesado (Set idsVistos)
     *  2. Usa caché para no repetir peticiones HTTP
     *  3. Se puede pausar sin detener el setInterval
     *  4. Anima la entrada de cada elemento nuevo
     *  5. Limita el panel a 20 elementos para no saturar la UI
     * ───────────────────────────────────────────────────────────── */
    async function cicloPolling() {
      if (!estado.pollingActivo) return;

      try {
        const idPost = Math.floor(Math.random() * 100) + 1;
        const clave  = 'tiempo-real-' + idPost;

        /* Si ya vimos este ID en esta sesión, saltar (prevención de duplicados) */
        if (estado.idsVistos.has(clave)) return;
        estado.idsVistos.add(clave);

        /* Obtener post (desde caché si ya se descargó antes) */
        const publicacion = await BookiaCache.getOrFetch(
          clave,
          () => BookiaAPI.request(
            `https://jsonplaceholder.typicode.com/posts/${idPost}`,
            { key: clave }
          ),
          10 * 60 * 1000
        );

        agregarElementoTiempoReal(publicacion);

        /* Notificación visual (Parte 6) */
        BookiaDOM.showToast(
          `📬 Nueva publicación: "${publicacion.title.slice(0, 36)}…"`,
          'new', 3000
        );

      } catch {
        /* Silenciar errores de polling para no interrumpir la UI */
      }
    }

    /* Inserta el elemento nuevo en el panel con animación */
    function agregarElementoTiempoReal(publicacion) {
      const contenedor = $('lista-tiempo-real');
      /* Quitar mensaje inicial "Esperando…" */
      const marcador = contenedor.querySelector('p');
      if (marcador) marcador.remove();

      estado.contadorTiempoReal++;
      const contEl = $('contador-tiempo-real');
      if (contEl) contEl.textContent = `${estado.contadorTiempoReal} nueva${estado.contadorTiempoReal !== 1 ? 's' : ''}`;

      const elemento = document.createElement('div');
      elemento.className = 'elemento-tiempo-real';
      elemento.innerHTML = `
        <span class="punto-vivo"></span>
        <div style="flex:1;min-width:0">
          <strong style="font-size:12px;text-transform:capitalize;display:block;
                         white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
            ${publicacion.title.slice(0, 55)}…
          </strong>
          <div style="font-size:11px;color:var(--color-muted);margin-top:2px">
            Publicación #${publicacion.id}
          </div>
        </div>
        <span style="font-size:11px;color:var(--color-muted);flex-shrink:0">
          ${new Date().toLocaleTimeString('es-MX')}
        </span>`;

      /* Insertar al inicio con animación de entrada (Parte 6) */
      contenedor.insertBefore(elemento, contenedor.firstChild);
      BookiaAnimations.animateIn(elemento, 'fadeLeft');

      /* Limitar a 20 elementos para no saturar la UI */
      const todos = contenedor.querySelectorAll('.elemento-tiempo-real');
      if (todos.length > 20) todos[todos.length - 1].remove();

      /* Actualizar estadísticas (refleja idsVistos actualizado) */
      mostrarEstadisticas();
    }

    function iniciarPolling() {
      estado.temporizadorPolling = setInterval(cicloPolling, 12000);
    }

    /* Actualiza el badge de "● En vivo" o "⏸ Pausado" */
    function actualizarInsignia(activo) {
      const ins = $('insignia-estado');
      if (activo) {
        ins.textContent  = '● En vivo';
        ins.style.background = '#DCFCE7';
        ins.style.color  = '#166534';
      } else {
        ins.textContent  = '⏸ Pausado';
        ins.style.background = '#FEF3C7';
        ins.style.color  = '#92400E';
      }
    }

    /* ─────────────────────────────────────────────────────────────
     * EVENTOS DE LA INTERFAZ
     * ───────────────────────────────────────────────────────────── */

    /*
     * Buscador con debounce (Parte 2):
     * Espera 300 ms tras la última tecla antes de filtrar.
     * Evita procesamiento innecesario cuando se escribe rápido.
     */
    $('buscador-global').addEventListener('input',
      BookiaDOM.debounce(e => {
        estado.terminoBusqueda = e.target.value;
        aplicarFiltro();
      }, 300)
    );

    /* Filtro de sección: todos / usuarios / publicaciones */
    $('filtro-seccion').addEventListener('change', e => {
      estado.seccionActiva = e.target.value;
      aplicarFiltro();
    });

    /* Filtro de autor por userId */
    $('filtro-usuario').addEventListener('change', e => {
      estado.filtroUsuario = e.target.value;
      aplicarFiltro();
    });

    /* Recargar: borra caché y vuelve a pedir frescos a la API */
    $('btn-recargar').addEventListener('click', () => cargarDatos(true));

    /*
     * Cancelar petición con AbortController (Parte 2):
     * Llama a controller.abort() si la petición está en curso.
     * Si ya terminó, no tiene efecto (seguro de llamar siempre).
     */
    $('btn-cancelar').addEventListener('click', () => {
      BookiaAPI.cancel('datos-dashboard');
      BookiaDOM.showToast('Petición cancelada manualmente', 'warning');
    });

    /* Pausar / reanudar el polling de tiempo real */
    $('btn-pausar-polling').addEventListener('click', () => {
      estado.pollingActivo = !estado.pollingActivo;
      const boton = $('btn-pausar-polling');
      if (estado.pollingActivo) {
        boton.textContent = '⏸ Pausar';
        actualizarInsignia(true);
        BookiaDOM.showToast('Actualizaciones en tiempo real reanudadas', 'success');
      } else {
        boton.textContent = '▶ Reanudar';
        actualizarInsignia(false);
        BookiaDOM.showToast('Actualizaciones pausadas', 'warning');
      }
    });

    /* ─────────────────────────────────────────────────────────────
     * ARRANQUE — ejecutado una sola vez al cargar la página
     * ───────────────────────────────────────────────────────────── */
    console.time('[Dashboard] arranque:total');
    await cargarDatos();
    console.timeEnd('[Dashboard] arranque:total');

    /* Activar IntersectionObserver para animaciones de scroll */
    BookiaAnimations.init();

    /* Iniciar polling de tiempo real */
    iniciarPolling();

    /* Primer ciclo inmediato (sin esperar 12 s) */
    setTimeout(cicloPolling, 2000);

  })();
  </script>

</body>
</html>
