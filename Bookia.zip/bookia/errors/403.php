<?php
/**
 * BOOKIA — Error 403 Acceso Prohibido
 */
if (!defined('SITE_ROOT')) {
    define('SITE_ROOT', '/bookia');
}
$user = (function() {
    if (function_exists('session_user')) return session_user();
    return null;
})();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>403 — Acceso denegado | Bookia</title>
  <link rel="stylesheet" href="<?= SITE_ROOT ?>/styles/estilos.css">
  <style>
    body { display:flex; align-items:center; justify-content:center; min-height:100vh; background:var(--color-bg,#f8f5f0); }
    .err-box { text-align:center; padding:60px 40px; background:#fff; border-radius:16px; box-shadow:0 4px 24px rgba(0,0,0,.10); max-width:480px; }
    .err-code { font-size:96px; font-weight:900; color:var(--color-primary,#8b4513); line-height:1; }
    .err-title { font-size:24px; font-weight:700; margin:12px 0 8px; }
    .err-msg { color:#666; margin-bottom:28px; }
    .btn { display:inline-block; padding:12px 28px; background:var(--color-primary,#8b4513); color:#fff; border-radius:8px; text-decoration:none; font-weight:600; }
  </style>
</head>
<body>
  <div class="err-box">
    <div class="err-code">403</div>
    <div class="err-title">Acceso Denegado</div>
    <p class="err-msg">No tienes permisos para acceder a este recurso.<br>
      <?php if ($user): ?>
        Tu rol actual es <strong><?= htmlspecialchars($user['rol']) ?></strong>.
      <?php endif; ?>
    </p>
    <a href="<?= SITE_ROOT ?>/index.php" class="btn">← Volver al inicio</a>
  </div>
</body>
</html>
