<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex">
  <title>404 — Página no encontrada · Bookia</title>
  <link rel="stylesheet" href="../styles/estilos.css">
  <style>
    body { background: #f9f5f0; }
    .error-wrap { min-height: 100vh; display: flex; flex-direction: column; }
    .error-scene { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 80px 24px; text-align: center; background: radial-gradient(ellipse at center, rgba(107,15,42,0.05) 0%, transparent 70%); }
    .error-code { font-size: clamp(80px,18vw,140px); font-weight: 900; line-height: 1; background: linear-gradient(135deg, #6B0F2A, #C19A6B); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; margin-bottom: 8px; font-family: Georgia, serif; }
    .error-icon { font-size: 56px; margin-bottom: 20px; animation: float 3s ease-in-out infinite; }
    @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-12px)} }
    h1 { font-size: 28px; font-weight: 800; color: #1F3A4D; margin-bottom: 12px; }
    .error-desc { color: #6B7280; max-width: 440px; margin: 0 auto 36px; font-size: 16px; line-height: 1.7; }
    .error-links { display: flex; gap: 14px; flex-wrap: wrap; justify-content: center; margin-bottom: 48px; }
    .error-suggestions { background: #fff; border: 1px solid #E8D5C0; border-radius: 16px; padding: 28px 32px; max-width: 500px; width: 100%; text-align: left; }
    .error-suggestions h3 { font-size: 14px; font-weight: 700; color: #6B0F2A; margin-bottom: 14px; text-transform: uppercase; letter-spacing: 0.5px; }
    .error-suggestions ul { list-style: none; }
    .error-suggestions ul li { margin-bottom: 8px; }
    .error-suggestions ul li a { color: #1F3A4D; font-size: 14px; display: flex; align-items: center; gap: 8px; padding: 6px 0; border-bottom: 1px solid #f0ece6; transition: color 0.2s; }
    .error-suggestions ul li a:hover { color: #6B0F2A; }
    .error-code-display { background: #f0ece6; border-radius: 8px; padding: 12px 20px; font-size: 13px; color: #6B7280; margin-top: 16px; font-family: monospace; }
  </style>
</head>
<body class="error-wrap">

  <nav class="navbar" role="navigation" aria-label="Navegación principal">
    <a href="../index.php" class="logo" aria-label="Bookia inicio">
      <img src="../img/logo.png" alt="Bookia" width="46" height="46">
      <span class="logo-text">BOOKIA</span>
    </a>
    <ul>
      <li><a href="../index.php">← Volver al inicio</a></li>
      <li><a href="../catalogo.php">📖 Catálogo</a></li>
      <li><a href="../contacto.php">Contacto</a></li>
    </ul>
  </nav>

  <div class="error-scene">
    <div class="error-icon">🔍</div>
    <div class="error-code">404</div>
    <h1>Página no encontrada</h1>
    <p class="error-desc">
      La página que buscas no existe, fue movida o la dirección fue escrita incorrectamente.
      No te preocupes, esto le pasa a los mejores lectores.
    </p>
    <div class="error-links">
      <a href="../index.php" class="btn">🏠 Ir al inicio</a>
      <a href="../catalogo.php" class="btn btn-ghost">📖 Ver catálogo</a>
      <a href="javascript:history.back()" class="btn btn-ghost">← Regresar</a>
    </div>
    <div class="error-suggestions">
      <h3>🗺️ Páginas principales</h3>
      <ul>
        <li><a href="../index.php"><span>🏠</span> Inicio — Bookia librería pick-up</a></li>
        <li><a href="../catalogo.php"><span>📚</span> Catálogo de libros</a></li>
        <li><a href="../reservar.php"><span>📌</span> Reservar un libro</a></li>
        <li><a href="../servicios.php"><span>🏪</span> Nuestros servicios</a></li>
        <li><a href="../contacto.php"><span>✉️</span> Contáctanos</a></li>
        <li><a href="../login.php"><span>🔑</span> Iniciar sesión</a></li>
      </ul>
      <div class="error-code-display">
        Error 404 · Recurso no encontrado · <strong>bookia.com</strong>
      </div>
    </div>
  </div>

</body>
</html>
