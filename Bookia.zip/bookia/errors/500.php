<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex">
  <title>500 — Error del servidor · Bookia</title>
  <link rel="stylesheet" href="../styles/estilos.css">
  <style>
    body { background: #f9f5f0; }
    .error-wrap { min-height: 100vh; display: flex; flex-direction: column; }
    .error-scene { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 80px 24px; text-align: center; background: radial-gradient(ellipse at center, rgba(107,15,42,0.05) 0%, transparent 70%); }
    .error-code { font-size: clamp(80px,18vw,140px); font-weight: 900; line-height: 1; background: linear-gradient(135deg, #6B0F2A, #C19A6B); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; margin-bottom: 8px; font-family: Georgia, serif; }
    .error-icon { font-size: 56px; margin-bottom: 20px; animation: spin 4s ease-in-out infinite; }
    @keyframes spin { 0%,100%{transform:rotate(-10deg)} 50%{transform:rotate(10deg)} }
    h1 { font-size: 28px; font-weight: 800; color: #1F3A4D; margin-bottom: 12px; }
    .error-desc { color: #6B7280; max-width: 440px; margin: 0 auto 36px; font-size: 16px; line-height: 1.7; }
    .error-links { display: flex; gap: 14px; flex-wrap: wrap; justify-content: center; margin-bottom: 48px; }
    .error-info { background: #fff; border: 1px solid #E8D5C0; border-radius: 16px; padding: 28px 32px; max-width: 500px; width: 100%; }
    .error-info h3 { font-size: 14px; font-weight: 700; color: #6B0F2A; margin-bottom: 14px; text-transform: uppercase; letter-spacing: 0.5px; }
    .error-status { display: flex; align-items: center; gap: 10px; padding: 10px 0; border-bottom: 1px solid #f0ece6; font-size: 14px; color: #4B5563; }
    .status-dot { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }
    .status-dot.green { background: #22c55e; }
    .status-dot.red   { background: #ef4444; animation: pulse 1.5s infinite; }
    .status-dot.yellow{ background: #f59e0b; }
    @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
    .error-code-display { background: #f0ece6; border-radius: 8px; padding: 12px 20px; font-size: 13px; color: #6B7280; margin-top: 16px; font-family: monospace; }
  </style>
</head>
<body class="error-wrap">

  <nav class="navbar" role="navigation" aria-label="Navegación principal">
    <a href="../index.php" class="logo" aria-label="Bookia inicio">
      <img src="../img/logo.png" alt="Bookia" width="46" height="46">
      <span class="logo-text">BOOKIA</span>
    </a>
    <ul>
      <li><a href="../index.php">← Volver al inicio</a></li>
      <li><a href="../contacto.php">Reportar problema</a></li>
    </ul>
  </nav>

  <div class="error-scene">
    <div class="error-icon">⚙️</div>
    <div class="error-code">500</div>
    <h1>Error interno del servidor</h1>
    <p class="error-desc">
      Algo salió mal en nuestro lado. Nuestro equipo ya fue notificado y está trabajando para resolverlo.
      Por favor intenta de nuevo en unos minutos.
    </p>
    <div class="error-links">
      <a href="../index.php" class="btn">🏠 Ir al inicio</a>
      <a href="javascript:location.reload()" class="btn btn-ghost">🔄 Intentar de nuevo</a>
      <a href="../contacto.php" class="btn btn-ghost">✉ Reportar problema</a>
    </div>
    <div class="error-info">
      <h3>⚙️ Estado del sistema</h3>
      <div class="error-status"><div class="status-dot green"></div> Base de datos local (localStorage)</div>
      <div class="error-status"><div class="status-dot red"></div> Servidor de aplicación — Error detectado</div>
      <div class="error-status"><div class="status-dot green"></div> Catálogo estático — Disponible</div>
      <div class="error-status"><div class="status-dot yellow"></div> Servicios de reserva — Verificando</div>
      <div class="error-code-display">
        Error 500 · Internal Server Error · <strong>bookia.com</strong>
      </div>
    </div>
  </div>

</body>
</html>
