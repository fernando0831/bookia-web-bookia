<?php
/**
 * BOOKIA — gen_hash.php
 * Script de utilidad para actualizar los hashes de contraseña.
 *
 * USO: Visita http://localhost/bookia/gen_hash.php en XAMPP
 *      DESPUÉS de importar el SQL.
 *      Borra este archivo cuando termines.
 *
 * SOLO EJECUTAR UNA VEZ.
 */

// Seguridad mínima: solo desde localhost
if (!in_array($_SERVER['REMOTE_ADDR'], ['127.0.0.1', '::1'])) {
    http_response_code(403);
    die('Acceso denegado');
}

require_once __DIR__ . '/api/config.php';

$password = 'Bookia2026';
$hash     = password_hash($password, PASSWORD_DEFAULT);

$db = getDB();
$stmt = $db->prepare('UPDATE usuarios SET password_hash = ?');
$stmt->execute([$hash]);

$rows = $stmt->rowCount();

echo "<h2>✅ Bookia — Hashes actualizados</h2>";
echo "<p>Contraseña: <code>$password</code></p>";
echo "<p>Nuevo hash: <code>$hash</code></p>";
echo "<p>Filas actualizadas: <strong>$rows</strong></p>";
echo "<hr><p style='color:red'><strong>⚠️ BORRA ESTE ARCHIVO INMEDIATAMENTE</strong></p>";
echo "<p>Elimina <code>" . __FILE__ . "</code> después de usarlo.</p>";
