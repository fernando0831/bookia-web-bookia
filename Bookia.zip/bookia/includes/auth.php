<?php
/**
 * BOOKIA — Auth Helper
 * Brute-force, OTP/MFA, password reset, multisesiones,
 * JWT emision/renovacion, CSRF, SSO.
 */

require_once __DIR__ . '/jwt.php';
require_once __DIR__ . '/mailer.php';

// ── Constantes de seguridad ──────────────────────────────────────────────────
if (!defined('MAX_INTENTOS'))      define('MAX_INTENTOS',      5);
if (!defined('BLOQUEO_MIN'))       define('BLOQUEO_MIN',        15);
if (!defined('OTP_MIN'))           define('OTP_MIN',            10);
if (!defined('RESET_MIN'))         define('RESET_MIN',          30);
if (!defined('MAX_INT_OTP'))       define('MAX_INT_OTP',        5);

// ══════════════════════════════════════════════════════════════════════════════
// BRUTE-FORCE
// ══════════════════════════════════════════════════════════════════════════════

/** ¿Cuenta bloqueada por brute-force? */
function cuenta_bloqueada(PDO $pdo, string $email): bool {
    $s = $pdo->prepare('SELECT bloqueado_hasta FROM usuarios WHERE email=? LIMIT 1');
    $s->execute([$email]);
    $r = $s->fetch();
    if (!$r || !$r['bloqueado_hasta']) return false;
    return new DateTime($r['bloqueado_hasta']) > new DateTime();
}

/** Registra intento fallido; bloquea tras MAX_INTENTOS. */
function registrar_intento_fallido(PDO $pdo, string $email): void {
    $s = $pdo->prepare('SELECT id, intentos_fallidos FROM usuarios WHERE email=? LIMIT 1');
    $s->execute([$email]);
    $u = $s->fetch();
    if (!$u) return;
    $n = (int)$u['intentos_fallidos'] + 1;
    if ($n >= MAX_INTENTOS) {
        $hasta = date('Y-m-d H:i:s', strtotime('+'.BLOQUEO_MIN.' minutes'));
        $pdo->prepare('UPDATE usuarios SET intentos_fallidos=?, bloqueado_hasta=? WHERE id=?')
            ->execute([$n, $hasta, $u['id']]);
    } else {
        $pdo->prepare('UPDATE usuarios SET intentos_fallidos=? WHERE id=?')
            ->execute([$n, $u['id']]);
    }
}

/** Limpia contadores tras login exitoso. */
function resetear_intentos(PDO $pdo, string $uid): void {
    $pdo->prepare('UPDATE usuarios SET intentos_fallidos=0, bloqueado_hasta=NULL WHERE id=?')
        ->execute([$uid]);
}

// ══════════════════════════════════════════════════════════════════════════════
// MFA — OTP
// ══════════════════════════════════════════════════════════════════════════════

/** Genera OTP de 6 dígitos, invalida anteriores del mismo tipo. */
function generar_otp(PDO $pdo, string $uid, string $tipo = 'email'): string {
    $pdo->prepare("UPDATE mfa_codes SET usado=1 WHERE usuario_id=? AND tipo=? AND usado=0")
        ->execute([$uid, $tipo]);
    $codigo = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $exp    = date('Y-m-d H:i:s', strtotime('+'.OTP_MIN.' minutes'));
    $pdo->prepare('INSERT INTO mfa_codes (id,usuario_id,codigo,tipo,expires_at) VALUES (?,?,?,?,?)')
        ->execute([uuid(), $uid, $codigo, $tipo, $exp]);
    return $codigo;
}

/** Valida OTP. Devuelve true si correcto (y lo marca usado). */
function validar_otp(PDO $pdo, string $uid, string $codigo, string $tipo = 'email'): bool {
    $s = $pdo->prepare(
        'SELECT id,codigo,intentos FROM mfa_codes
         WHERE usuario_id=? AND tipo=? AND usado=0 AND expires_at>NOW()
         ORDER BY created_at DESC LIMIT 1');
    $s->execute([$uid, $tipo]);
    $r = $s->fetch();
    if (!$r) return false;
    if ((int)$r['intentos'] >= MAX_INT_OTP) {
        $pdo->prepare('UPDATE mfa_codes SET usado=1 WHERE id=?')->execute([$r['id']]);
        return false;
    }
    $pdo->prepare('UPDATE mfa_codes SET intentos=intentos+1 WHERE id=?')->execute([$r['id']]);
    if (!hash_equals($r['codigo'], $codigo)) return false;
    $pdo->prepare('UPDATE mfa_codes SET usado=1 WHERE id=?')->execute([$r['id']]);
    return true;
}

// ══════════════════════════════════════════════════════════════════════════════
// RECUPERACIÓN DE CONTRASEÑA
// ══════════════════════════════════════════════════════════════════════════════

/** Genera token de reset; devuelve el token en texto plano (para el enlace). */
function generar_token_reset(PDO $pdo, string $uid, string $tipo = 'email'): string {
    $pdo->prepare("UPDATE password_resets SET usado=1 WHERE usuario_id=? AND tipo=?")
        ->execute([$uid, $tipo]);
    $token = bin2hex(random_bytes(32));
    $hash  = hash('sha256', $token);
    $exp   = date('Y-m-d H:i:s', strtotime('+'.RESET_MIN.' minutes'));
    $pdo->prepare('INSERT INTO password_resets (id,usuario_id,token_hash,tipo,expires_at) VALUES (?,?,?,?,?)')
        ->execute([uuid(), $uid, $hash, $tipo, $exp]);
    return $token;
}

/** Valida token de reset → devuelve usuario_id o null. */
function validar_token_reset(PDO $pdo, string $token): ?string {
    $hash = hash('sha256', $token);
    $s    = $pdo->prepare(
        'SELECT usuario_id FROM password_resets
         WHERE token_hash=? AND usado=0 AND expires_at>NOW() LIMIT 1');
    $s->execute([$hash]);
    $r = $s->fetch();
    return $r ? $r['usuario_id'] : null;
}

/** Marca token de reset como usado (anti-replay). */
function consumir_token_reset(PDO $pdo, string $token): void {
    $hash = hash('sha256', $token);
    $pdo->prepare('UPDATE password_resets SET usado=1 WHERE token_hash=?')->execute([$hash]);
}

// ══════════════════════════════════════════════════════════════════════════════
// MULTISESIONES
// ══════════════════════════════════════════════════════════════════════════════

/** Registra (o actualiza) la sesión actual en la tabla sessions. */
function registrar_sesion(PDO $pdo, string $uid): void {
    $sid  = session_id();
    $ip   = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
    $ua   = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500);
    $now  = date('Y-m-d H:i:s');
    $pdo->prepare(
        'INSERT INTO sessions (id,usuario_id,ip,user_agent,created_at,last_active,activa)
         VALUES (?,?,?,?,?,?,1)
         ON DUPLICATE KEY UPDATE last_active=?, activa=1')
        ->execute([$sid, $uid, $ip, $ua, $now, $now, $now]);
}

/** Sesiones activas del usuario. */
function listar_sesiones(PDO $pdo, string $uid): array {
    $s = $pdo->prepare(
        'SELECT id,ip,user_agent,created_at,last_active
         FROM sessions WHERE usuario_id=? AND activa=1 ORDER BY last_active DESC');
    $s->execute([$uid]);
    return $s->fetchAll();
}

/** Cierra una sesión específica e invalida sus refresh tokens. */
function cerrar_sesion_bd(PDO $pdo, string $sid, string $uid): void {
    $pdo->prepare('UPDATE sessions SET activa=0 WHERE id=? AND usuario_id=?')->execute([$sid, $uid]);
    $pdo->prepare('UPDATE refresh_tokens SET revocado=1 WHERE session_id=? AND usuario_id=?')->execute([$sid, $uid]);
}

/** Cierra todas las sesiones del usuario excepto la actual. */
function cerrar_otras_sesiones(PDO $pdo, string $uid): void {
    $actual = session_id();
    $pdo->prepare('UPDATE sessions SET activa=0 WHERE usuario_id=? AND id!=?')->execute([$uid, $actual]);
    $pdo->prepare('UPDATE refresh_tokens SET revocado=1 WHERE usuario_id=? AND session_id!=?')->execute([$uid, $actual]);
}

// ══════════════════════════════════════════════════════════════════════════════
// JWT + REFRESH TOKEN
// ══════════════════════════════════════════════════════════════════════════════

/** Emite access_token + refresh_token; guarda refresh hasheado en BD. */
function emitir_tokens(PDO $pdo, array $user): array {
    $payload     = ['id' => $user['id'], 'rol' => $user['rol'], 'sid' => session_id()];
    $accessToken = JWT::encode($payload, JWT_SECRET, JWT_TTL);
    $refresh     = bin2hex(random_bytes(32));
    $rHash       = hash('sha256', $refresh);
    $rExp        = date('Y-m-d H:i:s', time() + JWT_REFRESH_TTL);
    $pdo->prepare(
        'INSERT INTO refresh_tokens (id,usuario_id,token_hash,session_id,expires_at)
         VALUES (?,?,?,?,?)')
        ->execute([uuid(), $user['id'], $rHash, session_id(), $rExp]);
    return ['access_token' => $accessToken, 'refresh_token' => $refresh,
            'expires_in' => JWT_TTL, 'token_type' => 'Bearer'];
}

/** Renueva access_token usando un refresh_token válido. */
function renovar_access_token(PDO $pdo, string $refresh): ?array {
    $hash = hash('sha256', $refresh);
    $s    = $pdo->prepare(
        'SELECT rt.*,u.rol FROM refresh_tokens rt
         JOIN usuarios u ON rt.usuario_id=u.id
         WHERE rt.token_hash=? AND rt.revocado=0 AND rt.expires_at>NOW() LIMIT 1');
    $s->execute([$hash]);
    $r = $s->fetch();
    if (!$r) return null;
    $payload = ['id' => $r['usuario_id'], 'rol' => $r['rol'], 'sid' => $r['session_id']];
    return ['access_token' => JWT::encode($payload, JWT_SECRET, JWT_TTL),
            'expires_in'   => JWT_TTL, 'token_type' => 'Bearer'];
}

/** Extrae payload del Bearer token del header Authorization. */
function bearer_payload(): ?array {
    $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!preg_match('/^Bearer\s+(.+)$/i', $auth, $m)) return null;
    return JWT::decode($m[1], JWT_SECRET);
}

// ══════════════════════════════════════════════════════════════════════════════
// CSRF
// ══════════════════════════════════════════════════════════════════════════════

function csrf_token(): string {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (empty($_SESSION['csrf_token']))
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}

function csrf_verify(): void {
    $tok = $_POST['_csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!hash_equals(csrf_token(), $tok)) {
        http_response_code(403);
        die('Token CSRF inválido. Recarga e intenta de nuevo.');
    }
}

function csrf_field(): string {
    return '<input type="hidden" name="_csrf" value="' . htmlspecialchars(csrf_token(), ENT_QUOTES) . '">';
}

// ══════════════════════════════════════════════════════════════════════════════
// SSO SIMULADO
// ══════════════════════════════════════════════════════════════════════════════

function generar_token_sso(array $user): string {
    return JWT::encode(['id' => $user['id'], 'nombre' => $user['nombre'],
                        'rol' => $user['rol'], 'sso' => true], JWT_SECRET, 60);
}

function validar_token_sso(string $token): ?array {
    $p = JWT::decode($token, JWT_SECRET);
    if (!$p || empty($p['sso'])) return null;
    return $p;
}
