<?php
/**
 * BOOKIA — Configuración global
 */
define('DB_HOST',    'localhost');
define('DB_NAME',    'bookia');
define('DB_USER',    'root');
define('DB_PASS',    '');
define('DB_CHARSET', 'utf8mb4');
define('SITE_ROOT',  '/bookia');   // Cambia si tu carpeta se llama distinto

function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $pdo = new PDO(
        'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset='.DB_CHARSET,
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
         PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
         PDO::ATTR_EMULATE_PREPARES=>false]
    );
    return $pdo;
}

function uuid(): string {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0,0xffff),mt_rand(0,0xffff),mt_rand(0,0xffff),
        mt_rand(0,0x0fff)|0x4000,mt_rand(0,0x3fff)|0x8000,
        mt_rand(0,0xffff),mt_rand(0,0xffff),mt_rand(0,0xffff));
}

function generarCodigo(): string {
    $l='ABCDEFGHJKLMNPQRSTUVWXYZ'; $n='0123456789';
    $rl=fn()=>$l[random_int(0,strlen($l)-1)];
    $rn=fn()=>$n[random_int(0,9)];
    return "BKA-{$rl()}{$rl()}{$rn()}{$rn()}-{$rl()}{$rn()}{$rl()}";
}

function url(string $path = ''): string {
    return SITE_ROOT . ($path ? '/' . ltrim($path, '/') : '');
}

function redirect(string $path): never {
    header('Location: ' . url($path));
    exit;
}

function e(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8');
}
