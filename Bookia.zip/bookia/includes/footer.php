<?php
// Leer idioma para footer
$_ft_idioma = $idioma ?? ($GLOBALS['idioma'] ?? 'es');
$_ft_en = $_ft_idioma === 'en';
?>
<footer>
  <div class="footer-inner">
    <div class="footer-brand">
      <h3>📚 Book<span>ia</span></h3>
      <p><?= $_ft_en ? 'Your trusted pick-up bookstore.<br>Reserve online, pick up whenever you want.' : 'Tu librería pick-up de confianza.<br>Reserva en línea, recoge cuando quieras.' ?></p>
    </div>
    <div class="footer-links">
      <h4><?= $_ft_en ? 'Navigation' : 'Navegación' ?></h4>
      <ul>
        <li><a href="<?= url('catalogo.php') ?>"><?= $_ft_en ? 'Catalogue' : 'Catálogo' ?></a></li>
        <li><a href="<?= url('servicios.php') ?>"><?= $_ft_en ? 'Services' : 'Servicios' ?></a></li>
        <li><a href="<?= url('reservar.php') ?>"><?= $_ft_en ? 'Reserve' : 'Reservar' ?></a></li>
        <li><a href="<?= url('contacto.php') ?>"><?= $_ft_en ? 'Contact' : 'Contacto' ?></a></li>
      </ul>
    </div>
    <div class="footer-links">
      <h4><?= $_ft_en ? 'My Account' : 'Mi Cuenta' ?></h4>
      <ul>
        <?php if (is_logged_in()): ?>
          <li><a href="<?= url(is_admin() ? 'admin.php' : 'perfil.php') ?>"><?= $_ft_en ? 'My Profile' : 'Mi Perfil' ?></a></li>
          <li><a href="<?= url('logout.php') ?>"><?= $_ft_en ? 'Log Out' : 'Cerrar Sesión' ?></a></li>
        <?php else: ?>
          <li><a href="<?= url('login.php') ?>"><?= $_ft_en ? 'Log In' : 'Iniciar Sesión' ?></a></li>
          <li><a href="<?= url('registro.php') ?>"><?= $_ft_en ? 'Sign Up' : 'Registrarse' ?></a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
  <div class="footer-bottom">
    <p>&copy; Bookia 2026 · <?= $_ft_en ? 'Developed by' : 'Desarrollado por' ?> <strong>Angela Guadalupe Ropón Campos</strong> · <?= $_ft_en ? 'Software Development and Management Engineering' : 'Ingeniería en Desarrollo y Gestión de Software' ?></p>
  </div>
</footer>

<script src="<?= url('js/animations.js') ?>"></script>
<script src="<?= url('js/carousel.js') ?>"></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.menu-toggle');
  const nav    = document.querySelector('.navbar > ul');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', nav.classList.contains('open'));
    });
    document.addEventListener('click', e => {
      if (!e.target.closest('.navbar')) { nav.classList.remove('open'); }
    });
    document.querySelectorAll('.has-submenu > a').forEach(a => {
      a.addEventListener('click', e => {
        if (window.innerWidth <= 768) { e.preventDefault(); a.parentElement.classList.toggle('open'); }
      });
    });
  }
  if (document.querySelector('.bk-carousel')) {
    new BookiaCarousel('.bk-carousel', { autoplay: true, interval: 4500 });
  }
  if (typeof BookiaAnimations !== 'undefined') BookiaAnimations.init();
});
</script>
<?= $extraScript ?? '' ?>
</body>
</html>
