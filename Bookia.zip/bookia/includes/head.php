<?php
/**
 * BOOKIA — includes/head.php
 * Partial compartido: <head> con CSS de styles/
 */
if (!isset($pageTitle))       $pageTitle       = 'Bookia — Reserva, recoge y lee';
if (!isset($pageDescription)) $pageDescription = 'Bookia - Librería Pick Up. Reserva tus libros favoritos en línea y recógelos cuando quieras.';
if (!isset($extraCss))        $extraCss        = '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="<?= htmlspecialchars($pageDescription) ?>">
  <meta name="keywords" content="librería, libros, pick up, reserva, lectura, Bookia">
  <meta name="author" content="Angela Guadalupe Ropón Campos">
  <title><?= htmlspecialchars($pageTitle) ?></title>
  <link rel="stylesheet" href="styles/estilos.css">
  <link rel="stylesheet" href="styles/base.css">
  <link rel="stylesheet" href="styles/animations.css">
  <?php if ($extraCss): ?>
  <style><?= $extraCss ?></style>
  <?php endif; ?>
</head>
<body>
