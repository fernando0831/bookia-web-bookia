<?php
/**
 * BOOKIA — Navbar y head HTML
 * Variables esperadas: $pageTitle, $pageDesc (opcionales)
 */
$pageTitle = $pageTitle ?? 'Bookia — Reserva, recoge y lee';
$pageDesc  = $pageDesc  ?? 'Tu librería pick-up favorita. Reserva libros en línea y recógelos cuando quieras.';
$u = session_user();

// ── Leer preferencias del usuario ────────────────────────────────────────────
$temaOscuro = (int)($u['tema_oscuro'] ?? 0);
$idioma     = $u['idioma'] ?? 'es';

// Si cambiaron preferencias en seguridad.php, actualizar sesión en vivo
if ($u && isset($_SESSION['bookia_user'])) {
    try {
        $pref = db()->prepare('SELECT tema_oscuro, idioma FROM usuarios WHERE id=? LIMIT 1');
        $pref->execute([$u['id']]);
        $row = $pref->fetch();
        if ($row) {
            $_SESSION['bookia_user']['tema_oscuro'] = (int)$row['tema_oscuro'];
            $_SESSION['bookia_user']['idioma']      = $row['idioma'];
            $temaOscuro = (int)$row['tema_oscuro'];
            $idioma     = $row['idioma'];
        }
    } catch (Exception $e) {}
}

$dataTheme = $temaOscuro ? 'dark' : 'light';
$htmlLang  = $idioma === 'en' ? 'en' : 'es';
?>
<!DOCTYPE html>
<html lang="<?= $htmlLang ?>" data-theme="<?= $dataTheme ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="<?= e($pageDesc) ?>">
  <title><?= e($pageTitle) ?></title>
  <link rel="stylesheet" href="<?= url('css/base.css') ?>">
  <link rel="stylesheet" href="<?= url('css/estilos.css') ?>">
  <link rel="stylesheet" href="<?= url('css/animations.css') ?>">
</head>
<body>

<nav class="navbar" role="navigation" aria-label="Navegación principal">
  <a href="<?= url('index.php') ?>" class="logo" aria-label="Bookia inicio">
    <img src="<?= url('img/logo.png') ?>" alt="Bookia" width="46" height="46">
    <span class="logo-text">BOOKIA</span>
  </a>
  <button class="menu-toggle" aria-label="Abrir menú" aria-expanded="false">☰</button>
  <ul role="menubar">
    <li><a href="<?= url('index.php') ?>"><?= $idioma==='en' ? 'Home' : 'Inicio' ?></a></li>
    <li class="has-submenu">
      <a href="<?= url('catalogo.php') ?>" aria-haspopup="true"><?= $idioma==='en' ? 'Catalogue' : 'Catálogo' ?></a>
      <ul class="submenu">
        <li><a href="<?= url('catalogo.php') ?>">📖 <?= $idioma==='en' ? 'All Books' : 'Todos los libros' ?></a></li>
        <li><a href="<?= url('catalogo.php?g=Ficción') ?>">📝 <?= $idioma==='en' ? 'Fiction' : 'Ficción' ?></a></li>
        <li><a href="<?= url('catalogo.php?g=No+Ficción') ?>">🧪 <?= $idioma==='en' ? 'Non-Fiction' : 'No Ficción' ?></a></li>
        <li><a href="<?= url('catalogo.php?g=Infantil') ?>">🌟 <?= $idioma==='en' ? 'Children' : 'Infantil' ?></a></li>
        <li><a href="<?= url('catalogo.php?g=Misterio') ?>">🔍 <?= $idioma==='en' ? 'Mystery' : 'Misterio' ?></a></li>
        <li><a href="<?= url('catalogo.php?g=Ciencia+Ficción') ?>">🚀 <?= $idioma==='en' ? 'Sci-Fi' : 'Ciencia Ficción' ?></a></li>
        <li><a href="<?= url('catalogo.php?g=Romance') ?>">💕 Romance</a></li>
        <li><a href="<?= url('catalogo.php?g=Historia') ?>">🏛️ <?= $idioma==='en' ? 'History' : 'Historia' ?></a></li>
        <li><a href="<?= url('catalogo.php?g=Autoayuda') ?>">✨ <?= $idioma==='en' ? 'Self-Help' : 'Autoayuda' ?></a></li>
      </ul>
    </li>
    <li class="has-submenu">
      <a href="<?= url('servicios.php') ?>" aria-haspopup="true"><?= $idioma==='en' ? 'Services' : 'Servicios' ?></a>
      <ul class="submenu">
        <li><a href="<?= url('reservar.php') ?>">📌 <?= $idioma==='en' ? 'Reserve a Book' : 'Reservar libro' ?></a></li>
        <li><a href="<?= url('servicios.php') ?>">🏪 Pick Up</a></li>
      </ul>
    </li>
    <li><a href="<?= url('contacto.php') ?>"><?= $idioma==='en' ? 'Contact' : 'Contáctanos' ?></a></li>
    <li class="has-submenu">
      <a href="#" aria-haspopup="true"><?= $idioma==='en' ? 'My Account' : 'Mi Cuenta' ?></a>
      <ul class="submenu">
        <?php if ($u): ?>
          <?php if (in_array($u['rol'], ['admin','superadmin'])): ?>
            <li><a href="<?= url('admin.php') ?>">
              <span class="badge-admin"><?= $u['rol'] === 'superadmin' ? '⭐ Super Admin' : 'Admin' ?></span> Panel
            </a></li>
          <?php else: ?>
            <li><a href="<?= url('perfil.php') ?>">👤 <?= e($u['nombre']) ?></a></li>
          <?php endif; ?>
          <li><a href="<?= url('logout.php') ?>">🚪 <?= $idioma==='en' ? 'Log Out' : 'Cerrar Sesión' ?></a></li>
        <?php else: ?>
          <li><a href="<?= url('login.php') ?>"><?= $idioma==='en' ? 'Log In' : 'Iniciar Sesión' ?></a></li>
          <li><a href="<?= url('registro.php') ?>"><?= $idioma==='en' ? 'Sign Up' : 'Registrarse' ?></a></li>
        <?php endif; ?>
      </ul>
    </li>
  </ul>
</nav>

<?php if ($u): ?>
<!-- Banner de sesión revocada remotamente -->
<div id="session-revoked-banner" style="display:none;" role="alert" aria-live="assertive">
  <span id="session-revoked-msg">
    <?= $idioma === 'en'
        ? '⚠️ Your session was closed. Redirecting to login…'
        : '⚠️ Tu sesión fue cerrada. Redirigiendo al login…' ?>
  </span>
  <span id="session-revoked-countdown"></span>
</div>

<script>
(function () {
  'use strict';

  var CHECK_INTERVAL = 15000; // 15 segundos (igual que OnePiece)
  var REDIRECT_DELAY  = 3000; // 3 segundos antes de redirigir
  var endpoint = '<?= rtrim(url('api/auth.php'), '/') ?>?action=check_session';
  var loginUrl  = '<?= url('login.php') ?>';
  var banner    = document.getElementById('session-revoked-banner');
  var countdown = document.getElementById('session-revoked-countdown');
  var timer     = null;

  function showBannerAndRedirect() {
    if (banner) banner.style.display = 'flex';
    var secs = Math.ceil(REDIRECT_DELAY / 1000);
    var tick = setInterval(function () {
      secs--;
      if (countdown) countdown.textContent = ' (' + secs + ')';
      if (secs <= 0) {
        clearInterval(tick);
        window.location.href = loginUrl;
      }
    }, 1000);
    // Redirigir tras el delay aunque el intervalo falle
    setTimeout(function () { window.location.href = loginUrl; }, REDIRECT_DELAY + 200);
  }

  function checkSession() {
    fetch(endpoint, { method: 'GET', credentials: 'same-origin' })
      .then(function (res) {
        if (!res.ok) return; // error de red — no desloguear preventivamente
        return res.json();
      })
      .then(function (data) {
        if (data && data.activa === false) {
          clearInterval(timer);
          showBannerAndRedirect();
        }
      })
      .catch(function () { /* silenciar errores de red */ });
  }

  // Pausar polling cuando la pestaña está oculta (igual que OnePiece)
  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'hidden') {
      clearInterval(timer);
      timer = null;
    } else {
      if (!timer) timer = setInterval(checkSession, CHECK_INTERVAL);
      checkSession(); // verificar inmediatamente al volver a la pestaña
    }
  });

  // Iniciar polling al cargar la página
  timer = setInterval(checkSession, CHECK_INTERVAL);
})();
</script>
<?php endif; ?>
