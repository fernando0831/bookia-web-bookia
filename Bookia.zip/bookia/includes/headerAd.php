<?php
/**
 * BOOKIA — Navbar y head HTML
 * Variables esperadas: $pageTitle, $pageDesc (opcionales)
 */
$pageTitle = $pageTitle ?? 'Bookia — Reserva, recoge y lee';
$pageDesc  = $pageDesc  ?? 'Tu librería pick-up favorita. Reserva libros en línea y recógelos cuando quieras.';
$u = session_user();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="<?= e($pageDesc) ?>">
  <title><?= e($pageTitle) ?></title>
  <link rel="stylesheet" href="<?= url('css/estilos.css') ?>">
  <link rel="stylesheet" href="<?= url('css/base.css') ?>">
  <link rel="stylesheet" href="<?= url('css/animations.css') ?>">
</head>
<body>

<nav class="navbar" role="navigation" aria-label="Navegación principal">
  <a href="<?= url('index.php') ?>" class="logo" aria-label="Bookia inicio">
    <img src="<?= url('img/logo.png') ?>" alt="Bookia" width="46" height="46">
    <span class="logo-text">BOOKIA</span>
  </a>
  <button class="menu-toggle" aria-label="Abrir menú" aria-expanded="false">☰</button>
  <ul role="menubar">
    <li><a href="<?= url('index.php') ?>">Inicio</a></li>
    <li class="has-submenu">
      <a href="#" aria-haspopup="true">Mi Cuenta</a>
      <ul class="submenu">
        <?php if ($u): ?>
          <?php if ($u['rol'] === 'admin'): ?>
            <li><a href="<?= url('admin.php') ?>"><span class="badge-admin">Admin</span>
          <?php else: ?>
            <li><a href="<?= url('perfil.php') ?>">👤 <?= e($u['nombre']) ?></a></li>
          <?php endif; ?>
          <li><a href="<?= url('logout.php') ?>">🚪 Cerrar Sesión</a></li>
        <?php else: ?>
          <li><a href="<?= url('login.php') ?>">Iniciar Sesión</a></li>
          <li><a href="<?= url('registro.php') ?>">Registrarse</a></li>
        <?php endif; ?>
      </ul>
    </li>
  </ul>
</nav>
