<?php
/**
 * BOOKIA — JWT Helper (HS256 puro PHP, sin librerías externas)
 * RFC 7519
 */

if (!defined('JWT_SECRET'))      define('JWT_SECRET',      'B00k1a_JWT_S3cr3t_2026_IDGS8B!@#$%');
if (!defined('JWT_TTL'))         define('JWT_TTL',          900);       // 15 min access token
if (!defined('JWT_REFRESH_TTL')) define('JWT_REFRESH_TTL',  604800);    // 7 días refresh token

class JWT {
    /**
     * Genera un JWT firmado HS256.
     * @param array  $payload  Datos (NO incluir contraseñas)
     * @param string $secret   Clave HMAC
     * @param int    $ttl      Segundos de validez (0 = sin expiración)
     */
    public static function encode(array $payload, string $secret, int $ttl = 0): string {
        $header = self::b64u(json_encode(['alg'=>'HS256','typ'=>'JWT']));
        $now = time();
        $payload['iat'] = $now;
        if ($ttl > 0) $payload['exp'] = $now + $ttl;
        $body = self::b64u(json_encode($payload));
        $sig  = self::b64u(hash_hmac('sha256', "$header.$body", $secret, true));
        return "$header.$body.$sig";
    }

    /**
     * Decodifica y valida un JWT.
     * @return array|null  Payload o null si inválido/expirado
     */
    public static function decode(string $token, string $secret): ?array {
        $p = explode('.', $token);
        if (count($p) !== 3) return null;
        [$h, $b, $s] = $p;
        // Verificar firma en tiempo constante (anti timing-attack)
        $expected = self::b64u(hash_hmac('sha256', "$h.$b", $secret, true));
        if (!hash_equals($expected, $s)) return null;
        $payload = json_decode(self::b64d($b), true);
        if (!is_array($payload)) return null;
        // Verificar expiración
        if (isset($payload['exp']) && $payload['exp'] < time()) return null;
        return $payload;
    }

    private static function b64u(string $d): string {
        return rtrim(strtr(base64_encode($d), '+/', '-_'), '=');
    }
    private static function b64d(string $d): string {
        return base64_decode(strtr($d, '-_', '+/') . str_repeat('=', 3 - (3 + strlen($d)) % 4));
    }
}
