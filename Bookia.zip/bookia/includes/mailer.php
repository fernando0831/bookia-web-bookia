<?php
/**
 * BOOKIA — Mailer + SMS/Llamada simulados
 * Producción: reemplazar enviar() con PHPMailer+SMTP,
 *             sms() con Twilio, llamada() con Twilio Voice.
 * Desarrollo: todo queda en mail_log.txt (raíz del proyecto).
 */
class Mailer {
    private static string $log = __DIR__ . '/../mail_log.txt';

    // ── helpers internos ─────────────────────────────────────────────────────
    private static function append(string $entry): void {
        file_put_contents(self::$log, $entry, FILE_APPEND | LOCK_EX);
    }

    private static function linea(string $c = '─', int $n = 58): string {
        return str_repeat($c, $n);
    }

    // ── Correo ───────────────────────────────────────────────────────────────
    public static function enviar(string $to, string $subject, string $html): void {
        $sep   = self::linea('═');
        $entry = "\n$sep\n"
               . "[" . date('Y-m-d H:i:s') . "] 📧 CORREO SIMULADO\n"
               . "Para   : $to\n"
               . "Asunto : $subject\n"
               . self::linea() . "\n"
               . strip_tags(str_replace(['<br>','<br/>','</p>','</div>'], "\n", $html)) . "\n";
        self::append($entry);

        $h  = "MIME-Version: 1.0\r\nContent-type: text/html; charset=UTF-8\r\n";
        $h .= "From: Bookia <no-reply@bookia.com>\r\n";
        @mail($to, $subject, $html, $h);
    }

    // ── SMS simulado ─────────────────────────────────────────────────────────
    public static function sms(string $tel, string $msg): void {
        $ts   = date('H:i');
        $sep  = self::linea('═');
        $line = self::linea();

        // Formatear teléfono enmascarado: +52 *** *** 4521
        $masked = self::maskPhone($tel);

        // Burbuja de mensaje estilo SMS
        $burbuja = self::wrapBubble($msg, 42);

        $entry = "\n$sep\n"
               . "[" . date('Y-m-d H:i:s') . "] 📱 SMS SIMULADO — Bookia\n"
               . "$line\n"
               . "  Destinatario : $masked\n"
               . "  Remitente    : Bookia (shortcode 55200)\n"
               . "$line\n"
               . "\n"
               . "  ┌─────────────────────────────────────────────┐\n"
               . "  │  📱 Mensajes         Bookia         $ts      │\n"
               . "  ├─────────────────────────────────────────────┤\n";

        foreach ($burbuja as $linea_burbuja) {
            $entry .= "  │  $linea_burbuja  │\n";
        }

        $entry .= "  │                                      ✓✓ leído │\n"
               . "  └─────────────────────────────────────────────┘\n"
               . "\n"
               . "  [NOTA DEV] En producción esto usaría Twilio SMS API:\n"
               . "             POST https://api.twilio.com/2010-04-01/Accounts/{SID}/Messages\n"
               . "             To=$tel  From=+15005550006  Body=\"$msg\"\n"
               . "$sep\n";

        self::append($entry);
    }

    // ── Llamada simulada ─────────────────────────────────────────────────────
    public static function llamada(string $tel, string $codigo): void {
        $ts      = date('H:i:s');
        $sep     = self::linea('═');
        $line    = self::linea();
        $masked  = self::maskPhone($tel);
        $digitos = implode('  ', str_split($codigo)); // "1  2  3  4  5  6"
        $duracion = rand(18, 28); // segundos simulados

        $entry = "\n$sep\n"
               . "[" . date('Y-m-d H:i:s') . "] 📞 LLAMADA SIMULADA — Bookia\n"
               . "$line\n"
               . "  Destinatario : $masked\n"
               . "  Iniciada a   : $ts\n"
               . "  Duración     : {$duracion}s  (simulada)\n"
               . "$line\n"
               . "\n"
               . "  ╔═════════════════════════════════════════════╗\n"
               . "  ║   📞  LLAMADA ENTRANTE — Bookia             ║\n"
               . "  ╠═════════════════════════════════════════════╣\n"
               . "  ║                                             ║\n"
               . "  ║   [RING... RING...]  → Contestado ✓         ║\n"
               . "  ║                                             ║\n"
               . "  ║   🤖 VOZ AUTOMATIZADA:                      ║\n"
               . "  ║                                             ║\n"
               . "  ║   \"Hola. Te llama Bookia.                   ║\n"
               . "  ║    Tu código de verificación es:            ║\n"
               . "  ║                                             ║\n"
               . "  ║        $digitos              ║\n"
               . "  ║                                             ║\n"
               . "  ║    Repito:  $digitos         ║\n"
               . "  ║                                             ║\n"
               . "  ║    No compartas este código con nadie.\"     ║\n"
               . "  ║                                             ║\n"
               . "  ║   [Llamada finalizada — {$duracion}s]               ║\n"
               . "  ╚═════════════════════════════════════════════╝\n"
               . "\n"
               . "  [NOTA DEV] En producción esto usaría Twilio Voice + TwiML:\n"
               . "             <Say voice=\"alice\" language=\"es-MX\">Tu código es $codigo</Say>\n"
               . "$sep\n";

        self::append($entry);
    }

    // ── Helpers privados ─────────────────────────────────────────────────────
    private static function maskPhone(string $tel): string {
        $clean = preg_replace('/\D/', '', $tel);
        $len   = strlen($clean);
        if ($len >= 7) {
            return substr($clean, 0, max(1, $len - 6))
                 . str_repeat('*', 3) . ' *** '
                 . substr($clean, -4);
        }
        return $tel ?: '(sin teléfono)';
    }

    /** Parte el mensaje en líneas de $width chars, paddeadas con espacios */
    private static function wrapBubble(string $msg, int $width): array {
        $words  = explode(' ', $msg);
        $lines  = [];
        $actual = '';
        foreach ($words as $w) {
            if (strlen($actual) + strlen($w) + 1 > $width) {
                $lines[] = str_pad($actual, $width);
                $actual  = $w;
            } else {
                $actual = $actual === '' ? $w : "$actual $w";
            }
        }
        if ($actual !== '') $lines[] = str_pad($actual, $width);
        return $lines;
    }

    // ── Templates HTML ───────────────────────────────────────────────────────
    public static function htmlMFA(string $nombre, string $codigo, int $min = 10): string {
        return "<div style='font-family:sans-serif;max-width:480px;margin:auto'>
          <div style='background:#6B0F2A;padding:24px;text-align:center;border-radius:12px 12px 0 0'>
            <h1 style='color:#fff;margin:0'>📚 Bookia</h1></div>
          <div style='background:#fff;padding:32px;border:1px solid #e5e7eb;border-radius:0 0 12px 12px'>
            <p>Hola <strong>" . htmlspecialchars($nombre) . "</strong>, tu código de verificación es:</p>
            <div style='background:#f3f4f6;border-radius:10px;padding:20px;text-align:center;margin:20px 0'>
              <span style='font-size:40px;font-weight:900;letter-spacing:10px;color:#6B0F2A'>$codigo</span></div>
            <p style='color:#6B7280;font-size:13px'>Expira en <strong>$min minutos</strong>. No lo compartas.</p>
          </div></div>";
    }

    public static function htmlReset(string $nombre, string $link, int $min = 30): string {
        return "<div style='font-family:sans-serif;max-width:480px;margin:auto'>
          <div style='background:#6B0F2A;padding:24px;text-align:center;border-radius:12px 12px 0 0'>
            <h1 style='color:#fff;margin:0'>📚 Bookia</h1></div>
          <div style='background:#fff;padding:32px;border:1px solid #e5e7eb;border-radius:0 0 12px 12px'>
            <p>Hola <strong>" . htmlspecialchars($nombre) . "</strong>, solicitaste recuperar tu contraseña.</p>
            <div style='text-align:center;margin:28px 0'>
              <a href='$link' style='background:#6B0F2A;color:#fff;padding:14px 28px;border-radius:8px;text-decoration:none;font-weight:700'>
                Restablecer contraseña</a></div>
            <p style='color:#6B7280;font-size:13px'>Expira en <strong>$min minutos</strong>. Si no lo solicitaste, ignora este mensaje.</p>
          </div></div>";
    }
}
