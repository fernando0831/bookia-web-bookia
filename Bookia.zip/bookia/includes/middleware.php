<?php
/**
 * BOOKIA — Middleware de Seguridad Avanzado
 * Práctica 2 Unidad 3 — IDGS 8B
 *
 * Implementa:
 *  - Security headers (XSS, CSRF, Clickjacking)
 *  - Rate limiting por IP (en sesión/archivo)
 *  - Sanitización de inputs (Anti SQL Injection / XSS)
 *  - RBAC: control de acceso por roles
 *  - ABAC: control basado en atributos
 *  - Registro de auditoría
 */

if (!defined('SITE_ROOT')) require_once __DIR__ . '/config.php';

// ══════════════════════════════════════════════════════════════════════════════
// JERARQUÍA DE ROLES (RBAC)
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Peso numérico de cada rol: mayor número = más privilegios.
 * SUPERADMIN > ADMIN > EDITOR > USUARIO
 */
const ROLES_JERARQUIA = [
    'superadmin' => 4,
    'admin'      => 3,
    'editor'     => 2,
    'usuario'    => 1,
];

/**
 * Permisos granulares por rol (RBAC).
 * Cada clave es un permiso; true = tiene acceso.
 */
const ROLES_PERMISOS = [
    'superadmin' => [
        'ver_usuarios'       => true,
        'crear_usuarios'     => true,
        'editar_usuarios'    => true,
        'eliminar_usuarios'  => true,
        'cambiar_rol'        => true,
        'ver_libros'         => true,
        'crear_libros'       => true,
        'editar_libros'      => true,
        'eliminar_libros'    => true,
        'ver_reservas'       => true,
        'editar_reservas'    => true,
        'eliminar_reservas'  => true,
        'ver_auditoria'      => true,
        'ver_seguridad'      => true,
        'config_sistema'     => true,
    ],
    'admin' => [
        'ver_usuarios'       => true,
        'crear_usuarios'     => true,
        'editar_usuarios'    => true,
        'eliminar_usuarios'  => true,
        'cambiar_rol'        => false,  // solo superadmin puede cambiar rol
        'ver_libros'         => true,
        'crear_libros'       => true,
        'editar_libros'      => true,
        'eliminar_libros'    => true,
        'ver_reservas'       => true,
        'editar_reservas'    => true,
        'eliminar_reservas'  => true,
        'ver_auditoria'      => true,
        'ver_seguridad'      => false,
        'config_sistema'     => false,
    ],
    'editor' => [
        'ver_usuarios'       => false,
        'crear_usuarios'     => false,
        'editar_usuarios'    => false,
        'eliminar_usuarios'  => false,
        'cambiar_rol'        => false,
        'ver_libros'         => true,
        'crear_libros'       => true,
        'editar_libros'      => true,
        'eliminar_libros'    => false,
        'ver_reservas'       => true,
        'editar_reservas'    => false,
        'eliminar_reservas'  => false,
        'ver_auditoria'      => false,
        'ver_seguridad'      => false,
        'config_sistema'     => false,
    ],
    'usuario' => [
        'ver_libros'         => true,
        'crear_libros'       => false,
        'editar_libros'      => false,
        'eliminar_libros'    => false,
        'ver_reservas'       => false, // solo las propias (ABAC)
        'ver_auditoria'      => false,
        'ver_seguridad'      => false,
        'config_sistema'     => false,
    ],
];

// ══════════════════════════════════════════════════════════════════════════════
// FUNCIONES RBAC
// ══════════════════════════════════════════════════════════════════════════════

/** Verifica si un rol tiene un permiso específico */
function rbac_tiene_permiso(string $rol, string $permiso): bool {
    return ROLES_PERMISOS[$rol][$permiso] ?? false;
}

/** Verifica si el usuario en sesión tiene un permiso */
function puede(string $permiso): bool {
    $user = session_user();
    if (!$user) return false;
    return rbac_tiene_permiso($user['rol'], $permiso);
}

/** Requiere un permiso o redirige con error 403 */
function require_permiso(string $permiso): void {
    require_login();
    if (!puede($permiso)) {
        registrar_acceso_denegado($permiso);
        http_response_code(403);
        include __DIR__ . '/../errors/403.php';
        exit;
    }
}

/** Verifica jerarquía de rol (>= nivel mínimo) */
function require_rol_minimo(string $rol_minimo): void {
    require_login();
    $user = session_user();
    $nivel_usuario = ROLES_JERARQUIA[$user['rol']] ?? 0;
    $nivel_minimo  = ROLES_JERARQUIA[$rol_minimo]  ?? 999;
    if ($nivel_usuario < $nivel_minimo) {
        registrar_acceso_denegado("rol_minimo:$rol_minimo");
        http_response_code(403);
        include __DIR__ . '/../errors/403.php';
        exit;
    }
}

// Nota: is_superadmin(), is_admin(), is_editor(), session_user()
// están definidas en includes/session.php — no se redeclaran aquí.

// ══════════════════════════════════════════════════════════════════════════════
// ABAC — Control basado en atributos
// ══════════════════════════════════════════════════════════════════════════════

/**
 * ABAC: ¿puede el usuario actual acceder al recurso?
 * Ej: usuario solo accede a sus propias reservas;
 *     admin/superadmin acceden a todo.
 */
function abac_puede_acceder_recurso(string $tipo_recurso, string $propietario_id): bool {
    $user = session_user();
    if (!$user) return false;
    $rol = $user['rol'];
    // Admins y superadmin siempre pueden
    if (in_array($rol, ['admin', 'superadmin'])) return true;
    // Editor puede ver libros de cualquiera
    if ($tipo_recurso === 'libro' && $rol === 'editor') return true;
    // Usuario solo accede a sus propios recursos
    return $user['id'] === $propietario_id;
}

// ══════════════════════════════════════════════════════════════════════════════
// SECURITY HEADERS
// ══════════════════════════════════════════════════════════════════════════════

function aplicar_security_headers(): void {
    // Anti-Clickjacking
    header('X-Frame-Options: SAMEORIGIN');
    // Anti-XSS (navegadores legacy)
    header('X-XSS-Protection: 1; mode=block');
    // No sniffing de tipo de contenido
    header('X-Content-Type-Options: nosniff');
    // Referrer Policy
    header('Referrer-Policy: strict-origin-when-cross-origin');
    // Content Security Policy (básico)
    header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https:;");
    // HSTS (solo en HTTPS)
    if (!empty($_SERVER['HTTPS'])) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
    // Permissions Policy
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
}

// ══════════════════════════════════════════════════════════════════════════════
// RATE LIMITING
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Rate limiting por IP usando archivo JSON en /tmp.
 * Máximo $max_intentos en $ventana_segundos.
 * Si se supera, responde 429 y termina.
 */
function rate_limit(string $contexto = 'global', int $max_intentos = 60, int $ventana_segundos = 60): void {
    $ip = ip_real();
    $key = "rl_{$contexto}_" . md5($ip);
    $archivo = sys_get_temp_dir() . "/$key.json";

    $ahora = time();
    $data = ['intentos' => [], 'bloqueado_hasta' => 0];

    if (file_exists($archivo)) {
        $d = json_decode(file_get_contents($archivo), true);
        if (is_array($d)) $data = $d;
    }

    // Si está bloqueado por IP
    if ($data['bloqueado_hasta'] > $ahora) {
        $restante = $data['bloqueado_hasta'] - $ahora;
        registrar_auditoria_simple("RATE_LIMIT_BLOQUEADO", "IP bloqueada en $contexto por $restante s");
        http_response_code(429);
        header('Retry-After: ' . $restante);
        die(json_encode([
            'ok' => false,
            'msg' => "Demasiadas solicitudes. Espera $restante segundos.",
            'retry_after' => $restante
        ]));
    }

    // Filtrar intentos en la ventana
    $data['intentos'] = array_filter($data['intentos'], fn($t) => $ahora - $t < $ventana_segundos);
    $data['intentos'][] = $ahora;

    // ¿Superó el límite?
    if (count($data['intentos']) > $max_intentos) {
        $data['bloqueado_hasta'] = $ahora + $ventana_segundos;
        file_put_contents($archivo, json_encode($data), LOCK_EX);
        registrar_auditoria_simple("RATE_LIMIT_EXCEDIDO", "IP $ip bloqueada en $contexto");
        http_response_code(429);
        header('Retry-After: ' . $ventana_segundos);
        die(json_encode([
            'ok' => false,
            'msg' => "Límite excedido en $contexto. Espera $ventana_segundos segundos.",
            'retry_after' => $ventana_segundos
        ]));
    }

    file_put_contents($archivo, json_encode($data), LOCK_EX);
}

/** Obtiene la IP real del visitante (considera proxies) */
function ip_real(): string {
    foreach (['HTTP_CF_CONNECTING_IP','HTTP_X_REAL_IP','HTTP_X_FORWARDED_FOR','REMOTE_ADDR'] as $k) {
        if (!empty($_SERVER[$k])) {
            $ip = trim(explode(',', $_SERVER[$k])[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
        }
    }
    return '0.0.0.0';
}

// ══════════════════════════════════════════════════════════════════════════════
// SANITIZACIÓN (Anti SQL Injection / XSS)
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Sanitiza un string para output en HTML (Anti-XSS).
 * NUNCA usar datos de usuario en HTML sin pasar por esta función.
 */
function s(mixed $valor): string {
    return htmlspecialchars((string)($valor ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * Sanitiza para uso en SQL con PDO (solo strings limpios).
 * La verdadera protección es usar prepared statements — esto es defensa en profundidad.
 */
function sanitizar_sql_input(string $input): string {
    // Eliminar caracteres nulos
    $input = str_replace("\0", '', $input);
    // Limitar longitud máxima
    $input = mb_substr($input, 0, 1000);
    return $input;
}

/**
 * Detecta patrones básicos de inyección SQL en los inputs.
 * Registra y bloquea si detecta un ataque evidente.
 */
function detectar_sql_injection(array $inputs): void {
    $patrones = [
        '/(\bUNION\b.*\bSELECT\b)/i',
        '/(\bDROP\b.*\bTABLE\b)/i',
        '/(\bINSERT\b.*\bINTO\b)/i',
        '/(\bDELETE\b.*\bFROM\b)/i',
        '/(\bOR\b\s+[\'"]?\d+[\'"]?\s*=\s*[\'"]?\d+[\'"]?)/i',
        "/(--|\\/\\*|\\*\\/|;\\s*DROP|xp_)/i",
    ];
    foreach ($inputs as $nombre => $valor) {
        foreach ($patrones as $patron) {
            if (preg_match($patron, (string)$valor)) {
                registrar_auditoria_simple("SQL_INJECTION_DETECTADO", "Campo: $nombre | IP: " . ip_real());
                http_response_code(400);
                die(json_encode(['ok' => false, 'msg' => 'Entrada inválida detectada.']));
            }
        }
    }
}

/**
 * Detecta patrones de XSS en inputs.
 */
function detectar_xss(array $inputs): void {
    $patrones = [
        '/<script[\s\S]*?>[\s\S]*?<\/script>/i',
        '/javascript\s*:/i',
        '/on\w+\s*=\s*["\']?[^"\']*["\']?/i',
        '/<iframe[\s\S]*?>/i',
    ];
    foreach ($inputs as $nombre => $valor) {
        foreach ($patrones as $patron) {
            if (preg_match($patron, (string)$valor)) {
                registrar_auditoria_simple("XSS_DETECTADO", "Campo: $nombre | IP: " . ip_real());
                http_response_code(400);
                die(json_encode(['ok' => false, 'msg' => 'Contenido no permitido detectado.']));
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// AUDITORÍA
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Registra un evento en la tabla audit_log.
 * Si la BD no está disponible, escribe en archivo de log.
 */
function registrar_auditoria(string $evento, string $detalle = '', ?string $usuario_id = null): void {
    $ip = ip_real();
    $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 300);
    $url = ($_SERVER['REQUEST_URI'] ?? '');
    $user = session_user();
    $uid  = $usuario_id ?? ($user['id'] ?? null);

    // Intentar guardar en BD
    try {
        $pdo = db();
        $pdo->prepare(
            'INSERT INTO audit_log (id, usuario_id, evento, detalle, ip, user_agent, url, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, NOW())'
        )->execute([uuid(), $uid, $evento, $detalle, $ip, $ua, $url]);
    } catch (Exception $e) {
        // Fallback: escribir en archivo
        registrar_auditoria_simple($evento, $detalle);
    }
}

/** Versión ligera que solo escribe en archivo (sin BD) */
function registrar_auditoria_simple(string $evento, string $detalle = ''): void {
    $ip   = ip_real();
    $user = session_user();
    $uid  = $user['id'] ?? 'anon';
    $ts   = date('Y-m-d H:i:s');
    $linea = "[$ts] [$evento] usuario=$uid ip=$ip detalle=" . str_replace(["\n","\r"], ' ', $detalle) . PHP_EOL;
    $archivo = __DIR__ . '/../audit.log';
    file_put_contents($archivo, $linea, FILE_APPEND | LOCK_EX);
}

/** Registra acceso denegado */
function registrar_acceso_denegado(string $recurso): void {
    $user = session_user();
    $rol  = $user['rol'] ?? 'anon';
    registrar_auditoria("ACCESO_DENEGADO", "recurso=$recurso rol=$rol", $user['id'] ?? null);
}

// ══════════════════════════════════════════════════════════════════════════════
// PROTECCIÓN CONTRA SESSION FIXATION
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Regenera el ID de sesión periódicamente para prevenir session fixation.
 * Llamar al inicio de cada página protegida.
 */
function proteger_sesion(): void {
    if (session_status() === PHP_SESSION_NONE) session_start();

    // Regenerar ID cada 30 minutos
    $ahora = time();
    if (!isset($_SESSION['_last_regen'])) {
        $_SESSION['_last_regen'] = $ahora;
    } elseif ($ahora - $_SESSION['_last_regen'] > 1800) {
        session_regenerate_id(true);
        $_SESSION['_last_regen'] = $ahora;
    }

    // Validar User-Agent (protección básica contra session hijacking)
    $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 200);
    if (!isset($_SESSION['_ua'])) {
        $_SESSION['_ua'] = $ua;
    } elseif ($_SESSION['_ua'] !== $ua) {
        // UA cambió: posible robo de sesión
        registrar_auditoria("SESSION_UA_CAMBIO", "UA nuevo: $ua");
        session_unset(); session_destroy(); session_start();
        session_regenerate_id(true);
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// CORS CONFIGURABLE
// ══════════════════════════════════════════════════════════════════════════════

/**
 * CORS restringido para APIs (no permitir '*' en producción).
 */
function cors_seguro(array $origenes_permitidos = ['http://localhost', 'http://127.0.0.1']): void {
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if (in_array($origin, $origenes_permitidos)) {
        header("Access-Control-Allow-Origin: $origin");
        header('Vary: Origin');
    }
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-CSRF-Token');
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204); exit;
    }
}
