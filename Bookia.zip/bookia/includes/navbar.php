<?php
/**
 * BOOKIA — Navbar con control de roles (PHP puro, sin JS para auth)
 */
?>
  <nav class="navbar" role="navigation" aria-label="Navegación principal">
    <a href="<?= url('index.php') ?>" class="logo" aria-label="Bookia inicio">
      <img src="<?= url('img/logo.png') ?>" alt="Bookia" width="46" height="46">
      <span class="logo-text">BOOKIA</span>
    </a>
    <button class="menu-toggle" aria-label="Abrir menú" aria-expanded="false">☰</button>
    <ul role="menubar">
      <li role="none"><a href="<?= url('index.php') ?>" role="menuitem">Inicio</a></li>
      <li class="has-submenu" role="none">
        <a href="<?= url('catalogo.php') ?>" role="menuitem" aria-haspopup="true">Catálogo</a>
        <ul class="submenu" role="menu">
          <li><a href="<?= url('catalogo.php') ?>">📖 Todos los libros</a></li>
          <li><a href="<?= url('catalogo.php?g=Ficción') ?>">📝 Ficción</a></li>
          <li><a href="<?= url('catalogo.php?g=No+Ficción') ?>">🧪 No Ficción</a></li>
          <li><a href="<?= url('catalogo.php?g=Infantil') ?>">🌟 Infantil</a></li>
          <li><a href="<?= url('catalogo.php?g=Misterio') ?>">🔍 Misterio</a></li>
          <li><a href="<?= url('catalogo.php?g=Ciencia+Ficción') ?>">🚀 Ciencia Ficción</a></li>
          <li><a href="<?= url('catalogo.php?g=Romance') ?>">💕 Romance</a></li>
          <li><a href="<?= url('catalogo.php?g=Historia') ?>">🏛️ Historia</a></li>
          <li><a href="<?= url('catalogo.php?g=Autoayuda') ?>">✨ Autoayuda</a></li>
        </ul>
      </li>
      <li class="has-submenu" role="none">
        <a href="<?= url('servicios.php') ?>" role="menuitem" aria-haspopup="true">Servicios</a>
        <ul class="submenu" role="menu">
          <li><a href="<?= url('reservar.php') ?>">📌 Reservar libro</a></li>
          <li><a href="<?= url('servicios.php#recoger') ?>">🏪 Pick Up</a></li>
          <li><a href="<?= url('servicios.php#devoluciones') ?>">↩ Devoluciones</a></li>
        </ul>
      </li>
      <li role="none"><a href="<?= url('contacto.php') ?>" role="menuitem">Contáctanos</a></li>
      <li class="has-submenu" role="none">
        <a href="#" role="menuitem" aria-haspopup="true">Mi Cuenta</a>
        <ul class="submenu" role="menu">
          <?php if (is_logged_in()): $nu = session_user(); ?>
          <?php if (is_admin()): ?>
              <li><a href="<?= url('admin.php') ?>">
                <span class="badge-admin"><?= session_user()['rol'] === 'superadmin' ? '⭐ Super Admin' : 'Admin' ?></span> Panel
              </a></li>
            <?php else: ?>
              <li><a href="<?= url('perfil.php') ?>">👤 <?= e($nu['nombre']) ?></a></li>
              <li><a href="<?= url('seguridad.php') ?>">🔒 Seguridad</a></li>
              <?php if (is_editor()): ?>
              <li><a href="<?= url('sso_appb.php') ?>">🔗 SSO Demo</a></li>
              <?php endif; ?>
            <?php endif; ?>
            <li><a href="<?= url('logout.php') ?>">🚪 Cerrar Sesión</a></li>
          <?php else: ?>
            <li><a href="<?= url('login.php') ?>">Iniciar Sesión</a></li>
            <li><a href="<?= url('registro.php') ?>">Registrarse</a></li>
          <?php endif; ?>
        </ul>
      </li>
    </ul>
  </nav>
