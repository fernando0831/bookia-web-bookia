<?php
/**
 * BOOKIA — Manejo de sesión con RBAC extendido
 * Práctica 2 Unidad 3 — Roles: superadmin, admin, editor, usuario
 */
if (session_status() === PHP_SESSION_NONE) session_start();

require_once __DIR__ . '/auth.php';

// ── Accesores de sesión ──────────────────────────────────────
function session_user(): ?array { return $_SESSION['bookia_user'] ?? null; }
function is_logged_in(): bool   { return !empty($_SESSION['bookia_user']); }

// ── Verificadores de rol ─────────────────────────────────────
function is_superadmin(): bool {
    return (session_user()['rol'] ?? '') === 'superadmin';
}
function is_admin(): bool {
    return in_array(session_user()['rol'] ?? '', ['admin','superadmin']);
}
function is_editor(): bool {
    return in_array(session_user()['rol'] ?? '', ['editor','admin','superadmin']);
}

// ── Guardas de acceso ────────────────────────────────────────

function require_login(string $redirect = 'login.php'): void {
    if (!is_logged_in()) {
        redirect($redirect);
    }
    // Aplicar protección anti session fixation en cada página protegida
    proteger_sesion();
}

function require_admin(): void {
    require_login();
    if (!is_admin()) {
        registrar_acceso_denegado('admin');
        redirect('index.php');
    }
}

function require_superadmin(): void {
    require_login();
    if (!is_superadmin()) {
        registrar_acceso_denegado('superadmin');
        http_response_code(403);
        include __DIR__ . '/../errors/403.php';
        exit;
    }
}

function require_editor(): void {
    require_login();
    if (!is_editor()) {
        registrar_acceso_denegado('editor');
        redirect('index.php');
    }
}

// ── Gestión de sesión ────────────────────────────────────────

function login_user(array $user): void {
    session_regenerate_id(true);
    $_SESSION['bookia_user'] = [
        'id'          => $user['id'],
        'nombre'      => $user['nombre'],
        'email'       => $user['email'],
        'rol'         => $user['rol'],
        'tema_oscuro' => (int)($user['tema_oscuro'] ?? 0),
        'idioma'      => $user['idioma'] ?? 'es',
    ];
    $_SESSION['_ua']         = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 200);
    $_SESSION['_last_regen'] = time();

    try { registrar_sesion(db(), $user['id']); } catch (Exception $e) {}
    registrar_auditoria('LOGIN_EXITOSO', 'Sesión iniciada', $user['id']);
}

function logout_user(): void {
    if (is_logged_in()) {
        $u = session_user();
        registrar_auditoria('LOGOUT', 'Sesión cerrada', $u['id']);
        try { cerrar_sesion_bd(db(), session_id(), $u['id']); } catch (Exception $e) {}
    }
    session_unset();
    session_destroy();
    session_start();
    session_regenerate_id(true);
}

// Cargar middleware DESPUÉS de declarar session_user() y funciones de rol
require_once __DIR__ . '/middleware.php';
