<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/session.php';

$pageTitle = 'Bookia — Reserve, pick up & read';
$u = session_user();

$libros = [];
$stats  = ['total' => 0, 'generos' => 0];
try {
    $pdo = db();
    $row = $pdo->query('SELECT COUNT(*) as total, COUNT(DISTINCT genero) as generos FROM libros')->fetch();
    $stats = ['total' => $row['total'], 'generos' => $row['generos']];
    $libros = $pdo->query(
        'SELECT l.* FROM libros l
         INNER JOIN (
           SELECT MIN(id) as id FROM libros GROUP BY genero
         ) sub ON l.id = sub.id
         ORDER BY l.genero LIMIT 16'
    )->fetchAll();
} catch (Exception $e) {
    $dbError = 'No se pudo conectar a la base de datos.';
}

require_once __DIR__ . '/includes/header.php';
$en = $idioma === 'en';
?>

<section class="hero" aria-labelledby="hero-title">
  <div class="hero-content">
    <h2 id="hero-title"><?= $en ? 'Reserve, pick up<br><span>and enjoy reading</span>' : 'Reserva, recoge<br><span>y disfruta leer</span>' ?></h2>
    <p><?= $en ? 'Your favorite pick-up bookstore. Choose your next read online and pick it up whenever you want.' : 'Tu librería pick-up favorita. Elige tu próxima lectura en línea y recógela cuando quieras.' ?></p>
    <div class="hero-actions">
      <a href="<?= url('catalogo.php') ?>" class="btn">📖 <?= $en ? 'Browse Catalogue' : 'Explorar Catálogo' ?></a>
      <?php if (!is_logged_in()): ?>
        <a href="<?= url('registro.php') ?>" class="btn btn-outline"><?= $en ? 'Create free account' : 'Crear cuenta gratis' ?></a>
      <?php endif; ?>
    </div>
  </div>
</section>

<section style="background:#FFF;padding:32px 24px;border-bottom:1px solid #E0E0E0">
  <div style="max-width:900px;margin:0 auto;display:grid;grid-template-columns:repeat(3,1fr);gap:20px;text-align:center">
    <div>
      <div style="font-size:32px;font-weight:900;color:#6B0F2A"><?= $stats['total'] ?></div>
      <div style="font-size:14px;color:#6B7280;margin-top:4px"><?= $en ? 'Available books' : 'Libros disponibles' ?></div>
    </div>
    <div>
      <div style="font-size:32px;font-weight:900;color:#C19A6B"><?= $stats['generos'] ?></div>
      <div style="font-size:14px;color:#6B7280;margin-top:4px"><?= $en ? 'Literary genres' : 'Géneros literarios' ?></div>
    </div>
    <div>
      <div style="font-size:32px;font-weight:900;color:#6B0F2A">24h</div>
      <div style="font-size:14px;color:#6B7280;margin-top:4px"><?= $en ? 'Preparation time' : 'Tiempo de preparación' ?></div>
    </div>
  </div>
</section>

<section style="background:#fff;overflow:hidden;border-bottom:1px solid #E0E0E0">
  <div class="bk-carousel" style="position:relative;height:260px;background:#6B0F2A">
    <div class="carousel-slide" style="background:linear-gradient(135deg,#6B0F2A,#8B1A3A);display:flex;align-items:center;justify-content:center;height:260px">
      <div style="text-align:center;color:#fff;padding:20px">
        <div style="font-size:48px;margin-bottom:8px">📚</div>
        <h3 style="font-size:22px;font-weight:800;margin-bottom:6px"><?= $en ? 'New arrivals' : 'Nuevas adquisiciones' ?></h3>
        <p style="color:rgba(255,255,255,0.8);font-size:14px"><?= $en ? 'Discover the latest titles in our catalogue' : 'Descubre los títulos más recientes en nuestro catálogo' ?></p>
      </div>
    </div>
    <div class="carousel-slide" style="background:linear-gradient(135deg,#A8824E,#C19A6B);display:flex;align-items:center;justify-content:center;height:260px">
      <div style="text-align:center;color:#fff;padding:20px">
        <div style="font-size:48px;margin-bottom:8px">✨</div>
        <h3 style="font-size:22px;font-weight:800;margin-bottom:6px">Pick Up Express</h3>
        <p style="color:rgba(255,255,255,0.85);font-size:14px"><?= $en ? 'Reserve online and pick up in less than 2 hours' : 'Reserva en línea y recoge en menos de 2 horas' ?></p>
      </div>
    </div>
    <div class="carousel-slide" style="background:linear-gradient(135deg,#1e3a5f,#2563eb);display:flex;align-items:center;justify-content:center;height:260px">
      <div style="text-align:center;color:#fff;padding:20px">
        <div style="font-size:48px;margin-bottom:8px">🎁</div>
        <h3 style="font-size:22px;font-weight:800;margin-bottom:6px"><?= $en ? 'Reading events' : 'Eventos de lectura' ?></h3>
        <p style="color:rgba(255,255,255,0.8);font-size:14px"><?= $en ? 'Join our monthly book clubs' : 'Únete a nuestros clubes de lectura mensuales' ?></p>
      </div>
    </div>
  </div>
</section>

<section class="catalogo" aria-label="<?= $en ? 'Featured books' : 'Libros destacados' ?>">
  <div class="catalogo-header">
    <h2><?= $en ? 'Featured Books' : 'Libros Destacados' ?></h2>
    <p><?= $en ? 'Our curated selection for you' : 'Nuestra selección curada para ti' ?></p>
  </div>

  <?php if (isset($dbError)): ?>
    <div class="msg msg-error" style="max-width:600px;margin:0 auto">
      <span class="msg-icon">⚠</span>
      <?= e($dbError) ?> <?= $en ? 'Check that MySQL is running in XAMPP.' : 'Verifica que MySQL esté activo en XAMPP.' ?>
    </div>
  <?php elseif (empty($libros)): ?>
    <p style="text-align:center;color:#9CA3AF;padding:40px"><?= $en ? 'No books in the database yet.' : 'No hay libros en la base de datos aún.' ?></p>
  <?php else: ?>
    <div class="grid">
      <?php foreach ($libros as $libro): ?>
        <?php
          $disp      = (int)$libro['disponibles'];
          $dispLabel = $en ? ($disp === 0 ? 'Out of stock' : "$disp available") : ($disp === 0 ? 'Agotado' : "$disp disponibles");
          $dispClass = $disp === 0 ? 'agotado' : ($disp <= 2 ? 'poco' : '');
          $badgeText = $en
            ? ($disp === 0 ? 'Out of stock' : ($disp <= 2 ? 'Last copies' : ''))
            : ($disp === 0 ? 'Agotado' : ($disp <= 2 ? 'Últimas copias' : ''));
        ?>
        <div class="libro" data-detail-libro='<?= htmlspecialchars(json_encode(["id"=>$libro["id"],"titulo"=>$libro["titulo"],"autor"=>$libro["autor"],"genero"=>$libro["genero"],"anio"=>$libro["anio"],"disponibles"=>$libro["disponibles"],"descripcion"=>$libro["descripcion"],"imagen"=>$libro["imagen"],"isbn"=>$libro["isbn"]??""]), ENT_QUOTES) ?>' style="cursor:pointer">
          <div class="libro-cover">
            <?php if ($libro['imagen']): ?>
              <img src="<?= e($libro['imagen']) ?>" alt="<?= e($libro['titulo']) ?>" loading="lazy"
                   data-isbn="<?= e($libro['isbn'] ?? '') ?>"
                   onerror="
                     var isbn=this.dataset.isbn;
                     if(isbn&&!this.dataset.fallback){
                       this.dataset.fallback='1';
                       this.src='https://books.google.com/books/content?vid=ISBN'+isbn+'&printsec=frontcover&img=1&zoom=1';
                     } else {
                       this.style.display='none';
                       this.parentElement.style.background='linear-gradient(135deg,#6B0F2A,#8B1A3A)';
                     }
                   ">
            <?php else: ?>
              <div style="width:100%;height:100%;background:linear-gradient(135deg,#6B0F2A,#8B1A3A);display:flex;align-items:center;justify-content:center;font-size:40px;color:rgba(255,255,255,0.5)">📚</div>
            <?php endif; ?>
            <?php if ($badgeText): ?>
              <span class="libro-badge <?= $dispClass ?>"><?= $badgeText ?></span>
            <?php endif; ?>
          </div>
          <div class="libro-body">
            <h3><?= e($libro['titulo']) ?></h3>
            <p class="libro-autor">✍️ <?= e($libro['autor']) ?></p>
            <div class="libro-meta">
              <span class="libro-tag"><?= e($libro['genero']) ?></span>
              <?php if ($libro['anio']): ?><span class="libro-tag"><?= (int)$libro['anio'] ?></span><?php endif; ?>
            </div>
            <p class="libro-disponibles">📚 <strong class="<?= $dispClass ?>"><?= $dispLabel ?></strong></p>
            <?php if ($disp > 0): ?>
              <?php if (is_logged_in()): ?>
                <a href="<?= url('reservar.php?libro=' . urlencode($libro['id'])) ?>" class="btn" style="width:100%;justify-content:center;text-align:center">📌 <?= $en ? 'Reserve' : 'Reservar' ?></a>
              <?php else: ?>
                <a href="<?= url('login.php') ?>" class="btn btn-ghost" style="width:100%;justify-content:center;text-align:center">🔐 <?= $en ? 'Log in' : 'Iniciar sesión' ?></a>
              <?php endif; ?>
            <?php else: ?>
              <button class="btn btn-ghost" disabled style="width:100%;cursor:not-allowed;opacity:.6">🚫 <?= $en ? 'Unavailable' : 'No disponible' ?></button>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center;margin-top:32px">
      <a href="<?= url('catalogo.php') ?>" class="btn">📖 <?= $en ? "View all books ({$stats['total']})" : "Ver todos los libros ({$stats['total']})" ?></a>
    </div>
  <?php endif; ?>
</section>

<section style="background:#FFF;padding:60px 24px">
  <div style="max-width:900px;margin:0 auto;text-align:center">
    <h2 style="font-size:28px;font-weight:800;color:#6B0F2A;margin-bottom:8px"><?= $en ? 'How does it work?' : '¿Cómo funciona?' ?></h2>
    <p style="color:#6B7280;margin-bottom:40px"><?= $en ? 'Reserving your book has never been easier' : 'Reservar tu libro nunca fue tan fácil' ?></p>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:28px">
      <div style="padding:24px;text-align:center">
        <div style="font-size:40px;margin-bottom:16px">🔍</div>
        <h3 style="font-size:16px;font-weight:700;color:#6B0F2A;margin-bottom:8px"><?= $en ? '1. Browse' : '1. Explora' ?></h3>
        <p style="font-size:14px;color:#6B7280"><?= $en ? 'Browse our catalogue and find your next read' : 'Navega nuestro catálogo y encuentra tu próxima lectura' ?></p>
      </div>
      <div style="padding:24px;text-align:center">
        <div style="font-size:40px;margin-bottom:16px">📌</div>
        <h3 style="font-size:16px;font-weight:700;color:#6B0F2A;margin-bottom:8px"><?= $en ? '2. Reserve' : '2. Reserva' ?></h3>
        <p style="font-size:14px;color:#6B7280"><?= $en ? 'Reserve online and choose your pick-up date' : 'Reserva en línea y elige la fecha de recogida' ?></p>
      </div>
      <div style="padding:24px;text-align:center">
        <div style="font-size:40px;margin-bottom:16px">🏪</div>
        <h3 style="font-size:16px;font-weight:700;color:#6B0F2A;margin-bottom:8px"><?= $en ? '3. Pick up' : '3. Recoge' ?></h3>
        <p style="font-size:14px;color:#6B7280"><?= $en ? 'Come to the store and take your book in minutes' : 'Pasa por la librería y llévate tu libro en minutos' ?></p>
      </div>
    </div>
  </div>
</section>

<?php
$extraScript = '<script src="js/cache.js"></script><script src="js/dom.js"></script><script src="js/api.js"></script><script src="js/data.js"></script><script src="js/ui.js"></script><script src="js/app.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function() {
  document.querySelectorAll("[data-detail-libro]").forEach(function(card) {
    card.addEventListener("click", function(e) {
      if (e.target.closest("a") || e.target.closest("button")) return;
      try {
        var libro = JSON.parse(this.dataset.detailLibro);
        if (window.BookiaUI && window.BookiaUI.openLibroDetail) {
          window.BookiaUI.openLibroDetail(libro);
        }
      } catch(err) { console.error(err); }
    });
  });
});
</script>';
require_once __DIR__ . '/includes/footer.php'; ?>
