/**
 * BOOKIA — animations.js | Motor de Animaciones
 * Práctica 2 — Parte 3: Animaciones y Transiciones Avanzadas
 *
 * Implementa:
 *  - IntersectionObserver (fade + translate escalonado)
 *  - Parallax con mousemove
 *  - Efecto magnético en botones
 *  - Hover animado
 */
'use strict';

const BookiaAnimations = (() => {

  /* ── 1. Animaciones con Scroll (IntersectionObserver) ─────────── */

  function initScrollReveal(selector = '[data-reveal]', root = document) {
    const els = root.querySelectorAll(selector);
    if (!els.length) return;

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        const el = entry.target;
        const delay = el.dataset.delay || 0;

        setTimeout(() => {
          el.classList.add('revealed');
        }, parseInt(delay));

        observer.unobserve(el);
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    els.forEach((el, i) => {
      // Animaciones escalonadas automáticas si no se especifica delay
      if (!el.dataset.delay) el.dataset.delay = i * 80;
      observer.observe(el);
    });
  }

  /* ── 2. Parallax con mousemove ────────────────────────────────── */

  function initParallax(selector = '[data-parallax]') {
    const layers = document.querySelectorAll(selector);
    if (!layers.length) return;

    const throttle = window.BookiaDOM?.throttle || ((fn) => fn);

    document.addEventListener('mousemove', throttle((e) => {
      const cx = window.innerWidth  / 2;
      const cy = window.innerHeight / 2;
      const dx = (e.clientX - cx) / cx; // −1 … 1
      const dy = (e.clientY - cy) / cy;

      layers.forEach(el => {
        const depth = parseFloat(el.dataset.parallax) || 0.05;
        const tx = dx * depth * 40;
        const ty = dy * depth * 40;
        requestAnimationFrame(() => {
          el.style.transform = `translate(${tx}px, ${ty}px)`;
        });
      });
    }, 16));
  }

  /* ── 3. Efecto magnético en botones ───────────────────────────── */

  function initMagneticButtons(selector = '.btn-magnetic') {
    document.querySelectorAll(selector).forEach(btn => {
      btn.addEventListener('mousemove', (e) => {
        const rect = btn.getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width  / 2;
        const y = e.clientY - rect.top  - rect.height / 2;
        requestAnimationFrame(() => {
          btn.style.transform = `translate(${x * 0.25}px, ${y * 0.25}px)`;
        });
      });

      btn.addEventListener('mouseleave', () => {
        btn.style.transition = 'transform 0.4s cubic-bezier(0.23, 1, 0.32, 1)';
        btn.style.transform  = 'translate(0,0)';
        setTimeout(() => { btn.style.transition = ''; }, 400);
      });
    });
  }

  /* ── 4. Hover tilt en tarjetas ───────────────────────────────── */

  function initCardTilt(selector = '.libro') {
    document.querySelectorAll(selector).forEach(card => {
      card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width  - 0.5;
        const y = (e.clientY - rect.top)  / rect.height - 0.5;
        requestAnimationFrame(() => {
          card.style.transform = `perspective(600px) rotateY(${x * 6}deg) rotateX(${-y * 6}deg) translateY(-4px)`;
        });
      });

      card.addEventListener('mouseleave', () => {
        card.style.transition = 'transform 0.4s ease';
        card.style.transform  = '';
        setTimeout(() => { card.style.transition = ''; }, 400);
      });
    });
  }

  /* ── 5. Entrada de elementos nuevos (datos en tiempo real) ───── */

  /**
   * Anima la entrada de un elemento recién insertado
   */
  function animateIn(el, type = 'fadeUp') {
    const anims = {
      fadeUp:   [{ opacity: 0, transform: 'translateY(20px)' }, { opacity: 1, transform: 'translateY(0)' }],
      fadeLeft: [{ opacity: 0, transform: 'translateX(-20px)' }, { opacity: 1, transform: 'translateX(0)' }],
      pop:      [{ opacity: 0, transform: 'scale(0.85)' }, { opacity: 1, transform: 'scale(1)' }],
    };

    el.animate(anims[type] || anims.fadeUp, {
      duration: 400,
      easing: 'cubic-bezier(0.16, 1, 0.3, 1)',
      fill: 'forwards',
    });
  }

  /* ── Init global ─────────────────────────────────────────────── */

  function init() {
    initScrollReveal();
    initParallax();
    initMagneticButtons();
    // initCardTilt() — se llama tras renderizar tarjetas
  }

  return { init, initScrollReveal, initParallax, initMagneticButtons, initCardTilt, animateIn };
})();

window.BookiaAnimations = BookiaAnimations;
