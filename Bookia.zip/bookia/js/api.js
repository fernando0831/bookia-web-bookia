/**
 * BOOKIA — api.js | Capa de Comunicación Asíncrona
 * ===================================================
 * Misma interfaz que la versión original.
 * Ahora apunta a los endpoints PHP reales en /api/
 * en lugar de JSONPlaceholder.
 *
 * Se conservan:
 *  - AbortController (cancelación de peticiones)
 *  - Promise.allSettled para cargarDashboard
 *  - Manejo de errores parciales
 *  - timeout configurable
 */
'use strict';

const BookiaAPI = (() => {

  const _controllers = new Map();
  const API = './api';

  /**
   * Fetch genérico con AbortController y timeout.
   */
  async function request(url, opts = {}) {
    const { key = url, timeout = 8000, ...fetchOpts } = opts;

    if (_controllers.has(key)) _controllers.get(key).abort();

    const controller = new AbortController();
    _controllers.set(key, controller);
    const timer = setTimeout(() => controller.abort(), timeout);

    try {
      console.time(`[API] ${key}`);
      const res = await fetch(url, { ...fetchOpts, signal: controller.signal });
      console.timeEnd(`[API] ${key}`);
      if (!res.ok) throw new Error(`HTTP ${res.status} — ${res.statusText}`);
      return await res.json();
    } catch (err) {
      if (err.name === 'AbortError') throw new Error(`Petición cancelada: ${key}`);
      throw err;
    } finally {
      clearTimeout(timer);
      _controllers.delete(key);
    }
  }

  function cancel(key) {
    if (_controllers.has(key)) {
      _controllers.get(key).abort();
      _controllers.delete(key);
    }
  }

  // ── Endpoints propios (MySQL via PHP) ──────────────────
  async function getLibros(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return request(`${API}/libros.php${qs ? '?' + qs : ''}`, { key: 'libros' });
  }

  async function getLibro(id) {
    return request(`${API}/libros.php?id=${id}`, { key: `libro-${id}` });
  }

  async function getUsuarios(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return request(`${API}/usuarios.php${qs ? '?' + qs : ''}`, { key: 'usuarios' });
  }

  async function getReservas(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return request(`${API}/reservas.php${qs ? '?' + qs : ''}`, { key: 'reservas' });
  }

  async function getSession() {
    return request(`${API}/auth.php?action=session`, { key: 'session' });
  }

  /**
   * Carga simultánea de libros + usuarios + reservas para el dashboard.
   * Mantiene la lógica Promise.allSettled del original.
   */
  async function cargarDashboard() {
    const results = await Promise.allSettled([
      getLibros(),
      getUsuarios(),
      getReservas(),
    ]);

    const [lbRes, usRes, rvRes] = results;

    const errores = results
      .map((r, i) => r.status === 'rejected'
        ? { recurso: ['libros', 'usuarios', 'reservas'][i], error: r.reason.message }
        : null)
      .filter(Boolean);

    return {
      libros:   lbRes.status === 'fulfilled' ? lbRes.value.data  : [],
      usuarios: usRes.status === 'fulfilled' ? usRes.value.data  : [],
      reservas: rvRes.status === 'fulfilled' ? rvRes.value.data  : [],
      errores,
    };
  }

  return { request, cancel, getLibros, getLibro, getUsuarios, getReservas, getSession, cargarDashboard };
})();

window.BookiaAPI = BookiaAPI;
