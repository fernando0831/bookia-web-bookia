/**
 * =====================================================
 * BOOKIA - Módulo de Aplicación (Capa de Controladores)
 * app.js — Arquitectura de 3 capas: LÓGICA DE NEGOCIO
 * =====================================================
 * Responsabilidad:
 *   - Controladores de cada página
 *   - Coordinación entre Data y UI
 *   - Manejo de eventos del DOM
 *   - Delegación de eventos
 *   - Lógica de negocio (reservas, autenticación)
 * =====================================================
 */

'use strict';

/* =====================================================
   CONTROLADOR GLOBAL (COMPARTIDO)
   Inicializado en todas las páginas
   ===================================================== */

const AppGlobal = {
  init() {
    const { initSeedData } = window.BookiaData;
    const { Session } = window.BookiaData;
    const UI = window.BookiaUI;

    // Inicializar datos semilla
    initSeedData();

    // Menú hamburguesa
    UI.initMenu();

    // Actualizar navbar según sesión
    const session = Session.get();
    UI.updateNavbarSession(session);

    // Escuchar cambios de sesión
    window.addEventListener('bookia:sessionchange', e => {
      UI.updateNavbarSession(e.detail);
    });

    // Logout
    const logoutBtn = document.getElementById('btn-logout');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', e => {
        e.preventDefault();
        Session.clear();
        UI.toast('Sesión cerrada correctamente', 'info');
        setTimeout(() => window.location.href = 'index.php', 800);
      });
    }

    // Marcar enlace activo en la navbar
    const currentPage = window.location.pathname.split('/').pop() || 'index.php';
    document.querySelectorAll('.navbar a').forEach(a => {
      const href = a.getAttribute('href');
      if (href && href.split('#')[0] === currentPage) a.classList.add('active');
    });
  },
};


/* =====================================================
   CONTROLADOR DE INICIO (index.php)
   ===================================================== */

const HomeController = {
  async init() {
    AppGlobal.init();
    const { LibrosRepo } = window.BookiaData;
    const UI = window.BookiaUI;

    // Renderizar destacados en home (primeros 8 libros, una por género)
    const container = document.getElementById('home-catalogo');
    if (container) {
      container.innerHTML = '<p style="text-align:center;color:#9CA3AF;padding:40px">Cargando libros...</p>';
      try {
        const todosLibros = await LibrosRepo.getAll();
        container.innerHTML = '';
        const seenGeneros = new Set();
        const libros = todosLibros.filter(l => {
          if (seenGeneros.has(l.genero)) return false;
          seenGeneros.add(l.genero);
          return true;
        }).slice(0, 8);
        if (libros.length) {
          UI.renderCatalogoPlano(container, libros);
        } else {
          container.innerHTML = '<p style="text-align:center;color:#9CA3AF;padding:40px">No hay libros disponibles.</p>';
        }
      } catch(e) {
        container.innerHTML = '<p style="text-align:center;color:#EF4444;padding:40px">Error al cargar libros. Verifica la conexión a la BD.</p>';
      }
    }
    // Delegación de eventos en home
    if (container) {
      container.addEventListener('click', async e => {
        const detailTrigger = e.target.closest('[data-detail]');
        if (detailTrigger && !e.target.closest('.btn-reservar')) {
          const libro = await window.BookiaData.LibrosRepo.getById(detailTrigger.dataset.detail);
          if (libro) UI.openLibroDetail(libro);
          return;
        }
        const btn = e.target.closest('.btn-reservar');
        if (btn && !btn.disabled) {
          const libroId = btn.dataset.id;
          if (!window.BookiaData.Session.isLoggedIn()) {
            UI.toast('Inicia sesión para reservar libros', 'warning');
            setTimeout(() => window.location.href = 'login.php', 1200);
            return;
          }
          ReservasController.hacerReserva(libroId);
        }
      });
    }

    // Estadísticas en home
    try {
      const stats = await LibrosRepo.getStats();
      const elTotalLibros = document.getElementById('stat-total-libros');
      const elGeneros     = document.getElementById('stat-generos');
      if (elTotalLibros) elTotalLibros.textContent = stats.total;
      if (elGeneros)     elGeneros.textContent     = stats.generos;
    } catch(e) { /* silencioso */ }
  },
};


/* =====================================================
   CONTROLADOR DE CATÁLOGO (catalogo.php)
   ===================================================== */

const CatalogoController = {
  state: {
    q:       '',
    genero:  new URLSearchParams(window.location.search).get('g') || '',
    sortBy:  'titulo',
    sortDir: 'asc',
  },

  async init() {
    AppGlobal.init();
    const { LibrosRepo } = window.BookiaData;
    const UI = window.BookiaUI;

    const container   = document.getElementById('catalogo-container');
    const searchInput = document.getElementById('search-libros');
    const filtroGenero= document.getElementById('filtro-genero');
    const filtroOrden = document.getElementById('filtro-orden');
    const statsEl     = document.getElementById('filtro-stats');

    const render = async () => {
      if (container) container.innerHTML = '<p style="text-align:center;color:#9CA3AF;padding:20px">Cargando...</p>';
      try {
        const libros = await LibrosRepo.search(this.state);
        UI.renderCatalogo(container, libros);
        UI.updateResultCount(statsEl, libros.length);
      } catch(e) {
        if (container) container.innerHTML = '<p style="text-align:center;color:#EF4444;padding:20px">Error al cargar catálogo.</p>';
      }
    };

    await render();

    // Búsqueda en tiempo real (debounced)
    let debounceTimer;
    if (searchInput) {
      searchInput.addEventListener('input', e => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
          this.state.q = e.target.value;
          render();
        }, 280);
      });
    }

    // Filtro por género
    if (filtroGenero) {
      filtroGenero.addEventListener('change', e => {
        this.state.genero = e.target.value;
        render();
      });
    }

    // Ordenamiento
    if (filtroOrden) {
      filtroOrden.addEventListener('change', e => {
        const [sortBy, sortDir] = e.target.value.split('-');
        this.state.sortBy  = sortBy;
        this.state.sortDir = sortDir;
        render();
      });
    }

    // Delegación de eventos — Reservar libro + Ver detalle
    if (container) {
      container.addEventListener('click', async e => {
        const detailTrigger = e.target.closest('[data-detail]');
        if (detailTrigger && !e.target.closest('.btn-reservar') && !e.target.closest('.btn-edit-libro') && !e.target.closest('.btn-del-libro')) {
          const libroId = detailTrigger.dataset.detail;
          const libro = await window.BookiaData.LibrosRepo.getById(libroId);
          if (libro) UI.openLibroDetail(libro);
          return;
        }
        const btn = e.target.closest('.btn-reservar');
        if (btn && !btn.disabled) {
          const libroId = btn.dataset.id;
          if (!window.BookiaData.Session.isLoggedIn()) {
            UI.toast('Inicia sesión para reservar', 'warning');
            setTimeout(() => window.location.href = 'login.php', 1200);
            return;
          }
          const ok = await ReservasController.hacerReserva(libroId);
          if (ok) render();
        }
      });
    }

    // Escuchar cambios de datos
    window.addEventListener('bookia:datachange', e => {
      if (e.detail?.key === 'bookia_libros') render();
    });
  },
};


/* =====================================================
   CONTROLADOR DE RESERVAS
   ===================================================== */

const ReservasController = {
  async hacerReserva(libroId) {
    const { LibrosRepo, ReservasRepo, Session } = window.BookiaData;
    const UI = window.BookiaUI;
    const session = Session.get();
    if (!session) return false;

    const libro = await LibrosRepo.getById(libroId);
    if (!libro) { UI.toast('Libro no encontrado', 'error'); return false; }
    if (libro.disponibles <= 0) { UI.toast('Este libro no está disponible', 'warning'); return false; }

    // Verificar si ya tiene este libro reservado
    const reservasUsuario = await ReservasRepo.getByUsuario(session.id);
    const yaReservado = reservasUsuario.some(r => r.libroId === libroId && ['pendiente','lista'].includes(r.estado));
    if (yaReservado) { UI.toast('Ya tienes este libro reservado', 'warning'); return false; }

    const ok = await UI.confirm({
      title: '¿Confirmar reserva?',
      message: `¿Deseas reservar <strong>${libro.titulo}</strong>?<br><small>Lo tendremos listo en 24 horas.</small>`,
      confirmText: '📌 Reservar',
    });
    if (!ok) return false;

    try {
      const manana = new Date(Date.now() + 86400000).toISOString().split('T')[0];
      // La API PHP maneja el decremento de disponibles internamente
      await ReservasRepo.insert({
        usuarioId:    session.id,
        libroId:      libro.id,
        fechaRecogida: manana,
        estado: 'pendiente',
      });
      UI.toast(`📌 "${libro.titulo}" reservado para el ${manana}`, 'success', 4000);
      return true;
    } catch(e) {
      UI.toast(e.message || 'Error al crear la reserva', 'error');
      return false;
    }
  },

  async cancelarReserva(reservaId) {
    const { ReservasRepo } = window.BookiaData;
    const UI = window.BookiaUI;

    const ok = await UI.confirm({
      title: 'Cancelar reserva',
      message: '¿Seguro que deseas cancelar esta reserva?',
      confirmText: 'Sí, cancelar',
      danger: true,
    });
    if (!ok) return false;

    try {
      // La API PHP devuelve el libro automáticamente al cancelar
      await ReservasRepo.update(reservaId, { estado: 'cancelada' });
      UI.toast('Reserva cancelada', 'info');
      return true;
    } catch(e) {
      UI.toast('Error al cancelar la reserva', 'error');
      return false;
    }
  },
};


/* =====================================================
   CONTROLADOR DE FORMULARIO DE RESERVA (reservar.php)
   ===================================================== */

const ReservarController = {
  async init() {
    AppGlobal.init();
    const { LibrosRepo, ReservasRepo, Session } = window.BookiaData;
    const UI = window.BookiaUI;

    const session = Session.get();
    const form    = document.getElementById('reservarForm');
    const select  = document.getElementById('libro');
    if (!form || !select) return;

    // Llenar select con libros disponibles
    try {
      const todosLibros = await LibrosRepo.getAll();
      const libros = todosLibros.filter(l => l.disponibles > 0);
      select.innerHTML = '<option value="">— Selecciona un libro —</option>';
      libros.forEach(l => {
        const opt = document.createElement('option');
        opt.value       = l.id;
        opt.textContent = `${l.titulo} — ${l.autor}`;
        const params = new URLSearchParams(window.location.search);
        const qLibro = params.get('libro');
        if (qLibro && (l.id === qLibro || l.titulo.toLowerCase().includes(qLibro.toLowerCase()))) {
          opt.selected = true;
        }
        select.appendChild(opt);
      });
    } catch(e) {
      select.innerHTML = '<option value="">Error al cargar libros</option>';
    }

    // Pre-rellenar datos del usuario
    if (session) {
      const nombreEl = document.getElementById('nombre');
      const emailEl  = document.getElementById('email');
      if (nombreEl) nombreEl.value = session.nombre;
      if (emailEl)  emailEl.value  = session.email;
    }

    const { validators } = UI;
    form.addEventListener('submit', async e => {
      e.preventDefault();
      UI.clearAllFieldErrors(form);
      UI.clearMessage('reservar-msg');

      const rules = {
        libro:          [validators.required('Selecciona un libro')],
        nombre:         [validators.required(), validators.minLen(3)],
        email:          [validators.required(), validators.email()],
        fechaRecogida:  [validators.required('Selecciona una fecha')],
      };

      const { valid, errors } = UI.validateForm(rules);
      Object.entries(errors).forEach(([id, msg]) => UI.showFieldError(id, msg));
      if (!valid) return;

      if (!session) {
        UI.showMessage('reservar-msg', 'Debes <a href="login.php">iniciar sesión</a> para reservar.', 'warning');
        return;
      }

      const libroId = document.getElementById('libro').value;
      const fecha   = document.getElementById('fechaRecogida').value;
      const notas   = document.getElementById('notas')?.value || '';

      try {
        const libro   = await LibrosRepo.getById(libroId);
        const reserva = await ReservasRepo.insert({
          usuarioId: session.id, libroId: libro.id,
          fechaRecogida: fecha, notas, estado: 'pendiente',
        });
        UI.showMessage('reservar-msg',
          `✅ <strong>¡Reserva confirmada!</strong><br>
           El libro <em>${libro.titulo}</em> estará listo para recoger el <strong>${fecha}</strong>.<br>
           <small>Código: ${reserva.codigoRecogida}</small>`, 'success');
        form.reset();
      } catch(err) {
        UI.showMessage('reservar-msg', `❌ ${err.message || 'Error al crear la reserva'}`, 'error');
      }
    });
  },
};


/* =====================================================
   CONTROLADOR DE LOGIN (login.php)
   ===================================================== */

const LoginController = {
  init() {
    AppGlobal.init();
    const { UsuariosRepo, Session } = window.BookiaData;
    const UI = window.BookiaUI;

    if (Session.isLoggedIn()) {
      window.location.href = Session.isAdmin() ? 'admin.php' : 'perfil.php';
      return;
    }

    const form    = document.getElementById('loginForm');
    const submitBtn = document.getElementById('btn-login');
    if (!form) return;

    const { validators } = UI;

    form.addEventListener('submit', async e => {
      e.preventDefault();
      UI.clearAllFieldErrors(form);
      UI.clearMessage('login-msg');

      const rules = {
        email:    [validators.required(), validators.email()],
        password: [validators.required()],
      };
      const { valid, errors } = UI.validateForm(rules);
      Object.entries(errors).forEach(([id, msg]) => UI.showFieldError(id, msg));
      if (!valid) return;

      UI.setLoading(submitBtn, true, 'Verificando...');

      const emailVal = document.getElementById('email').value.trim();
      const passVal  = document.getElementById('password').value;

      try {
        const user = await UsuariosRepo.verificarCredenciales(emailVal, passVal);
        UI.setLoading(submitBtn, false);

        if (!user) {
          UI.showMessage('login-msg', '❌ Credenciales incorrectas. Verifica tu correo y contraseña.', 'error');
          return;
        }

        const sessionData = { id: user.id, nombre: user.nombre, email: user.email, rol: user.rol };
        Session.set(sessionData);

        const destino = user.rol === 'admin' ? 'admin.php' : 'perfil.php';
        UI.toast('¡Bienvenido, ' + user.nombre.split(' ')[0] + '!', 'success');
        setTimeout(() => { window.location.href = destino; }, 900);
      } catch(err) {
        UI.setLoading(submitBtn, false);
        UI.showMessage('login-msg', '❌ ' + (err.message || 'Credenciales incorrectas.'), 'error');
      }
    });

    ['email','password'].forEach(id => {
      document.getElementById(id)?.addEventListener('input', () => UI.clearFieldError(id));
    });
  },
};


/* =====================================================
   CONTROLADOR DE REGISTRO (registro.php)
   ===================================================== */

const RegistroController = {
  init() {
    AppGlobal.init();
    const { UsuariosRepo, Session } = window.BookiaData;
    const UI = window.BookiaUI;

    if (Session.isLoggedIn()) { window.location.href = 'perfil.php'; return; }

    const form = document.getElementById('registroForm');
    if (!form) return;

    const { validators } = UI;

    document.getElementById('password')?.addEventListener('input', e => {
      UI.updatePasswordStrength(e.target.value, 'strength-bar', 'strength-text');
    });

    form.addEventListener('submit', async e => {
      e.preventDefault();
      UI.clearAllFieldErrors(form);
      UI.clearMessage('registro-msg');

      const rules = {
        nombre:          [validators.required(), validators.minLen(3)],
        email:           [validators.required(), validators.email()],
        telefono:        [validators.required(), validators.phone()],
        password:        [validators.required(), validators.minLen(8)],
        confirmPassword: [validators.required(), validators.match('password', 'Las contraseñas no coinciden')],
      };

      const { valid, errors } = UI.validateForm(rules);
      Object.entries(errors).forEach(([id, msg]) => UI.showFieldError(id, msg));
      if (!valid) return;

      if (typeof BookiaCaptcha !== 'undefined' && !BookiaCaptcha.isVerified()) {
        const capErr = document.getElementById('captcha-error');
        if (capErr) { capErr.textContent = 'Por favor completa la verificación de seguridad'; }
        BookiaCaptcha.show();
        return;
      }

      const email    = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;

      try {
        const existente = await UsuariosRepo.getByEmail(email);
        if (existente) {
          UI.showFieldError('email', 'Este correo ya está registrado');
          return;
        }

        const usuario = await UsuariosRepo.insert({
          nombre:   document.getElementById('nombre').value.trim(),
          email,
          telefono: document.getElementById('telefono').value.trim(),
          password,
          rol: 'usuario',
        });

        UI.showMessage('registro-msg',
          `✅ <strong>¡Cuenta creada exitosamente!</strong><br>
           Bienvenido a Bookia, <strong>${usuario.nombre}</strong>.<br>
           <a href="login.php" class="btn btn-sm" style="margin-top:10px">Iniciar sesión →</a>`,
          'success');
        form.style.display = 'none';
      } catch(err) {
        UI.showMessage('registro-msg', `❌ ${err.message || 'Error al crear la cuenta'}`, 'error');
      }
    });

    // Limpiar errores al escribir
    form.querySelectorAll('input').forEach(el => {
      el.addEventListener('input', () => UI.clearFieldError(el.id));
    });
  },
};


/* =====================================================
   CONTROLADOR DE PERFIL (perfil.php)
   ===================================================== */

const PerfilController = {
  async init() {
    AppGlobal.init();
    const { ReservasRepo, LibrosRepo, Session, UsuariosRepo } = window.BookiaData;
    const UI = window.BookiaUI;

    const session = Session.get();
    if (!session) { window.location.href = 'login.php'; return; }
    if (session.rol === 'admin') { window.location.href = 'admin.php'; return; }

    const navLabel = document.getElementById('nav-user-label');
    if (navLabel) navLabel.textContent = session.nombre.split(' ')[0];

    const reservasContainer = document.getElementById('mis-reservas');
    const renderReservas = async () => {
      if (!reservasContainer) return;
      try {
        const [reservas, libros] = await Promise.all([
          ReservasRepo.getByUsuario(session.id),
          LibrosRepo.getAll(),
        ]);
        const librosMap = {};
        libros.forEach(l => librosMap[l.id] = l);
        UI.renderReservasUsuario(reservasContainer, reservas, librosMap);
      } catch(e) {
        reservasContainer.innerHTML = '<p style="color:#EF4444">Error al cargar reservas.</p>';
      }
    };
    await renderReservas();

    reservasContainer?.addEventListener('click', async e => {
      const btnComp = e.target.closest('.btn-comprobante');
      if (btnComp) {
        const reserva = await window.BookiaData.ReservasRepo.getById(btnComp.dataset.id);
        if (reserva) UI.descargarComprobante(reserva, session.nombre);
        return;
      }
      const btn = e.target.closest('.btn-cancelar-reserva');
      if (!btn) return;
      const ok = await ReservasController.cancelarReserva(btn.dataset.id);
      if (ok) renderReservas();
    });

    const formPerfil = document.getElementById('formPerfil');
    if (formPerfil) {
      try {
        const user = await UsuariosRepo.getById(session.id);
        if (user) {
          const fn = document.getElementById('pnombre');
          const fe = document.getElementById('pemail');
          const ft = document.getElementById('ptelefono');
          if (fn) fn.value = user.nombre;
          if (fe) fe.value = user.email;
          if (ft) ft.value = user.telefono || '';
        }
      } catch(e) { /* silencioso */ }

      formPerfil.addEventListener('submit', async e => {
        e.preventDefault();
        UI.clearMessage('perfil-msg');
        const nombre   = document.getElementById('pnombre').value.trim();
        const telefono = document.getElementById('ptelefono').value.trim();
        if (!nombre) { UI.showFieldError('pnombre', 'El nombre es obligatorio'); return; }
        try {
          await UsuariosRepo.update(session.id, { nombre, telefono });
          Session.set({ ...session, nombre });
          UI.showMessage('perfil-msg', '✅ Perfil actualizado correctamente', 'success');
          const hn = document.getElementById('hero-nombre');
          if (hn) hn.textContent = nombre;
        } catch(e) {
          UI.showMessage('perfil-msg', '❌ Error al actualizar el perfil', 'error');
        }
      });
    }
  },
};


/* =====================================================
   CONTROLADOR DE CONTACTO (contacto.html)
   ===================================================== */

const ContactoController = {
  init() {
    AppGlobal.init();
    const UI = window.BookiaUI;
    const { validators } = UI;
    const form = document.getElementById('contactoForm');
    if (!form) return;

    const session = window.BookiaData.Session.get();
    if (session) {
      form.querySelector('#cnombre').value = session.nombre;
      form.querySelector('#cemail').value  = session.email;
    }

    form.addEventListener('submit', e => {
      e.preventDefault();
      UI.clearAllFieldErrors(form);
      UI.clearMessage('contacto-msg');

      const rules = {
        cnombre:  [validators.required(), validators.minLen(3)],
        cemail:   [validators.required(), validators.email()],
        casunto:  [validators.required()],
        cmensaje: [validators.required(), validators.minLen(10)],
      };
      const { valid, errors } = UI.validateForm(rules);
      Object.entries(errors).forEach(([id, msg]) => UI.showFieldError(id, msg));
      if (!valid) return;

      // Validar CAPTCHA si está presente
      if (typeof BookiaCaptcha !== 'undefined' && !BookiaCaptcha.isVerified()) {
        const capErr = document.getElementById('captcha-error');
        if (capErr) capErr.textContent = 'Por favor completa la verificación de seguridad';
        BookiaCaptcha.show();
        return;
      }

      UI.showMessage('contacto-msg',
        '✅ <strong>¡Mensaje enviado!</strong> Nos comunicaremos contigo en menos de 24 horas.', 'success');
      form.reset();
    });

    form.querySelectorAll('input,textarea').forEach(el => {
      el.addEventListener('input', () => UI.clearFieldError(el.id));
    });
  },
};


/* =====================================================
   CONTROLADOR ADMIN (admin.php)
   ===================================================== */

const AdminController = {
  currentSection: 'dashboard',
  librosPage: 1,
  ITEMS_PER_PAGE: 10,

  init() {
    AppGlobal.init();
    const { Session } = window.BookiaData;
    const UI = window.BookiaUI;

    // Verificar permisos
    const session = Session.get();
    if (!session) {
      UI.toast('Debes iniciar sesión para acceder al panel', 'warning');
      setTimeout(() => window.location.href = 'login.php', 1000);
      return;
    }
    if (session.rol !== 'admin') {
      UI.toast('Acceso restringido a administradores', 'error');
      setTimeout(() => window.location.href = 'perfil.php', 1000);
      return;
    }

    // Mostrar nombre del admin
    document.querySelectorAll('[data-admin-nombre]').forEach(el => el.textContent = session.nombre.split(' ')[0]);

    // Navegación del panel — usar referencia a this correctamente
    const self = this;
    document.querySelectorAll('.admin-nav a').forEach(link => {
      link.addEventListener('click', e => {
        e.preventDefault();
        const section = link.dataset.section;
        if (section) self.showSection(section);
      });
    });

    // Mostrar sección según hash
    const hash = window.location.hash.replace('#', '');
    this.showSection(hash || 'dashboard');

    // Actualizar badges sidebar
    this._updateSidebarBadges();

    // Escuchar cambios de datos
    window.addEventListener('bookia:datachange', () => {
      this.refreshCurrentSection();
    });
  },

  showSection(section) {
    this.currentSection = section;
    document.querySelectorAll('.admin-section').forEach(s => {
      /* Corrección Práctica 2 — Parte 3.2:
         Se usa la clase CSS 'admin-section--oculta' (visibility:hidden + height:0)
         en lugar de display:none, cumpliendo el requisito de transición sin display:none */
      if (s.id === 'section-' + section) {
        s.classList.remove('admin-section--oculta');
        s.removeAttribute('aria-hidden');
      } else {
        s.classList.add('admin-section--oculta');
        s.setAttribute('aria-hidden', 'true');
      }
    });
    document.querySelectorAll('.admin-nav a').forEach(l => {
      l.classList.toggle('active', l.dataset.section === section);
    });
    // Update hash without triggering scroll
    history.replaceState(null, '', '#' + section);
    // Update breadcrumb
    const bcLabels = { dashboard:'Dashboard', libros:'Libros', reservas:'Reservas', usuarios:'Usuarios' };
    const bcEl = document.getElementById('admin-bc-current');
    if (bcEl) bcEl.textContent = bcLabels[section] || section;
    // Call the render method for this section
    const methodName = 'render' + section.charAt(0).toUpperCase() + section.slice(1);
    if (typeof this[methodName] === 'function') {
      this[methodName]();
    }
  },

  refreshCurrentSection() {
    this._updateSidebarBadges();
    this.showSection(this.currentSection);
  },

  async _updateSidebarBadges() {
    const { LibrosRepo, ReservasRepo } = window.BookiaData;
    const bl = document.getElementById('sidebar-badge-libros');
    const br = document.getElementById('sidebar-badge-reservas');
    try {
      if (bl) bl.textContent = (await LibrosRepo.getAll()).length;
      if (br) {
        const stats = await ReservasRepo.getStats();
        br.textContent = stats.pendientes + stats.listas;
      }
    } catch(e) { /* silencioso */ }
  },

  /* ---- DASHBOARD ---- */
  async renderDashboard() {
    const { LibrosRepo, UsuariosRepo, ReservasRepo } = window.BookiaData;

    try {
      const [lStats, uStats, rStats] = await Promise.all([
        LibrosRepo.getStats(),
        UsuariosRepo.getStats(),
        ReservasRepo.getStats(),
      ]);

      const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
      set('dash-total-libros',        lStats.total);
      set('dash-libros-disponibles',  lStats.disponibles);
      set('dash-libros-agotados',     lStats.agotados);
      set('dash-total-usuarios',      uStats.total);
      set('dash-total-reservas',      rStats.total);
      set('dash-reservas-pendientes', rStats.pendientes);

      const bl = document.getElementById('sidebar-badge-libros');
      const br = document.getElementById('sidebar-badge-reservas');
      if (bl) bl.textContent = lStats.total;
      if (br) br.textContent = rStats.pendientes + rStats.listas;

      const tbody = document.getElementById('tabla-ultimas-reservas');
      if (tbody) {
        const [usuarios, reservas] = await Promise.all([
          UsuariosRepo.getAll(),
          ReservasRepo.search({ sortBy: 'fechaReserva', sortDir: 'desc' }),
        ]);
        const usMap = {}; usuarios.forEach(u => usMap[u.id] = u.nombre);
        const ultimas = reservas.slice(0, 5);
        const estadoClasses = { pendiente:'pill-yellow', lista:'pill-green', recogida:'pill-blue', cancelada:'pill-red' };
        tbody.innerHTML = '';
        if (!ultimas.length) {
          tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#9CA3AF;padding:20px">Sin reservas recientes</td></tr>';
        } else {
          ultimas.forEach(r => {
            const tr = document.createElement('tr');
            const fecha = r.fechaReserva ? new Date(r.fechaReserva).toLocaleDateString('es-MX') : '—';
            tr.innerHTML = `
              <td><strong>${r.tituloLibro}</strong><br><small style="color:#6B7280">${r.autorLibro}</small></td>
              <td>${usMap[r.usuarioId] || '—'}</td>
              <td>${fecha}</td>
              <td>${r.fechaRecogida || '—'}</td>
              <td><span class="pill ${estadoClasses[r.estado] || 'pill-gray'}">${r.estado}</span></td>
              <td><code style="font-size:11px;background:#f3f4f6;padding:2px 6px;border-radius:4px">${r.codigoRecogida || '—'}</code></td>`;
            tbody.appendChild(tr);
          });
        }
      }
    } catch(e) {
      console.error('[Admin] Dashboard error:', e);
    }
  },

  /* ---- LIBROS ---- */
  _librosInitialized: false,

  renderLibros() {
    const { LibrosRepo } = window.BookiaData;
    const UI = window.BookiaUI;

    const searchInput  = document.getElementById('search-admin-libros');
    const filtroGenero = document.getElementById('filtro-admin-genero');
    const tbody        = document.getElementById('tabla-libros');
    const pagination   = document.getElementById('libros-pagination');
    const paginationInfo = document.getElementById('libros-pagination-info');
    const totalEl      = document.getElementById('libros-total');

    const bl = document.getElementById('sidebar-badge-libros');

    const render = async () => {
      const q       = searchInput ? searchInput.value : '';
      const genero  = filtroGenero ? filtroGenero.value : '';
      try {
        const all     = await LibrosRepo.search({ q, genero });
        const total   = all.length;
        const totalPags = Math.max(1, Math.ceil(total / this.ITEMS_PER_PAGE));
        if (this.librosPage > totalPags) this.librosPage = 1;
        const start   = (this.librosPage - 1) * this.ITEMS_PER_PAGE;
        const slice   = all.slice(start, start + this.ITEMS_PER_PAGE);

        if (bl) bl.textContent = total;
        if (totalEl) totalEl.textContent = total + ' libro' + (total !== 1 ? 's' : '') + ' en catálogo';
        if (paginationInfo) paginationInfo.textContent = `Mostrando ${start + 1}–${Math.min(start + this.ITEMS_PER_PAGE, total)} de ${total}`;

        if (tbody) {
          if (!slice.length) {
            tbody.innerHTML = `<tr><td colspan="6"><div class="empty-state" style="padding:32px"><div class="empty-icon">📚</div><p>No se encontraron libros</p></div></td></tr>`;
          } else {
            tbody.innerHTML = '';
            slice.forEach(libro => {
              const tr = document.createElement('tr');
              const dispClass = libro.disponibles === 0 ? 'pill-red' : libro.disponibles <= 2 ? 'pill-yellow' : 'pill-green';
              const FALLBACK_THUMB = `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='36' height='50' viewBox='0 0 36 50'%3E%3Crect width='36' height='50' fill='%236B0F2A'/%3E%3Ctext x='18' y='30' font-size='18' text-anchor='middle' fill='rgba(255,255,255,0.7)'%3E%F0%9F%93%9A%3C/text%3E%3C/svg%3E`;
              const imgSrc = libro.imagen || FALLBACK_THUMB;
              tr.innerHTML = `
                <td>
                  <div class="libro-td-info">
                    <img class="libro-thumb" src="${imgSrc}" alt="${libro.titulo}" onerror="this.src='${FALLBACK_THUMB}'" loading="lazy">
                    <div class="libro-td-text">
                      <strong>${libro.titulo}</strong>
                      <small>${libro.autor}</small>
                    </div>
                  </div>
                </td>
                <td><span class="pill pill-blue">${libro.genero}</span></td>
                <td>${libro.anio}</td>
                <td style="font-size:11.5px;color:#6b7280">${libro.isbn || '—'}</td>
                <td><span class="pill ${dispClass}">${libro.disponibles}</span></td>
                <td>
                  <div class="table-actions">
                    <button class="btn btn-sm btn-ghost btn-edit-libro" data-id="${libro.id}" title="Editar libro">✏️ Editar</button>
                    <button class="btn btn-sm btn-danger btn-del-libro" data-id="${libro.id}" title="Eliminar libro">🗑</button>
                  </div>
                </td>`;
              tbody.appendChild(tr);
            });
          }
        }

        if (pagination) {
          pagination.innerHTML = '';
          pagination.className = 'pagination-btns';
          for (let i = 1; i <= totalPags; i++) {
            const btn = document.createElement('button');
            btn.textContent = i;
            if (i === this.librosPage) btn.classList.add('active');
            btn.addEventListener('click', () => { this.librosPage = i; render(); });
            pagination.appendChild(btn);
          }
        }
      } catch(e) {
        if (tbody) tbody.innerHTML = `<tr><td colspan="6" style="color:#EF4444;padding:20px">Error al cargar libros.</td></tr>`;
      }
    };

    if (!this._librosInitialized) {
      this._librosInitialized = true;

      let debounce;
      if (searchInput) {
        searchInput.addEventListener('input', () => {
          clearTimeout(debounce);
          debounce = setTimeout(() => { this.librosPage = 1; render(); }, 280);
        });
      }
      if (filtroGenero) {
        filtroGenero.addEventListener('change', () => { this.librosPage = 1; render(); });
      }

      const btnNuevo = document.getElementById('btn-nuevo-libro');
      if (btnNuevo) {
        btnNuevo.addEventListener('click', () => this.openLibroModal(null, render));
      }

      if (tbody) {
        tbody.addEventListener('click', async e => {
          const btnEdit = e.target.closest('.btn-edit-libro');
          const btnDel  = e.target.closest('.btn-del-libro');
          if (btnEdit) {
            const libro = await LibrosRepo.getById(btnEdit.dataset.id);
            if (libro) this.openLibroModal(libro, render);
          }
          if (btnDel) {
            const ok = await UI.confirm({
              title: 'Eliminar libro',
              message: '¿Seguro que deseas eliminar este libro? Esta acción no se puede deshacer.',
              confirmText: 'Eliminar',
              danger: true,
            });
            if (ok) {
              await LibrosRepo.delete(btnDel.dataset.id);
              UI.toast('Libro eliminado', 'success');
              render();
            }
          }
        });
      }
    }

    render();
  },

  openLibroModal(libro, onSave) {
    const { LibrosRepo } = window.BookiaData;
    const UI = window.BookiaUI;
    const isEdit = !!libro;

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal" style="max-width:560px">
        <div class="modal-header">
          <span class="modal-icon">${isEdit ? '✏️' : '📗'}</span>
          <h3>${isEdit ? 'Editar libro' : 'Nuevo libro'}</h3>
        </div>
        <div class="modal-body" style="padding:0">
          <form id="modal-libro-form" class="admin-form">
            <div class="form-row">
              <div class="form-group">
                <label>Título <span class="required">*</span></label>
                <input id="ml-titulo" value="${libro?.titulo || ''}" placeholder="Título del libro" required>
                <p class="field-error" id="ml-titulo-error">⚠ Campo requerido</p>
              </div>
              <div class="form-group">
                <label>Autor <span class="required">*</span></label>
                <input id="ml-autor" value="${libro?.autor || ''}" placeholder="Nombre del autor" required>
                <p class="field-error" id="ml-autor-error">⚠ Campo requerido</p>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>Género <span class="required">*</span></label>
                <select id="ml-genero">
                  <option value="Ficción"    ${libro?.genero==='Ficción'    ?'selected':''}>Ficción</option>
                  <option value="No Ficción" ${libro?.genero==='No Ficción' ?'selected':''}>No Ficción</option>
                  <option value="Infantil"   ${libro?.genero==='Infantil'   ?'selected':''}>Infantil</option>
                </select>
              </div>
              <div class="form-group">
                <label>Año</label>
                <input id="ml-anio" type="number" min="1000" max="2030" value="${libro?.anio || new Date().getFullYear()}" placeholder="Año">
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>Disponibles <span class="required">*</span></label>
                <input id="ml-disponibles" type="number" min="0" value="${libro?.disponibles ?? 1}" placeholder="0">
                <p class="field-error" id="ml-disponibles-error">⚠ Número requerido</p>
              </div>
              <div class="form-group">
                <label>ISBN</label>
                <input id="ml-isbn" value="${libro?.isbn || ''}" placeholder="ISBN (opcional)">
              </div>
            </div>
            <div class="form-group">
              <label>URL de imagen</label>
              <input id="ml-imagen" value="${libro?.imagen || ''}" placeholder="https://...">
            </div>
            <div class="form-group">
              <label>Descripción</label>
              <textarea id="ml-descripcion" rows="3" placeholder="Breve descripción del libro">${libro?.descripcion || ''}</textarea>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" id="modal-cancel-libro">Cancelar</button>
          <button class="btn" id="modal-save-libro">${isEdit ? '💾 Guardar cambios' : '➕ Agregar libro'}</button>
        </div>
      </div>`;

    document.body.appendChild(overlay);

    overlay.querySelector('#modal-cancel-libro').addEventListener('click', () => overlay.remove());
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });

    overlay.querySelector('#modal-save-libro').addEventListener('click', async () => {
      const titulo      = document.getElementById('ml-titulo').value.trim();
      const autor       = document.getElementById('ml-autor').value.trim();
      const disponibles = parseInt(document.getElementById('ml-disponibles').value);

      if (!titulo) { UI.showFieldError('ml-titulo', 'El título es obligatorio'); return; }
      if (!autor)  { UI.showFieldError('ml-autor',  'El autor es obligatorio');  return; }
      if (isNaN(disponibles) || disponibles < 0) { UI.showFieldError('ml-disponibles', 'Número válido requerido'); return; }

      const data = {
        titulo, autor,
        genero:      document.getElementById('ml-genero').value,
        anio:        parseInt(document.getElementById('ml-anio').value),
        disponibles,
        isbn:        document.getElementById('ml-isbn').value.trim(),
        imagen:      document.getElementById('ml-imagen').value.trim(),
        descripcion: document.getElementById('ml-descripcion').value.trim(),
      };

      try {
        if (isEdit) {
          await LibrosRepo.update(libro.id, data);
          UI.toast('Libro actualizado correctamente', 'success');
        } else {
          await LibrosRepo.insert(data);
          UI.toast('Libro agregado al catálogo', 'success');
        }
        overlay.remove();
        onSave?.();
      } catch(e) {
        UI.toast(e.message || 'Error al guardar el libro', 'error');
      }
    });
  },

  /* ---- USUARIOS ---- */
  _usuariosInitialized: false,

  renderUsuarios() {
    const { UsuariosRepo, ReservasRepo } = window.BookiaData;
    const UI = window.BookiaUI;

    const searchInput = document.getElementById('search-admin-usuarios');
    const filtroRol   = document.getElementById('filtro-admin-rol');
    const tbody       = document.getElementById('tabla-usuarios');
    const totalEl     = document.getElementById('usuarios-total');

    const render = async () => {
      const q   = searchInput ? searchInput.value : '';
      const rol = filtroRol ? filtroRol.value : '';
      try {
        const users = await UsuariosRepo.search({ q, rol });
        if (totalEl) totalEl.textContent = users.length + ' usuario' + (users.length !== 1 ? 's' : '');

        if (tbody) {
          if (!users.length) {
            tbody.innerHTML = `<tr><td colspan="6"><div class="empty-state" style="padding:32px"><div class="empty-icon">👤</div><p>No se encontraron usuarios</p></div></td></tr>`;
            return;
          }
          // Cargar reservas de todos los usuarios en paralelo
          const reservasPorUsuario = await Promise.all(
            users.map(u => ReservasRepo.getByUsuario(u.id).catch(() => []))
          );
          tbody.innerHTML = '';
          users.forEach((u, i) => {
            const tr = document.createElement('tr');
            const rolClass = u.rol === 'admin' ? 'pill-purple' : 'pill-blue';
            const reservasUsuario = reservasPorUsuario[i] || [];
            const activas = reservasUsuario.filter(r => ['pendiente','lista'].includes(r.estado)).length;
            tr.innerHTML = `
              <td><strong>${u.nombre}</strong></td>
              <td>${u.email}</td>
              <td>${u.telefono || '—'}</td>
              <td>
                <span title="${reservasUsuario.length} total" style="font-size:13px;color:#374151">
                  ${reservasUsuario.length} total${activas ? ` · <span style="color:#16a34a">${activas} activa${activas!==1?'s':''}</span>` : ''}
                </span>
              </td>
              <td><span class="pill ${rolClass}">${u.rol === 'admin' ? '⭐ Admin' : '👤 Usuario'}</span></td>
              <td>
                <div class="table-actions">
                  <button class="btn btn-sm btn-ghost btn-edit-user" data-id="${u.id}" title="Editar usuario">✏️</button>
                  <button class="btn btn-sm btn-danger btn-del-user"  data-id="${u.id}" title="Eliminar usuario">🗑</button>
                </div>
              </td>`;
            tbody.appendChild(tr);
          });
        }
      } catch(e) {
        if (tbody) tbody.innerHTML = `<tr><td colspan="6" style="color:#EF4444;padding:20px">Error al cargar usuarios.</td></tr>`;
      }
    };

    if (!this._usuariosInitialized) {
      this._usuariosInitialized = true;

      let debounce;
      if (searchInput) {
        searchInput.addEventListener('input', () => {
          clearTimeout(debounce); debounce = setTimeout(render, 280);
        });
      }
      if (filtroRol) {
        filtroRol.addEventListener('change', render);
      }

      if (tbody) {
        tbody.addEventListener('click', async e => {
          const btnDel  = e.target.closest('.btn-del-user');
          const btnEdit = e.target.closest('.btn-edit-user');
          if (btnDel) {
            const session = window.BookiaData.Session.get();
            if (btnDel.dataset.id === session?.id) { UI.toast('No puedes eliminar tu propia cuenta', 'warning'); return; }
            const ok = await UI.confirm({ title: 'Eliminar usuario', message: '¿Seguro que deseas eliminar este usuario?', confirmText: 'Eliminar', danger: true });
            if (ok) { await UsuariosRepo.delete(btnDel.dataset.id); UI.toast('Usuario eliminado', 'success'); render(); }
          }
          if (btnEdit) {
            const user = await UsuariosRepo.getById(btnEdit.dataset.id);
            if (user) this.openUsuarioModal(user, render);
          }
        });
      }

      const btnNuevo = document.getElementById('btn-nuevo-usuario');
      if (btnNuevo) btnNuevo.addEventListener('click', () => this.openUsuarioModal(null, render));
    }

    render();
  },

  openUsuarioModal(user, onSave) {
    const { UsuariosRepo } = window.BookiaData;
    const UI = window.BookiaUI;
    const isEdit = !!user;

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal" style="max-width:460px">
        <div class="modal-header">
          <span class="modal-icon">${isEdit ? '✏️' : '👤'}</span>
          <h3>${isEdit ? 'Editar usuario' : 'Nuevo usuario'}</h3>
        </div>
        <div class="modal-body" style="padding:0">
          <form id="modal-user-form" class="admin-form">
            <div class="form-group">
              <label>Nombre completo <span class="required">*</span></label>
              <input id="mu-nombre" value="${user?.nombre || ''}" placeholder="Nombre completo" required>
            </div>
            <div class="form-group">
              <label>Correo electrónico <span class="required">*</span></label>
              <input id="mu-email" type="email" value="${user?.email || ''}" placeholder="correo@ejemplo.com" required>
            </div>
            <div class="form-group">
              <label>Teléfono</label>
              <input id="mu-telefono" value="${user?.telefono || ''}" placeholder="10 dígitos">
            </div>
            <div class="form-group">
              <label>Rol</label>
              <select id="mu-rol">
                <option value="usuario" ${user?.rol==='usuario'?'selected':''}>Usuario</option>
                <option value="admin"   ${user?.rol==='admin'  ?'selected':''}>Administrador</option>
              </select>
            </div>
            ${!isEdit ? `
            <div class="form-group">
              <label>Contraseña <span class="required">*</span></label>
              <input id="mu-password" type="password" placeholder="Mínimo 8 caracteres" minlength="8">
            </div>` : ''}
          </form>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" id="modal-cancel-user">Cancelar</button>
          <button class="btn" id="modal-save-user">${isEdit ? '💾 Guardar' : '➕ Crear usuario'}</button>
        </div>
      </div>`;

    document.body.appendChild(overlay);
    overlay.querySelector('#modal-cancel-user').addEventListener('click', () => overlay.remove());
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });

    overlay.querySelector('#modal-save-user').addEventListener('click', async () => {
      const nombre  = document.getElementById('mu-nombre').value.trim();
      const email   = document.getElementById('mu-email').value.trim();
      if (!nombre || !email) { UI.toast('Nombre y correo son obligatorios', 'error'); return; }

      const data = {
        nombre, email,
        telefono: document.getElementById('mu-telefono').value.trim(),
        rol:      document.getElementById('mu-rol').value,
      };

      try {
        if (isEdit) {
          await UsuariosRepo.update(user.id, data);
          UI.toast('Usuario actualizado', 'success');
        } else {
          const pass = document.getElementById('mu-password')?.value;
          if (!pass || pass.length < 8) { UI.toast('La contraseña debe tener mínimo 8 caracteres', 'error'); return; }
          await UsuariosRepo.insert({ ...data, password: pass });
          UI.toast('Usuario creado correctamente', 'success');
        }
        overlay.remove();
        onSave?.();
      } catch(e) {
        UI.toast(e.message || 'Error al guardar el usuario', 'error');
      }
    });
  },

  /* ---- RESERVAS ---- */
  _reservasInitialized: false,

  async renderReservas() {
    const { ReservasRepo, UsuariosRepo } = window.BookiaData;
    const UI = window.BookiaUI;

    const searchInput  = document.getElementById('search-admin-reservas');
    const filtroEstado = document.getElementById('filtro-admin-estado');
    const tbody        = document.getElementById('tabla-reservas');
    const totalEl      = document.getElementById('reservas-total');
    const statsRow     = document.getElementById('reservas-stats-row');

    // Estadísticas de reservas clicables
    try {
      const [rStats, usuarios] = await Promise.all([
        ReservasRepo.getStats(),
        UsuariosRepo.getAll(),
      ]);

      const br = document.getElementById('sidebar-badge-reservas');
      if (br) br.textContent = rStats.pendientes + rStats.listas;

      if (statsRow) {
        const statsData = [
          { label: 'Total',      val: rStats.total,     bg: '#ede9fe', emoji: '📋', estado: '' },
          { label: 'Pendientes', val: rStats.pendientes, bg: '#fef3c7', emoji: '⏳', estado: 'pendiente' },
          { label: 'Listas',     val: rStats.listas,     bg: '#dcfce7', emoji: '✅', estado: 'lista' },
          { label: 'Recogidas',  val: rStats.recogidas,  bg: '#dbeafe', emoji: '📦', estado: 'recogida' },
          { label: 'Canceladas', val: rStats.canceladas, bg: '#fee2e2', emoji: '❌', estado: 'cancelada' },
        ];
        statsRow.innerHTML = '';
        statsData.forEach(s => {
          const card = document.createElement('div');
          card.className = 'stat-card';
          card.style.cssText = 'cursor:pointer;transition:transform .15s,box-shadow .15s';
          card.innerHTML = `
            <div class="stat-icon" style="background:${s.bg};font-size:18px">${s.emoji}</div>
            <div class="stat-info"><h4 style="font-size:22px">${s.val}</h4><p>${s.label}</p></div>`;
          card.addEventListener('click', () => {
            if (filtroEstado) {
              filtroEstado.value = s.estado;
              filtroEstado.dispatchEvent(new Event('change'));
            }
          });
          card.addEventListener('mouseenter', () => { card.style.transform = 'translateY(-2px)'; card.style.boxShadow = '0 6px 18px rgba(0,0,0,.1)'; });
          card.addEventListener('mouseleave', () => { card.style.transform = ''; card.style.boxShadow = ''; });
          statsRow.appendChild(card);
        });
      }

      const usMap = {};
      usuarios.forEach(u => usMap[u.id] = u);

      const render = async () => {
        const q      = searchInput?.value || '';
        const estado = filtroEstado?.value || '';
        try {
          const reservas = await ReservasRepo.search({ q, estado });
          if (totalEl) totalEl.textContent = `${reservas.length} reserva${reservas.length !== 1 ? 's' : ''}`;

          if (tbody) {
            if (!reservas.length) {
              tbody.innerHTML = `<tr><td colspan="7"><div class="empty-state" style="padding:32px"><div class="empty-icon">🔖</div><p>No hay reservas con los filtros aplicados</p></div></td></tr>`;
              return;
            }
            tbody.innerHTML = '';
            reservas.forEach(r => {
              const tr = document.createElement('tr');
              const estadoClasses = { pendiente:'pill-yellow', lista:'pill-green', recogida:'pill-blue', cancelada:'pill-red' };
              const estadoEmojis  = { pendiente:'⏳', lista:'✅', recogida:'📦', cancelada:'❌' };
              const fecha = r.fechaReserva ? new Date(r.fechaReserva).toLocaleDateString('es-MX') : '—';
              const usuario = usMap[r.usuarioId];
              const usuarioInfo = usuario
                ? `<strong>${usuario.nombre}</strong><br><small style="color:#6b7280">${usuario.email}</small>`
                : `<span style="color:#9ca3af">${r.usuarioId}</span>`;

              tr.innerHTML = `
                <td>
                  <strong style="display:block">${r.tituloLibro}</strong>
                  <small style="color:#6b7280">${r.autorLibro}</small>
                </td>
                <td>${usuarioInfo}</td>
                <td>${fecha}</td>
                <td>${r.fechaRecogida || '—'}</td>
                <td>
                  <code style="font-size:13px;font-weight:800;background:#fdf4f6;color:#6B0F2A;padding:4px 10px;border-radius:6px;letter-spacing:1.5px;border:1px solid rgba(107,15,42,0.15)">${r.codigoRecogida || '—'}</code>
                </td>
                <td><span class="pill ${estadoClasses[r.estado] || 'pill-gray'}">${estadoEmojis[r.estado] || ''} ${r.estado}</span></td>
                <td>
                  <div class="table-actions">
                    <button class="btn btn-sm btn-ghost btn-comprobante-admin" data-id="${r.id}" title="Descargar comprobante PDF">📄 PDF</button>
                    <button class="btn btn-sm btn-ghost btn-edit-reserva" data-id="${r.id}" title="Cambiar estado">✏️</button>
                    <button class="btn btn-sm btn-danger btn-del-reserva" data-id="${r.id}" title="Eliminar reserva">🗑</button>
                  </div>
                </td>`;
              tbody.appendChild(tr);
            });
          }
        } catch(e) {
          if (tbody) tbody.innerHTML = `<tr><td colspan="7" style="color:#EF4444;padding:20px">Error al cargar reservas.</td></tr>`;
        }
      };

      await render();

      if (!this._reservasInitialized) {
        this._reservasInitialized = true;

        let debounce;
        if (searchInput) searchInput.addEventListener('input', () => { clearTimeout(debounce); debounce = setTimeout(render, 280); });
        if (filtroEstado) filtroEstado.addEventListener('change', render);

        if (tbody) {
          tbody.addEventListener('click', async e => {
            const btnComp = e.target.closest('.btn-comprobante-admin');
            if (btnComp) {
              const r = await ReservasRepo.getById(btnComp.dataset.id);
              const u = r ? await UsuariosRepo.getById(r.usuarioId) : null;
              if (r) UI.descargarComprobante(r, u?.nombre || '—');
              return;
            }
            const btnDel  = e.target.closest('.btn-del-reserva');
            const btnEdit = e.target.closest('.btn-edit-reserva');
            if (btnDel) {
              const ok = await UI.confirm({ title: 'Eliminar reserva', message: '¿Seguro que deseas eliminar esta reserva?', confirmText: 'Eliminar', danger: true });
              if (ok) {
                await ReservasRepo.delete(btnDel.dataset.id);
                UI.toast('Reserva eliminada', 'success');
                this._reservasInitialized = false;
                this.renderReservas();
              }
            }
            if (btnEdit) {
              const reserva = await ReservasRepo.getById(btnEdit.dataset.id);
              if (reserva) this.openReservaEstadoModal(reserva, () => {
                this._reservasInitialized = false;
                this.renderReservas();
              });
            }
          });
        }
      }
    } catch(e) {
      console.error('[Admin] renderReservas error:', e);
    }
  },
  openReservaEstadoModal(reserva, onSave) {
    const { ReservasRepo, UsuariosRepo } = window.BookiaData;
    const UI = window.BookiaUI;
    const usuario = UsuariosRepo.getById(reserva.usuarioId);

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal" style="max-width:480px">
        <div class="modal-header">
          <span class="modal-icon">🔖</span>
          <h3>Gestionar reserva</h3>
        </div>
        <div class="modal-body">
          <!-- Datos del libro -->
          <div style="background:#f9fafb;border-radius:10px;padding:14px;margin-bottom:16px">
            <p style="font-size:15px;font-weight:700;color:#111827;margin-bottom:4px">${reserva.tituloLibro}</p>
            <p style="font-size:13px;color:#6b7280">✍️ ${reserva.autorLibro}</p>
            ${usuario ? `<p style="font-size:13px;color:#6b7280;margin-top:6px">👤 ${usuario.nombre} · ${usuario.email}</p>` : ''}
          </div>
          <!-- Estado actual -->
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
            <div>
              <label style="font-size:12px;font-weight:700;text-transform:uppercase;color:#9ca3af;display:block;margin-bottom:6px">Estado de la reserva</label>
              <select id="reserva-estado" style="width:100%;padding:10px;border:1.5px solid #e5e7eb;border-radius:8px;font-family:inherit;font-size:14px">
                <option value="pendiente" ${reserva.estado==='pendiente'?'selected':''}>⏳ Pendiente</option>
                <option value="lista"     ${reserva.estado==='lista'    ?'selected':''}>✅ Lista para recoger</option>
                <option value="recogida"  ${reserva.estado==='recogida' ?'selected':''}>📦 Recogida</option>
                <option value="cancelada" ${reserva.estado==='cancelada'?'selected':''}>❌ Cancelada</option>
              </select>
            </div>
            <div>
              <label style="font-size:12px;font-weight:700;text-transform:uppercase;color:#9ca3af;display:block;margin-bottom:6px">Fecha de recogida</label>
              <input type="date" id="reserva-fecha" value="${reserva.fechaRecogida || ''}" style="width:100%;padding:10px;border:1.5px solid #e5e7eb;border-radius:8px;font-family:inherit;font-size:14px;box-sizing:border-box">
            </div>
          </div>
          <div style="margin-top:14px">
            <label style="font-size:12px;font-weight:700;text-transform:uppercase;color:#9ca3af;display:block;margin-bottom:6px">Notas internas</label>
            <textarea id="reserva-notas" rows="2" placeholder="Notas opcionales para esta reserva..." style="width:100%;padding:10px;border:1.5px solid #e5e7eb;border-radius:8px;font-family:inherit;font-size:14px;resize:vertical;box-sizing:border-box">${reserva.notas || ''}</textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" id="modal-cancel-res">Cancelar</button>
          <button class="btn btn-danger" id="modal-cancel-reserva-btn">❌ Cancelar reserva</button>
          <button class="btn" id="modal-save-res">💾 Guardar cambios</button>
        </div>
      </div>`;

    document.body.appendChild(overlay);
    overlay.querySelector('#modal-cancel-res').addEventListener('click', () => overlay.remove());
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });

    // Botón "Cancelar reserva" rápido
    overlay.querySelector('#modal-cancel-reserva-btn').addEventListener('click', async () => {
      const ok = await UI.confirm({ title: 'Cancelar reserva', message: '¿Estás seguro de cancelar esta reserva?', confirmText: 'Sí, cancelar', danger: true });
      if (ok) {
        try {
          await ReservasRepo.update(reserva.id, { estado: 'cancelada' });
          UI.toast('Reserva cancelada', 'info');
          overlay.remove();
          onSave?.();
        } catch(e) { UI.toast('Error al cancelar la reserva', 'error'); }
      }
    });

    overlay.querySelector('#modal-save-res').addEventListener('click', async () => {
      const estado = document.getElementById('reserva-estado').value;
      const fecha  = document.getElementById('reserva-fecha').value;
      const notas  = document.getElementById('reserva-notas').value.trim();
      try {
        await ReservasRepo.update(reserva.id, { estado, fechaRecogida: fecha, notas });
        UI.toast('Reserva actualizada correctamente', 'success');
        overlay.remove();
        onSave?.();
      } catch(e) { UI.toast('Error al actualizar la reserva', 'error'); }
    });
  },

};


/* =====================================================
   BOOTSTRAP — Detectar página y lanzar controlador
   ===================================================== */

document.addEventListener('DOMContentLoaded', () => {
  const page = window.location.pathname.split('/').pop() || 'index.php';

  // Expose for modal access
  window.ReservasController = ReservasController;

  const controllers = {
    'index.php':     () => HomeController.init(),
    '':               () => HomeController.init(),
    'catalogo.php':  () => CatalogoController.init(),
    'reservar.php':  () => ReservarController.init(),
    'login.php':     () => LoginController.init(),
    'registro.php':  () => RegistroController.init(),
    'perfil.php':    () => PerfilController.init(),
    'contacto.html':  () => ContactoController.init(),
    'contacto.php':   () => ContactoController.init(),
    'admin.php':     () => AdminController.init(),
    'dashboard.php': () => AppGlobal.init(),   // navbar + sesión activos
  };

  const controller = controllers[page];
  if (controller) {
    controller();
  } else {
    // Páginas sin controlador específico (servicios, errores)
    AppGlobal.init();
  }
});

