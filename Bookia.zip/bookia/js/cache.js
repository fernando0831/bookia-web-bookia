/**
 * BOOKIA — cache.js | Caché Manual en Memoria
 * Práctica 2 — Parte 2: Implementación Asíncrona Avanzada
 *
 * Evita llamadas repetidas a la API almacenando respuestas
 * con TTL (Time To Live) configurable.
 */
'use strict';

const BookiaCache = (() => {

  const _store = new Map(); // key → { value, expires }

  /**
   * Guarda un valor en caché
   * @param {string} key
   * @param {*} value
   * @param {number} ttl  milisegundos antes de expirar (default 5 min)
   */
  function set(key, value, ttl = 5 * 60 * 1000) {
    _store.set(key, { value, expires: Date.now() + ttl });
  }

  /**
   * Obtiene un valor si existe y no ha expirado
   * @returns {*|null}
   */
  function get(key) {
    const entry = _store.get(key);
    if (!entry) return null;
    if (Date.now() > entry.expires) {
      _store.delete(key);
      return null;
    }
    return entry.value;
  }

  /** Elimina una entrada */
  function del(key) { _store.delete(key); }

  /** Vacía toda la caché */
  function clear() { _store.clear(); }

  /** Cuántas entradas válidas hay en caché */
  function size() {
    const now = Date.now();
    let count = 0;
    for (const [k, v] of _store) {
      if (v.expires > now) count++;
      else _store.delete(k);
    }
    return count;
  }

  /**
   * Helper: obtiene de caché o ejecuta fn() y guarda el resultado
   * @param {string}   key
   * @param {Function} fn  función async que devuelve el dato
   * @param {number}   ttl
   */
  async function getOrFetch(key, fn, ttl) {
    const cached = get(key);
    if (cached !== null) {
      console.log(`[Cache HIT] ${key}`);
      return cached;
    }
    console.log(`[Cache MISS] ${key} — fetching…`);
    const data = await fn();
    set(key, data, ttl);
    return data;
  }

  return { set, get, del, clear, size, getOrFetch };
})();

window.BookiaCache = BookiaCache;
