/**
 * BOOKIA — carousel.js | Carrusel Avanzado sin Librerías
 * Práctica 2 — Parte 3.4
 *
 * Implementa:
 *  - Autoplay con pausa al hover
 *  - Controles manuales (prev / next)
 *  - Indicadores dinámicos
 *  - Transición con transform + translateX
 *  - Loop infinito simulado (clones)
 *  - Soporte táctil (touch events)
 */
'use strict';

class BookiaCarousel {
  /**
   * @param {HTMLElement|string} container  selector o elemento
   * @param {object} opts
   */
  constructor(container, opts = {}) {
    this.el = typeof container === 'string'
      ? document.querySelector(container)
      : container;

    if (!this.el) return;

    this.opts = {
      autoplay:  true,
      interval:  4000,
      speed:     500,
      loop:      true,
      ...opts,
    };

    this._build();
    this._bindEvents();
    if (this.opts.autoplay) this._startAutoplay();
  }

  /* ── Construcción DOM ──────────────────────────────────────── */

  _build() {
    const origSlides = Array.from(this.el.querySelectorAll('.carousel-slide'));
    if (!origSlides.length) return;

    this.total   = origSlides.length;
    this.current = 0;
    this._animating = false;

    // Wrapper interior
    this.track = document.createElement('div');
    this.track.className = 'carousel-track';

    // Clonar primero y último para loop infinito
    const firstClone = origSlides[0].cloneNode(true);
    const lastClone  = origSlides[this.total - 1].cloneNode(true);
    firstClone.setAttribute('aria-hidden', 'true');
    lastClone.setAttribute('aria-hidden', 'true');
    firstClone.classList.add('clone');
    lastClone.classList.add('clone');

    this.track.appendChild(lastClone);
    origSlides.forEach(s => this.track.appendChild(s));
    this.track.appendChild(firstClone);

    // Posición inicial (offset por el clon del final)
    this._offset = this.current + 1; // índice real en track
    this.track.style.cssText = `
      display: flex;
      will-change: transform;
      transition: transform ${this.opts.speed}ms cubic-bezier(0.45, 0, 0.55, 1);
    `;

    // Limpiar y reconstruir
    while (this.el.firstChild) this.el.removeChild(this.el.firstChild);
    this.el.appendChild(this.track);
    this.el.style.overflow = 'hidden';
    this.el.style.position = 'relative';

    // Tamaño de cada slide = 100% del contenedor
    this._allSlides = Array.from(this.track.querySelectorAll('.carousel-slide'));
    this._allSlides.forEach(s => {
      s.style.flex = `0 0 ${100 / (this.total + 2)}%`;
    });
    this.track.style.width = `${(this.total + 2) * 100}%`;
    this._allSlides.forEach(s => s.style.flex = `0 0 calc(100% / ${this.total + 2})`);

    this._goTo(this._offset, false);

    // Controles
    this._buildControls();
    this._buildDots();
    this._updateDots();
  }

  _buildControls() {
    const prev = document.createElement('button');
    prev.className = 'carousel-btn carousel-btn--prev';
    prev.innerHTML = '&#8249;';
    prev.setAttribute('aria-label', 'Anterior');

    const next = document.createElement('button');
    next.className = 'carousel-btn carousel-btn--next';
    next.innerHTML = '&#8250;';
    next.setAttribute('aria-label', 'Siguiente');

    this.el.appendChild(prev);
    this.el.appendChild(next);

    prev.addEventListener('click', () => this.prev());
    next.addEventListener('click', () => this.next());
  }

  _buildDots() {
    const dots = document.createElement('div');
    dots.className = 'carousel-dots';

    this.dots = Array.from({ length: this.total }, (_, i) => {
      const d = document.createElement('button');
      d.className = 'carousel-dot';
      d.setAttribute('aria-label', `Ir a slide ${i + 1}`);
      d.addEventListener('click', () => this.goToIndex(i));
      dots.appendChild(d);
      return d;
    });

    this.el.appendChild(dots);
  }

  _updateDots() {
    this.dots?.forEach((d, i) => {
      d.classList.toggle('active', i === this.current);
    });
  }

  /* ── Navegación ────────────────────────────────────────────── */

  _goTo(trackIdx, animated = true) {
    if (!animated) {
      this.track.style.transition = 'none';
    } else {
      this.track.style.transition = `transform ${this.opts.speed}ms cubic-bezier(0.45, 0, 0.55, 1)`;
    }

    const pct = -trackIdx * (100 / (this.total + 2));
    this.track.style.transform = `translateX(${pct}%)`;
    this._offset = trackIdx;
  }

  goToIndex(idx) {
    if (this._animating) return;
    this.current = ((idx % this.total) + this.total) % this.total;
    this._goTo(this.current + 1);
    this._updateDots();
  }

  next() {
    if (this._animating) return;
    this._animating = true;
    this.current = (this.current + 1) % this.total;
    this._goTo(this.current + 1);
    this._updateDots();
    this._handleLoopEnd();
  }

  prev() {
    if (this._animating) return;
    this._animating = true;
    this.current = (this.current - 1 + this.total) % this.total;
    this._goTo(this.current + 1);
    this._updateDots();
    this._handleLoopEnd();
  }

  _handleLoopEnd() {
    const onEnd = () => {
      this._animating = false;
      this.track.removeEventListener('transitionend', onEnd);
      // Reposicionar sin animación si llegamos a un clon
      const trackIdx = this.current + 1;
      if (trackIdx !== this._offset) {
        this._goTo(trackIdx, false);
      }
    };
    this.track.addEventListener('transitionend', onEnd, { once: true });
  }

  /* ── Autoplay ──────────────────────────────────────────────── */

  _startAutoplay() {
    this._autoplayTimer = setInterval(() => this.next(), this.opts.interval);
  }

  _stopAutoplay() {
    clearInterval(this._autoplayTimer);
  }

  /* ── Eventos ───────────────────────────────────────────────── */

  _bindEvents() {
    // Pausa hover
    this.el.addEventListener('mouseenter', () => this._stopAutoplay());
    this.el.addEventListener('mouseleave', () => {
      if (this.opts.autoplay) this._startAutoplay();
    });

    // Touch
    let startX = 0;
    this.el.addEventListener('touchstart', e => {
      startX = e.touches[0].clientX;
    }, { passive: true });

    this.el.addEventListener('touchend', e => {
      const diff = startX - e.changedTouches[0].clientX;
      if (Math.abs(diff) > 40) {
        diff > 0 ? this.next() : this.prev();
      }
    });
  }

  /** Destruir la instancia */
  destroy() {
    this._stopAutoplay();
  }
}

window.BookiaCarousel = BookiaCarousel;
