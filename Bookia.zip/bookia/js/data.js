/**
 * BOOKIA — data.js | Capa de Datos (con backend MySQL/XAMPP)
 * ============================================================
 * Misma interfaz pública que la versión localStorage.
 * Los Repos ahora hacen fetch a /api/*.php en lugar de
 * leer/escribir en localStorage.
 *
 * Clases Libro, Usuario, Reserva, Session → sin cambios.
 * DAO interno → reemplazado por llamadas HTTP.
 * ============================================================
 */
'use strict';

// ── BASE URL de la API ──────────────────────────────────────
// Si el proyecto está en htdocs/bookia/, esta ruta es correcta.
const API_BASE = './api';

// ── Clases de modelo ────────────────────────────────────────

class Libro {
  constructor({ id, titulo, autor, genero, anio, disponibles, descripcion, imagen, isbn, createdAt } = {}) {
    this.id          = id || '';
    this.titulo      = titulo      || '';
    this.autor       = autor       || '';
    this.genero      = genero      || 'Ficción';
    this.anio        = parseInt(anio) || new Date().getFullYear();
    this.disponibles = parseInt(disponibles) ?? 0;
    this.descripcion = descripcion || '';
    this.imagen      = imagen      || '';
    this.isbn        = isbn        || '';
    this.createdAt   = createdAt   || Date.now();
  }
}

class Usuario {
  constructor({ id, nombre, email, telefono, rol, avatar, createdAt } = {}) {
    this.id        = id || '';
    this.nombre    = nombre    || '';
    this.email     = email     || '';
    this.telefono  = telefono  || '';
    this.rol       = rol       || 'usuario';
    this.avatar    = avatar    || '';
    this.createdAt = createdAt || Date.now();
  }
}

class Reserva {
  constructor({ id, usuarioId, libroId, tituloLibro, autorLibro, fechaReserva, fechaRecogida, estado, notas, codigoRecogida, createdAt } = {}) {
    this.id             = id || '';
    this.usuarioId      = usuarioId    || '';
    this.libroId        = libroId      || '';
    this.tituloLibro    = tituloLibro  || '';
    this.autorLibro     = autorLibro   || '';
    this.fechaReserva   = fechaReserva || new Date().toISOString();
    this.fechaRecogida  = fechaRecogida|| '';
    this.estado         = estado       || 'pendiente';
    this.notas          = notas        || '';
    this.codigoRecogida = codigoRecogida || '';
    this.createdAt      = createdAt    || Date.now();
  }
  static generarCodigo() {
    const l = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    const n = '0123456789';
    const rl = () => l[Math.floor(Math.random() * l.length)];
    const rn = () => n[Math.floor(Math.random() * n.length)];
    return `BKA-${rl()}${rl()}${rn()}${rn()}-${rl()}${rn()}${rl()}`;
  }
}

// ── Helper HTTP ─────────────────────────────────────────────
async function apiCall(url, method = 'GET', body = null) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  const res  = await fetch(url, opts);
  const data = await res.json();
  if (!data.ok) throw new Error(data.msg || `Error HTTP ${res.status}`);
  return data;
}

function emitDataChange(key) {
  window.dispatchEvent(new CustomEvent('bookia:datachange', { detail: { key } }));
}

// ── LibrosRepo ──────────────────────────────────────────────
const LibrosRepo = {
  async getAll() {
    const r = await apiCall(`${API_BASE}/libros.php`);
    return r.data.map(d => new Libro(d));
  },
  async getById(id) {
    try {
      const r = await apiCall(`${API_BASE}/libros.php?id=${id}`);
      return new Libro(r.data);
    } catch { return null; }
  },
  async insert(data) {
    const r = await apiCall(`${API_BASE}/libros.php`, 'POST', data);
    emitDataChange('bookia_libros');
    return new Libro(r.data);
  },
  async update(id, changes) {
    const actual = await this.getById(id);
    if (!actual) return null;
    const merged = { ...actual, ...changes };
    const r = await apiCall(`${API_BASE}/libros.php?id=${id}`, 'PUT', merged);
    emitDataChange('bookia_libros');
    return new Libro(r.data);
  },
  async delete(id) {
    await apiCall(`${API_BASE}/libros.php?id=${id}`, 'DELETE');
    emitDataChange('bookia_libros');
    return true;
  },
  async search({ q = '', genero = '', sortBy = 'titulo', sortDir = 'asc' } = {}) {
    const params = new URLSearchParams({ q, sortBy, sortDir });
    if (genero) params.set('genero', genero);
    const r = await apiCall(`${API_BASE}/libros.php?${params}`);
    return r.data.map(d => new Libro(d));
  },
  async reservar(id) {
    const l = await this.getById(id);
    if (!l || l.disponibles <= 0) return false;
    return await this.update(id, { disponibles: l.disponibles - 1 });
  },
  async devolver(id) {
    const l = await this.getById(id);
    if (!l) return false;
    return await this.update(id, { disponibles: l.disponibles + 1 });
  },
  async getStats() {
    const libros = await this.getAll();
    return {
      total:       libros.length,
      disponibles: libros.filter(x => x.disponibles > 0).length,
      agotados:    libros.filter(x => x.disponibles === 0).length,
      generos:     [...new Set(libros.map(x => x.genero))].length,
    };
  },
};

// ── UsuariosRepo ────────────────────────────────────────────
const UsuariosRepo = {
  async getAll() {
    const r = await apiCall(`${API_BASE}/usuarios.php`);
    return r.data.map(d => new Usuario(d));
  },
  async getById(id) {
    try {
      const r = await apiCall(`${API_BASE}/usuarios.php?id=${id}`);
      return new Usuario(r.data);
    } catch { return null; }
  },
  async insert(data) {
    const r = await apiCall(`${API_BASE}/usuarios.php`, 'POST', data);
    emitDataChange('bookia_usuarios');
    return new Usuario(r.data);
  },
  async update(id, changes) {
    const r = await apiCall(`${API_BASE}/usuarios.php?id=${id}`, 'PUT', changes);
    emitDataChange('bookia_usuarios');
    return new Usuario(r.data);
  },
  async delete(id) {
    await apiCall(`${API_BASE}/usuarios.php?id=${id}`, 'DELETE');
    emitDataChange('bookia_usuarios');
    return true;
  },
  async getByEmail(email) {
    const r = await apiCall(`${API_BASE}/usuarios.php?q=${encodeURIComponent(email)}`);
    return r.data.find(u => u.email.toLowerCase() === email.toLowerCase()) || null;
  },
  async search({ q = '', rol = '' } = {}) {
    const params = new URLSearchParams({ q });
    if (rol) params.set('rol', rol);
    const r = await apiCall(`${API_BASE}/usuarios.php?${params}`);
    return r.data.map(d => new Usuario(d));
  },
  hashPassword(pass) {
    // Solo para compatibilidad. El hash real lo hace PHP (bcrypt).
    let h = 0;
    for (let i = 0; i < pass.length; i++) { h = ((h << 5) - h) + pass.charCodeAt(i); h |= 0; }
    return h.toString(36) + '_bookia';
  },
  async verificarCredenciales(email, password) {
    try {
      const r = await apiCall(`${API_BASE}/auth.php?action=login`, 'POST', { email, password });
      return r.user || null;
    } catch { return null; }
  },
  async getStats() {
    const u = await this.getAll();
    return { total: u.length, admins: u.filter(x => x.rol === 'admin').length };
  },
};

// ── ReservasRepo ────────────────────────────────────────────
const ReservasRepo = {
  async getAll() {
    const r = await apiCall(`${API_BASE}/reservas.php`);
    return r.data.map(d => new Reserva(d));
  },
  async getById(id) {
    try {
      const r = await apiCall(`${API_BASE}/reservas.php?id=${id}`);
      return new Reserva(r.data);
    } catch { return null; }
  },
  async insert(data) {
    const r = await apiCall(`${API_BASE}/reservas.php`, 'POST', data);
    emitDataChange('bookia_reservas');
    return new Reserva(r.data);
  },
  async update(id, changes) {
    const r = await apiCall(`${API_BASE}/reservas.php?id=${id}`, 'PUT', changes);
    emitDataChange('bookia_reservas');
    return new Reserva(r.data);
  },
  async delete(id) {
    await apiCall(`${API_BASE}/reservas.php?id=${id}`, 'DELETE');
    emitDataChange('bookia_reservas');
    return true;
  },
  async getByUsuario(uid) {
    const r = await apiCall(`${API_BASE}/reservas.php?usuario_id=${uid}`);
    return r.data.map(d => new Reserva(d));
  },
  async search({ q = '', estado = '', sortBy = 'fechaReserva', sortDir = 'desc' } = {}) {
    const sortMap = { fechaReserva: 'fecha_reserva', fechaRecogida: 'fecha_recogida', estado: 'estado' };
    const params = new URLSearchParams({ q, sortBy: sortMap[sortBy] || 'fecha_reserva', sortDir });
    if (estado) params.set('estado', estado);
    const r = await apiCall(`${API_BASE}/reservas.php?${params}`);
    return r.data.map(d => new Reserva(d));
  },
  async getStats() {
    const r = await this.getAll();
    return {
      total:      r.length,
      pendientes: r.filter(x => x.estado === 'pendiente').length,
      listas:     r.filter(x => x.estado === 'lista').length,
      recogidas:  r.filter(x => x.estado === 'recogida').length,
      canceladas: r.filter(x => x.estado === 'cancelada').length,
    };
  },
};

// ── Session (sessionStorage — sin cambios) ──────────────────
const KEYS = { SESSION: 'bookia_session' };

const Session = {
  get()        { try { return JSON.parse(sessionStorage.getItem(KEYS.SESSION) || 'null'); } catch { return null; } },
  set(u)       { try { sessionStorage.setItem(KEYS.SESSION, JSON.stringify(u)); window.dispatchEvent(new CustomEvent('bookia:sessionchange', { detail: u })); } catch(e) { console.error(e); } },
  clear()      { sessionStorage.removeItem(KEYS.SESSION); window.dispatchEvent(new CustomEvent('bookia:sessionchange', { detail: null })); },
  isAdmin()    { return this.get()?.rol === 'admin'; },
  isLoggedIn() { return !!this.get(); },
};

// initSeedData: en modo MySQL el seed lo maneja bookia.sql
function initSeedData() {
  console.log('[Bookia] Modo MySQL — seed gestionado por bookia.sql');
}

window.BookiaData = {
  Libro, Usuario, Reserva,
  LibrosRepo, UsuariosRepo, ReservasRepo,
  Session, KEYS, initSeedData,
};
