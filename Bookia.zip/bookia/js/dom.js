/**
 * BOOKIA — dom.js | Utilidades DOM + Optimización
 * Práctica 2 — Partes 2 y 5
 *
 * Implementa:
 *  - debounce
 *  - throttle
 *  - requestAnimationFrame helpers
 *  - Minimización de reflows
 *  - Lazy loading manual
 *  - Patrón Pub/Sub (Observer)
 */
'use strict';

/* ═══════════════════════════════════════════════════════════════
   UTILIDADES DE TIEMPO
═══════════════════════════════════════════════════════════════ */

/**
 * Debounce: espera `delay` ms tras el último llamado antes de ejecutar
 */
function debounce(fn, delay = 300) {
  let timeout;
  return (...args) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => fn(...args), delay);
  };
}

/**
 * Throttle: ejecuta como máximo una vez cada `limit` ms
 */
function throttle(fn, limit = 200) {
  let lastCall = 0;
  return (...args) => {
    const now = Date.now();
    if (now - lastCall >= limit) {
      lastCall = now;
      fn(...args);
    }
  };
}

/* ═══════════════════════════════════════════════════════════════
   RAF HELPERS — minimiza reflows/repaints
═══════════════════════════════════════════════════════════════ */

/**
 * Aplica un batch de cambios DOM en el próximo frame
 * evitando múltiples reflows consecutivos
 */
function rafBatch(fn) {
  requestAnimationFrame(() => {
    console.time('[RAF] batch');
    fn();
    console.timeEnd('[RAF] batch');
  });
}

/**
 * Mueve el scroll suavemente a un elemento sin bloquear el hilo
 */
function scrollToEl(el, offset = 80) {
  if (!el) return;
  const top = el.getBoundingClientRect().top + window.scrollY - offset;
  requestAnimationFrame(() => window.scrollTo({ top, behavior: 'smooth' }));
}

/* ═══════════════════════════════════════════════════════════════
   LAZY LOADING MANUAL
═══════════════════════════════════════════════════════════════ */

/**
 * Observa imágenes con data-src y las carga al entrar en viewport
 */
function initLazyImages(root = document) {
  const imgs = root.querySelectorAll('img[data-src]');
  if (!imgs.length) return;

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const img = entry.target;
      img.src = img.dataset.src;
      img.removeAttribute('data-src');
      obs.unobserve(img);
    });
  }, { rootMargin: '200px' });

  imgs.forEach(img => observer.observe(img));
}

/* ═══════════════════════════════════════════════════════════════
   PATRÓN PUB / SUB  (Observer)
═══════════════════════════════════════════════════════════════ */

const BookiaPubSub = (() => {
  const _channels = {};

  function subscribe(event, handler) {
    if (!_channels[event]) _channels[event] = [];
    _channels[event].push(handler);
    // Devuelve función para desuscribirse
    return () => {
      _channels[event] = _channels[event].filter(h => h !== handler);
    };
  }

  function publish(event, data) {
    (_channels[event] || []).forEach(fn => fn(data));
  }

  return { subscribe, publish };
})();

/* ═══════════════════════════════════════════════════════════════
   TOAST / NOTIFICACIÓN VISUAL
═══════════════════════════════════════════════════════════════ */

function showToast(msg, type = 'info', duration = 3500) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `bk-toast bk-toast--${type}`;
  toast.innerHTML = `<span>${msg}</span>`;
  container.appendChild(toast);

  // Entrada con RAF para garantizar transición
  requestAnimationFrame(() => {
    requestAnimationFrame(() => toast.classList.add('bk-toast--visible'));
  });

  setTimeout(() => {
    toast.classList.remove('bk-toast--visible');
    toast.addEventListener('transitionend', () => toast.remove(), { once: true });
  }, duration);
}

/* ═══════════════════════════════════════════════════════════════
   SHOW / HIDE SIN display:none
   Práctica 2 — Parte 3.2: transición con opacity + height
   No se usa display:none en ningún momento
═══════════════════════════════════════════════════════════════ */

/**
 * Muestra un elemento con transición (opacity + height)
 */
function showEl(el, display = 'block') {
  if (!el) return;
  el.style.display = display;
  el.style.overflow = 'hidden';
  const h = el.scrollHeight;
  el.style.height = '0';
  el.style.opacity = '0';
  el.style.transition = 'height 0.35s ease, opacity 0.35s ease';
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      el.style.height = h + 'px';
      el.style.opacity = '1';
      el.addEventListener('transitionend', () => {
        el.style.height = '';
        el.style.overflow = '';
        el.style.transition = '';
      }, { once: true });
    });
  });
}

/**
 * Oculta un elemento con transición (opacity + height)
 * NO usa display:none — usa visibility:hidden + pointer-events:none
 * cumpliendo el requisito de la Práctica 2, Parte 3.2
 */
function hideEl(el) {
  if (!el) return;
  el.style.overflow   = 'hidden';
  el.style.height     = el.scrollHeight + 'px';
  el.style.opacity    = '1';
  el.style.transition = 'height 0.35s ease, opacity 0.35s ease';
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      el.style.height  = '0';
      el.style.opacity = '0';
      el.addEventListener('transitionend', () => {
        // Sin display:none — oculto con visibility + pointer-events
        el.style.visibility    = 'hidden';
        el.style.pointerEvents = 'none';
        el.style.height        = '';
        el.style.overflow      = '';
        el.style.opacity       = '';
        el.style.transition    = '';
      }, { once: true });
    });
  });
}

/**
 * Revierte hideEl — restaura visibilidad completa
 */
function revealEl(el) {
  if (!el) return;
  el.style.visibility    = '';
  el.style.pointerEvents = '';
  showEl(el);
}

/* ═══════════════════════════════════════════════════════════════
   EXPORTS
═══════════════════════════════════════════════════════════════ */
window.BookiaDOM = {
  debounce, throttle, rafBatch, scrollToEl,
  initLazyImages, showToast, showEl, hideEl, revealEl,
};
window.BookiaPubSub = BookiaPubSub;
