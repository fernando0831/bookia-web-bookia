/**
 * =====================================================
 * BOOKIA - Módulo de Interfaz (Capa de Presentación)
 * ui.js — Arquitectura de 3 capas: PRESENTACIÓN
 * =====================================================
 * Responsabilidad:
 *   - Manipulación del DOM (querySelector, createElement, etc.)
 *   - Renderizado dinámico de componentes
 *   - Toasts y notificaciones
 *   - Modales de confirmación
 *   - Mensajes de formulario
 *   - Actualización reactiva de la UI
 * =====================================================
 */

'use strict';

const UI = {

  /* TOAST NOTIFICATIONS*/

  /**
   * Muestra una notificación toast
   * @param {string} message
   * @param {'success'|'error'|'warning'|'info'} type
   * @param {number} duration ms
   */
  toast(message, type = 'success', duration = 3500) {
    let container = document.querySelector('.toast-container');
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }

    const icons = { success: '✓', error: '✕', warning: '⚠', info: 'ℹ' };
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
      <span class="toast-icon">${icons[type] || '✓'}</span>
      <span>${message}</span>
    `;

    container.prepend(toast); // prepend: nuevos toasts arriba

    setTimeout(() => {
      toast.style.animation = 'toastOut 0.3s ease forwards';
      setTimeout(() => toast.remove(), 300);
    }, duration);
  },


  /* ============================
     MODAL DE CONFIRMACIÓN
     ============================ */

  /**
   * Muestra un modal de confirmación
   * @returns {Promise<boolean>}
   */
  confirm({ title = '¿Estás seguro?', message = '', confirmText = 'Confirmar', cancelText = 'Cancelar', danger = false } = {}) {
    return new Promise(resolve => {
      const overlay = document.createElement('div');
      overlay.className = 'modal-overlay';
      overlay.innerHTML = `
        <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
          <div class="modal-header">
            <span class="modal-icon">${danger ? '⚠️' : '❓'}</span>
            <h3 id="modal-title">${title}</h3>
          </div>
          ${message ? `<div class="modal-body">${message}</div>` : ''}
          <div class="modal-footer">
            <button class="btn btn-ghost" id="modal-cancel">${cancelText}</button>
            <button class="btn ${danger ? 'btn-danger' : ''}" id="modal-confirm">${confirmText}</button>
          </div>
        </div>
      `;

      document.body.appendChild(overlay);

      const close = (result) => {
        overlay.style.animation = 'none';
        overlay.style.opacity = '0';
        setTimeout(() => overlay.remove(), 150);
        resolve(result);
      };

      overlay.querySelector('#modal-confirm').addEventListener('click', () => close(true));
      overlay.querySelector('#modal-cancel').addEventListener('click',  () => close(false));
      overlay.addEventListener('click', e => { if (e.target === overlay) close(false); });

      // Foco en botón de confirmación
      setTimeout(() => overlay.querySelector('#modal-confirm').focus(), 50);
    });
  },


  /* ============================
     MENSAJES EN FORMULARIOS
     ============================ */

  /**
   * Muestra un mensaje dentro de un contenedor
   */
  showMessage(containerId, message, type = 'success') {
    const container = document.getElementById(containerId);
    if (!container) return;

    const icons = { success: '✓', error: '✕', warning: '⚠', info: 'ℹ' };
    container.innerHTML = `
      <div class="msg msg-${type}">
        <span class="msg-icon">${icons[type]}</span>
        <div>${message}</div>
      </div>
    `;
    container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  },

  clearMessage(containerId) {
    const container = document.getElementById(containerId);
    if (container) container.innerHTML = '';
  },

  /**
   * Muestra error en un campo específico
   */
  showFieldError(fieldId, message) {
    const field = document.getElementById(fieldId);
    const errEl = document.getElementById(`${fieldId}-error`);
    if (field) field.classList.add('error-field');
    if (errEl) { errEl.textContent = message; errEl.classList.add('visible'); }
  },

  clearFieldError(fieldId) {
    const field = document.getElementById(fieldId);
    const errEl = document.getElementById(`${fieldId}-error`);
    if (field) field.classList.remove('error-field');
    if (errEl) errEl.classList.remove('visible');
  },

  clearAllFieldErrors(formEl) {
    if (!formEl) return;
    formEl.querySelectorAll('.error-field').forEach(el => el.classList.remove('error-field'));
    formEl.querySelectorAll('.field-error').forEach(el => el.classList.remove('visible'));
  },


  /* ============================
     CATÁLOGO — RENDERIZADO
     ============================ */

  /**
   * Renderiza la tarjeta de un libro
   */
  renderLibroCard(libro, options = {}) {
    const { isAdmin = false } = options;
    const dispClass  = libro.disponibles === 0 ? 'agotado' : libro.disponibles <= 2 ? 'poco' : '';
    const dispLabel  = libro.disponibles === 0 ? 'Agotado' : `${libro.disponibles} disponibles`;
    const dispStrong = libro.disponibles === 0 ? 'agotado' : '';
    const badgeText  = libro.disponibles === 0 ? 'Agotado' : libro.disponibles <= 2 ? 'Últimas copias' : '';

    const card = document.createElement('div');
    card.className = 'libro';
    card.dataset.id = libro.id;

    // Solo mostrar botón Reservar a usuarios logueados; sin sesión no se muestra nada
    const isLoggedIn = window.BookiaData?.Session?.isLoggedIn();
    let actionBtn = '';
    if (isAdmin) {
      actionBtn = `<div class="table-actions" style="margin-top:auto;">
               <button class="btn btn-sm btn-ghost btn-edit-libro" data-id="${libro.id}">✏️ Editar</button>
               <button class="btn btn-sm btn-danger btn-del-libro" data-id="${libro.id}">🗑</button>
             </div>`;
    } else if (libro.disponibles === 0) {
      actionBtn = `<button class="btn btn-ghost" disabled style="width:100%;justify-content:center;cursor:not-allowed;opacity:.6">🚫 No disponible</button>`;
    } else if (isLoggedIn) {
      actionBtn = `<button class="btn btn-reservar" data-id="${libro.id}" style="width:100%;justify-content:center">📌 Reservar</button>`;
    }
    // Sin sesión: no se muestra botón de acción en la tarjeta

    const COVER_FALLBACK = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1' height='1'%3E%3C/svg%3E";
    card.innerHTML = `
      <div class="libro-cover libro-cover-clickable" data-detail="${libro.id}" title="Ver descripción">
        <img src="${libro.imagen || COVER_FALLBACK}"
             alt="Portada de ${libro.titulo}"
             loading="lazy"
             onerror="BookiaUI.imgFallback(this)"
             style="width:100%;height:100%;object-fit:cover;">
        ${badgeText ? `<span class="libro-badge ${dispClass}">${badgeText}</span>` : ''}
        <div class="libro-cover-hover">🔍 Ver detalle</div>
      </div>
      <div class="libro-body">
        <h3 class="libro-cover-clickable" data-detail="${libro.id}" style="cursor:pointer">${libro.titulo}</h3>
        <p class="libro-autor">✍️ ${libro.autor}</p>
        <div class="libro-meta">
          <span class="libro-tag">${libro.genero}</span>
          ${libro.anio ? `<span class="libro-tag">${libro.anio}</span>` : ''}
        </div>
        <p class="libro-disponibles" style="margin-bottom:${actionBtn ? '12px' : '4px'}">
          📚 <strong class="${dispStrong}">${dispLabel}</strong>
        </p>
        ${actionBtn}
      </div>
    `;
    return card;
  },

  /** Fallback limpio para portadas que no cargan */
  imgFallback(img) {
    img.style.display = 'none';
    const cover = img.parentElement;
    if (!cover || cover.querySelector('.img-fb')) return;
    cover.style.background = 'linear-gradient(135deg,#6B0F2A,#8B1A3A)';
    const fb = document.createElement('div');
    fb.className = 'img-fb';
    fb.style.cssText = 'position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,0.55);font-size:40px;pointer-events:none';
    fb.textContent = '📚';
    cover.appendChild(fb);
  },

  openLibroDetail(libro) {
    document.querySelectorAll('.libro-detail-overlay').forEach(el => el.remove());
    const isLoggedIn = window.BookiaData?.Session?.isLoggedIn();
    const dispColor  = libro.disponibles === 0 ? '#dc2626' : '#16a34a';
    const dispLabel  = libro.disponibles === 0 ? 'Agotado' : `${libro.disponibles} disponibles`;
    const pricePool  = [149,179,199,219,239,259,279,299,319,349];
    const priceIdx   = (libro.isbn || libro.titulo).split('').reduce((a,c) => a + c.charCodeAt(0), 0) % pricePool.length;
    const precio     = pricePool[priceIdx];

    // Modal solo muestra info — sin botón de acción

    const overlay = document.createElement('div');
    overlay.className = 'libro-detail-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.55);z-index:9000;display:flex;align-items:center;justify-content:center;padding:20px;backdrop-filter:blur(3px);animation:fadeIn .18s ease';

    // Build modal DOM (no innerHTML with complex escaping — use createElement for the image)
    const modal = document.createElement('div');
    modal.style.cssText = 'background:#fff;border-radius:20px;box-shadow:0 24px 64px rgba(107,15,42,0.3);max-width:660px;width:100%;max-height:92vh;overflow-y:auto;position:relative;animation:slideUp .22s ease';

    // Header
    const header = document.createElement('div');
    header.style.cssText = 'background:linear-gradient(135deg,#6B0F2A 0%,#8B1A3A 100%);border-radius:20px 20px 0 0;padding:28px 24px 0;display:flex;gap:22px;align-items:flex-end;position:relative';

    // Close button
    const closeBtn = document.createElement('button');
    closeBtn.id = 'close-libro-detail';
    closeBtn.textContent = '×';
    closeBtn.style.cssText = 'position:absolute;top:14px;right:14px;background:rgba(255,255,255,0.15);border:none;color:#fff;width:32px;height:32px;border-radius:50%;font-size:22px;line-height:1;cursor:pointer;display:flex;align-items:center;justify-content:center';
    header.appendChild(closeBtn);

    // Cover image
    const img = document.createElement('img');
    img.alt = 'Portada';
    img.style.cssText = 'width:96px;height:136px;object-fit:cover;border-radius:10px 10px 0 0;box-shadow:0 -4px 20px rgba(0,0,0,0.3);flex-shrink:0';
    img.src = libro.imagen || "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1' height='1'%3E%3C/svg%3E";
    img.onerror = function() { window.BookiaUI.imgFallback(this); };
    header.appendChild(img);

    // Title block
    const titleBlock = document.createElement('div');
    titleBlock.style.cssText = 'padding-bottom:22px;flex:1;min-width:0';
    titleBlock.innerHTML = `
      <span style="display:inline-block;padding:3px 12px;background:rgba(193,154,107,0.25);color:#C19A6B;border:1px solid rgba(193,154,107,0.4);border-radius:20px;font-size:11px;font-weight:700;margin-bottom:10px;letter-spacing:.3px">${libro.genero} · ${libro.anio}</span>
      <h2 style="font-size:21px;font-weight:900;color:#fff;margin-bottom:6px;line-height:1.25">${libro.titulo}</h2>
      <p style="color:rgba(193,154,107,.85);font-size:14px">por <strong>${libro.autor}</strong></p>`;
    header.appendChild(titleBlock);
    modal.appendChild(header);

    // Body
    const body = document.createElement('div');
    body.style.cssText = 'padding:26px 28px';
    body.innerHTML = `
      <p style="font-size:15px;color:#374151;line-height:1.8;margin-bottom:24px">${libro.descripcion || 'Sin descripción disponible.'}</p>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:8px">
        <div style="background:#fdf9f5;border:1px solid rgba(193,154,107,0.2);border-radius:10px;padding:14px;text-align:center">
          <div style="font-size:11px;font-weight:700;color:#9CA3AF;text-transform:uppercase;letter-spacing:.4px;margin-bottom:4px">Disponibles</div>
          <div style="font-size:18px;font-weight:900;color:${dispColor}">${dispLabel}</div>
        </div>
        <div style="background:#fdf9f5;border:1px solid rgba(193,154,107,0.2);border-radius:10px;padding:14px;text-align:center">
          <div style="font-size:11px;font-weight:700;color:#9CA3AF;text-transform:uppercase;letter-spacing:.4px;margin-bottom:4px">Precio ref.</div>
          <div style="font-size:18px;font-weight:900;color:#1F3A4D">$${precio} MXN</div>
        </div>
      </div>`;
    modal.appendChild(body);
    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    // Events
    closeBtn.addEventListener('click', () => overlay.remove());
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
    document.addEventListener('keydown', function escHandler(e) {
      if (e.key === 'Escape') { overlay.remove(); document.removeEventListener('keydown', escHandler); }
    });

    // (sin botón de reserva en modal — solo info)
  },

  /**
   * Renderiza libros en grid plano (sin agrupar por género) — usado en home
   */
  renderCatalogoPlano(container, libros, options = {}) {
    if (!container) return;
    container.innerHTML = '';
    if (!libros.length) {
      container.innerHTML = '<p style="text-align:center;color:#9CA3AF;padding:40px">No hay libros disponibles.</p>';
      return;
    }
    const grid = document.createElement('div');
    grid.className = 'grid';
    libros.forEach(libro => grid.appendChild(this.renderLibroCard(libro, options)));
    container.appendChild(grid);
  },

  /**
   * Renderiza el catálogo completo agrupado por género
   * @param {HTMLElement} container
   * @param {Array} libros
   * @param {object} options
   */
  renderCatalogo(container, libros, options = {}) {
    if (!container) return;

    if (!libros.length) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">📚</div>
          <h4>No se encontraron libros</h4>
          <p>Intenta con otros filtros de búsqueda.</p>
        </div>`;
      return;
    }

    const generoIconos = {
      'Ficción':         '📖',
      'No Ficción':      '🧪',
      'Infantil':        '🌟',
      'Misterio':        '🔍',
      'Ciencia Ficción': '🚀',
      'Romance':         '💕',
      'Historia':        '🏛️',
      'Autoayuda':       '✨',
    };

    const byGenero = libros.reduce((acc, l) => {
      (acc[l.genero] = acc[l.genero] || []).push(l);
      return acc;
    }, {});

    container.innerHTML = '';

    for (const [genero, librosGenero] of Object.entries(byGenero)) {
      const section = document.createElement('section');
      section.className = 'categoria-section';
      section.id = `cat-${genero.toLowerCase().replace(/\s/g, '-')}`;

      const header = document.createElement('div');
      header.className = 'categoria-header';
      header.innerHTML = `
        <div class="categoria-icon">${generoIconos[genero] || '📚'}</div>
        <h3>${genero}</h3>
        <span class="cat-badge">${librosGenero.length} libros</span>
      `;

      const grid = document.createElement('div');
      grid.className = 'grid';

      librosGenero.forEach(libro => {
        grid.appendChild(this.renderLibroCard(libro, options));
      });

      section.appendChild(header);
      section.appendChild(grid);
      container.appendChild(section);
    }
  },

  /**
   * Actualiza el contador de resultados
   */
  updateResultCount(el, count) {
    if (el) el.textContent = `${count} libro${count !== 1 ? 's' : ''} encontrado${count !== 1 ? 's' : ''}`;
  },


  /* ============================
     TABLA DE ADMINISTRACIÓN
     ============================ */

  /**
   * Renderiza una tabla dinámica de libros para el panel admin
   */
  renderTablaLibros(tbody, libros) {
    if (!tbody) return;
    if (!libros.length) {
      tbody.innerHTML = `<tr><td colspan="6"><div class="empty-state" style="padding:28px"><div class="empty-icon">📚</div><p>No hay libros registrados</p></div></td></tr>`;
      return;
    }
    tbody.innerHTML = '';
    libros.forEach(libro => {
      const tr = document.createElement('tr');
      const dispClass = libro.disponibles === 0 ? 'pill-red' : libro.disponibles <= 2 ? 'pill-yellow' : 'pill-green';
      tr.innerHTML = `
        <td><strong>${libro.titulo}</strong></td>
        <td>${libro.autor}</td>
        <td><span class="pill pill-blue">${libro.genero}</span></td>
        <td>${libro.anio}</td>
        <td><span class="pill ${dispClass}">${libro.disponibles}</span></td>
        <td>
          <div class="table-actions">
            <button class="btn btn-sm btn-ghost btn-edit-libro" data-id="${libro.id}" title="Editar">✏️</button>
            <button class="btn btn-sm btn-danger btn-del-libro"  data-id="${libro.id}" title="Eliminar">🗑</button>
          </div>
        </td>`;
      tbody.appendChild(tr);
    });
  },

  /**
   * Renderiza tabla de usuarios para admin
   */
  renderTablaUsuarios(tbody, usuarios) {
    if (!tbody) return;
    if (!usuarios.length) {
      tbody.innerHTML = `<tr><td colspan="5"><div class="empty-state" style="padding:28px"><div class="empty-icon">👤</div><p>No hay usuarios registrados</p></div></td></tr>`;
      return;
    }
    tbody.innerHTML = '';
    usuarios.forEach(u => {
      const tr = document.createElement('tr');
      const rolClass = u.rol === 'admin' ? 'pill-purple' : 'pill-blue';
      tr.innerHTML = `
        <td><strong>${u.nombre}</strong></td>
        <td>${u.email}</td>
        <td>${u.telefono || '—'}</td>
        <td><span class="pill ${rolClass}">${u.rol}</span></td>
        <td>
          <div class="table-actions">
            <button class="btn btn-sm btn-ghost btn-edit-user"  data-id="${u.id}" title="Editar">✏️</button>
            <button class="btn btn-sm btn-danger btn-del-user"  data-id="${u.id}" title="Eliminar">🗑</button>
          </div>
        </td>`;
      tbody.appendChild(tr);
    });
  },

  /**
   * Renderiza tabla de reservas para admin
   */
  renderTablaReservas(tbody, reservas, usuarios) {
    if (!tbody) return;
    if (!reservas.length) {
      tbody.innerHTML = `<tr><td colspan="6"><div class="empty-state" style="padding:28px"><div class="empty-icon">🔖</div><p>No hay reservas</p></div></td></tr>`;
      return;
    }
    const usMap = {};
    (usuarios || []).forEach(u => usMap[u.id] = u.nombre);

    tbody.innerHTML = '';
    reservas.forEach(r => {
      const tr = document.createElement('tr');
      const estadoClasses = { pendiente:'pill-yellow', lista:'pill-green', recogida:'pill-blue', cancelada:'pill-red' };
      const fecha = r.fechaReserva ? new Date(r.fechaReserva).toLocaleDateString('es-MX') : '—';
      tr.innerHTML = `
        <td><strong>${r.tituloLibro}</strong><br><small style="color:#6B7280">${r.autorLibro}</small></td>
        <td>${usMap[r.usuarioId] || r.usuarioId}</td>
        <td>${fecha}</td>
        <td>${r.fechaRecogida || '—'}</td>
        <td><code style="font-size:11px;background:#f3f4f6;padding:3px 7px;border-radius:5px;font-weight:700;color:#6B0F2A">${r.codigoRecogida || '—'}</code></td>
        <td><span class="pill ${estadoClasses[r.estado] || 'pill-gray'}">${r.estado}</span></td>
        <td>
          <div class="table-actions">
            <button class="btn btn-sm btn-ghost btn-comprobante-admin" data-id="${r.id}" title="Descargar comprobante" style="font-size:11px">📄</button>
            <button class="btn btn-sm btn-ghost btn-edit-reserva"  data-id="${r.id}" title="Cambiar estado">✏️</button>
            <button class="btn btn-sm btn-danger btn-del-reserva"  data-id="${r.id}" title="Eliminar">🗑</button>
          </div>
        </td>`;
      tbody.appendChild(tr);
    });
  },


  /* ============================
     PERFIL — RESERVAS USUARIO
     ============================ */

  renderReservasUsuario(container, reservas, librosMap) {
    if (!container) return;
    if (!reservas.length) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">📋</div>
          <h4>Sin reservas activas</h4>
          <p>Explora el catálogo y reserva tu próxima lectura.</p>
          <a href="catalogo.html" class="btn" style="margin-top:16px">Ver catálogo</a>
        </div>`;
      return;
    }
    container.innerHTML = '';
    const estadoClasses  = { pendiente:'pill-yellow', lista:'pill-green', recogida:'pill-blue', cancelada:'pill-red' };
    const estadoLabels   = { pendiente:'Pendiente', lista:'Lista para recoger', recogida:'Recogida', cancelada:'Cancelada' };
    reservas.forEach(r => {
      const libro = librosMap ? librosMap[r.libroId] : null;
      const card  = document.createElement('div');
      card.className = 'reserva-card';
      const imgSrc = libro?.imagen || '';

      // Código de recogida visible si pendiente o lista
      const mostrarCodigo = r.estado === 'pendiente' || r.estado === 'lista';
      const codigoHtml = mostrarCodigo && r.codigoRecogida ? `
        <div style="margin-top:10px;background:linear-gradient(135deg,rgba(107,15,42,0.06),rgba(193,154,107,0.08));border:1px dashed rgba(107,15,42,0.25);border-radius:10px;padding:10px 14px;display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap">
          <div>
            <div style="font-size:10px;font-weight:700;color:#9CA3AF;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">Código de recogida</div>
            <code style="font-size:17px;font-weight:900;color:#6B0F2A;letter-spacing:2px">${r.codigoRecogida}</code>
          </div>
          <button class="btn-comprobante" data-id="${r.id}" style="padding:7px 14px;background:linear-gradient(135deg,#6B0F2A,#8B1A3A);color:#fff;border:none;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;white-space:nowrap;font-family:inherit">
            📄 Descargar comprobante
          </button>
        </div>` : '';

      card.innerHTML = `
        <img class="reserva-cover"
             src="${imgSrc}"
             alt="${r.tituloLibro}"
             onerror="BookiaUI.imgFallback(this)">
        <div class="reserva-info" style="flex:1">
          <h4 style="font-size:15px;font-weight:700;color:#1F3A4D;margin-bottom:2px">${r.tituloLibro}</h4>
          <p style="font-size:13px;color:#9CA3AF;margin-bottom:8px">${r.autorLibro}</p>
          <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:${mostrarCodigo?'0':'4px'}">
            <span class="pill ${estadoClasses[r.estado] || 'pill-gray'}">${estadoLabels[r.estado] || r.estado}</span>
            ${r.fechaRecogida ? `<span style="font-size:12px;color:#6B7280">📅 ${r.fechaRecogida}</span>` : ''}
          </div>
          ${codigoHtml}
        </div>
        ${r.estado === 'pendiente' ? `<button class="btn btn-sm btn-danger btn-cancelar-reserva" data-id="${r.id}" style="align-self:flex-start;flex-shrink:0">Cancelar</button>` : ''}
      `;
      container.appendChild(card);
    });
  },

  /** Genera y descarga un comprobante en PDF de la reserva usando jsPDF */
  descargarComprobante(reserva, nombreUsuario) {
    // Cargar jsPDF dinámicamente si no está disponible
    const generarPDF = () => {
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF({ unit: 'mm', format: 'a4' });

      const W = 210;
      const primaryColor  = [107, 15, 42];    // #6B0F2A
      const accentColor   = [193, 154, 107];  // #C19A6B
      const darkColor     = [31, 58, 77];     // #1F3A4D
      const mutedColor    = [107, 114, 128];  // #6B7280
      const bgColor       = [253, 249, 245];  // #FDF9F5

      // ── Encabezado (fondo vino) ────────────────────────────────────
      doc.setFillColor(...primaryColor);
      doc.rect(0, 0, W, 52, 'F');

      // Logo / Título
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(26);
      doc.setFont('helvetica', 'bold');
      doc.text('BOOKIA', W / 2, 20, { align: 'center' });

      doc.setFontSize(11);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(...accentColor);
      doc.text('Comprobante de Reserva', W / 2, 30, { align: 'center' });

      // Línea decorativa dorada
      doc.setDrawColor(...accentColor);
      doc.setLineWidth(0.6);
      doc.line(20, 36, W - 20, 36);

      // Fecha de emisión
      doc.setFontSize(9);
      doc.setTextColor(220, 200, 170);
      const fechaEmision = new Date().toLocaleDateString('es-MX', { year:'numeric', month:'long', day:'numeric' });
      doc.text('Emitido el ' + fechaEmision, W / 2, 44, { align: 'center' });

      // ── Caja de código de recogida ─────────────────────────────────
      doc.setFillColor(...bgColor);
      doc.roundedRect(20, 58, W - 40, 34, 4, 4, 'F');
      doc.setDrawColor(...accentColor);
      doc.setLineWidth(0.5);
      doc.setLineDashPattern([3, 2], 0);
      doc.roundedRect(20, 58, W - 40, 34, 4, 4, 'S');
      doc.setLineDashPattern([], 0);

      doc.setFontSize(8);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(...mutedColor);
      doc.text('CÓDIGO DE RECOGIDA', W / 2, 68, { align: 'center' });

      doc.setFontSize(22);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(...primaryColor);
      doc.text(reserva.codigoRecogida || '———', W / 2, 82, { align: 'center' });

      // ── Datos de la reserva ────────────────────────────────────────
      let y = 104;
      const drawRow = (label, value) => {
        doc.setFillColor(255, 255, 255);
        doc.rect(20, y - 5, W - 40, 12, 'F');
        doc.setDrawColor(240, 236, 230);
        doc.setLineWidth(0.3);
        doc.line(20, y + 7, W - 20, y + 7);

        doc.setFontSize(9);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(...mutedColor);
        doc.text(label.toUpperCase(), 26, y + 3);

        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(...darkColor);
        const maxW = 90;
        const lines = doc.splitTextToSize(String(value), maxW);
        doc.text(lines, W - 26, y + 3, { align: 'right' });

        y += 14;
      };

      const estadoLabels = { pendiente:'Pendiente', lista:'Lista para recoger', recogida:'Recogida', cancelada:'Cancelada' };
      const fechaReserva = reserva.fechaReserva
        ? new Date(reserva.fechaReserva).toLocaleDateString('es-MX', { year:'numeric', month:'long', day:'numeric' })
        : '—';

      drawRow('Libro',              reserva.tituloLibro);
      drawRow('Autor',              reserva.autorLibro);
      drawRow('Reservado por',      nombreUsuario);
      drawRow('Fecha de reserva',   fechaReserva);
      drawRow('Fecha de recogida',  reserva.fechaRecogida || '—');
      drawRow('Estado',             estadoLabels[reserva.estado] || reserva.estado);

      // ── Instrucciones ──────────────────────────────────────────────
      y += 6;
      doc.setFillColor(...bgColor);
      doc.roundedRect(20, y, W - 40, 24, 3, 3, 'F');
      doc.setFontSize(8.5);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(...darkColor);
      doc.text('¿Cómo recoger tu libro?', 26, y + 8);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(...mutedColor);
      doc.text('Presenta este comprobante con tu código en la librería Bookia.', 26, y + 15);
      doc.text('Horario de atención: Lunes a Sábado de 9:00 a 20:00 h.', 26, y + 21);

      // ── Pie de página ──────────────────────────────────────────────
      doc.setFillColor(...primaryColor);
      doc.rect(0, 280, W, 17, 'F');
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(200, 180, 160);
      doc.text('bookia.mx  ·  Tu librería pick-up de confianza  ·  © Bookia 2026', W / 2, 290, { align: 'center' });

      doc.save('Comprobante-Bookia-' + (reserva.codigoRecogida || 'reserva') + '.pdf');
    };

    // Cargar jsPDF desde CDN si no está disponible aún
    if (window.jspdf) {
      generarPDF();
    } else {
      const script = document.createElement('script');
      script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
      script.onload = () => generarPDF();
      script.onerror = () => {
        this.toast('No se pudo generar el PDF. Verifica tu conexión.', 'error');
      };
      document.head.appendChild(script);
    }
  },


  /* ============================
     BARRA DE NAVEGACIÓN
     ============================ */

  /**
   * Actualiza la navbar según la sesión del usuario
   * Los IDs nav-* están directamente en los <li>
   */
  updateNavbarSession(session) {
    // Helper: oculta/muestra un elemento por su ID (el ID está en el <li>)
    const hide = (id) => { const el = document.getElementById(id); if (el) el.style.display = 'none'; };
    const show = (id) => { const el = document.getElementById(id); if (el) el.style.display = ''; };

    const userLabel = document.getElementById('nav-user-label');

    if (session) {
      hide('nav-login');
      hide('nav-register');
      show('nav-logout');
      if (userLabel) userLabel.textContent = session.nombre.split(' ')[0];
      if (session.rol === 'admin') {
        hide('nav-profile');   // admin goes directly to admin panel, not perfil
        show('nav-admin');
      } else {
        show('nav-profile');
        hide('nav-admin');
      }
    } else {
      show('nav-login');
      show('nav-register');
      hide('nav-profile');
      hide('nav-logout');
      hide('nav-admin');
    }
  },


  /* ============================
     VALIDACIÓN DE FORMULARIOS
     ============================ */

  /**
   * Valida un formulario y retorna { valid, errors }
   */
  validateForm(rules) {
    const errors = {};
    for (const [fieldId, checks] of Object.entries(rules)) {
      const el    = document.getElementById(fieldId);
      const value = el ? el.value.trim() : '';
      for (const check of checks) {
        const errMsg = check(value, el);
        if (errMsg) { errors[fieldId] = errMsg; break; }
      }
    }
    return { valid: Object.keys(errors).length === 0, errors };
  },

  // Reglas de validación reutilizables
  validators: {
    required: msg => v => !v ? (msg || 'Este campo es obligatorio') : null,
    minLen:   (n, msg) => v => v.length < n ? (msg || `Mínimo ${n} caracteres`) : null,
    email:    msg => v => !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? (msg || 'Correo inválido') : null,
    numeric:  msg => v => isNaN(v) || v === '' ? (msg || 'Debe ser un número') : null,
    min:      (n, msg) => v => Number(v) < n ? (msg || `Mínimo ${n}`) : null,
    max:      (n, msg) => v => Number(v) > n ? (msg || `Máximo ${n}`) : null,
    phone:    msg => v => !/^\d{10}$/.test(v.replace(/[\s\-\(\)]/g,'')) ? (msg || 'Teléfono inválido (10 dígitos)') : null,
    match:    (otherId, msg) => (v) => {
      const other = document.getElementById(otherId);
      return (other && v !== other.value) ? (msg || 'No coincide') : null;
    },
  },


  /* ============================
     PASSWORD STRENGTH METER
     ============================ */

  /**
   * Actualiza el indicador de fortaleza de contraseña
   */
  updatePasswordStrength(password, barId, textId) {
    const bar  = document.getElementById(barId);
    const text = document.getElementById(textId);
    if (!bar || !text) return;

    let score = 0;
    if (password.length >= 8)                score++;
    if (/[a-z]/.test(password))              score++;
    if (/[A-Z]/.test(password))              score++;
    if (/\d/.test(password))                 score++;
    if (/[^a-zA-Z0-9]/.test(password))      score++;

    const levels = [
      { color: '#dc2626', label: 'Muy débil',   pct: '20%' },
      { color: '#f59e0b', label: 'Débil',       pct: '40%' },
      { color: '#f59e0b', label: 'Regular',     pct: '60%' },
      { color: '#16a34a', label: 'Fuerte',      pct: '80%' },
      { color: '#15803d', label: 'Muy fuerte',  pct: '100%' },
    ];

    const level = levels[Math.max(0, score - 1)] || levels[0];
    bar.style.width           = password ? level.pct : '0%';
    bar.style.backgroundColor = level.color;
    text.textContent          = password ? level.label : '';
    text.style.color          = level.color;
  },


  /* ============================
     PAGINACIÓN
     ============================ */

  /**
   * Genera controles de paginación
   */
  renderPagination(container, { current, total, onChange }) {
    if (!container || total <= 1) {
      if (container) container.innerHTML = '';
      return;
    }
    const controls = document.createElement('div');
    controls.className = 'pagination-controls';

    const addBtn = (label, page, disabled = false, active = false) => {
      const btn = document.createElement('button');
      btn.className = `page-btn${active ? ' active' : ''}`;
      btn.textContent = label;
      btn.disabled = disabled;
      if (!disabled && !active) btn.addEventListener('click', () => onChange(page));
      controls.appendChild(btn);
    };

    addBtn('‹', current - 1, current === 1);
    for (let i = 1; i <= total; i++) {
      if (total > 7 && (i > 2 && i < total - 1) && Math.abs(i - current) > 1) {
        if (i === 3 || i === total - 2) { const d = document.createElement('span'); d.textContent = '…'; d.style.padding='0 6px'; controls.appendChild(d); }
        continue;
      }
      addBtn(i, i, false, i === current);
    }
    addBtn('›', current + 1, current === total);

    container.innerHTML = '';
    container.appendChild(controls);
  },


  /* ============================
     MENÚ HAMBURGUESA
     ============================ */

  initMenu() {
    const toggle = document.querySelector('.menu-toggle');
    const nav    = document.querySelector('.navbar > ul');
    if (!toggle || !nav) return;

    toggle.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open);
    });

    // Submenús en móvil
    document.querySelectorAll('.has-submenu > a').forEach(link => {
      link.addEventListener('click', e => {
        if (window.innerWidth <= 768) {
          e.preventDefault();
          link.parentElement.classList.toggle('open');
        }
      });
    });

    // Cerrar al hacer click fuera
    document.addEventListener('click', e => {
      if (!e.target.closest('.navbar')) {
        nav.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  },


  /* ============================
     LOADING STATE
     ============================ */

  setLoading(el, loading, text = 'Cargando...') {
    if (!el) return;
    if (loading) {
      el.dataset.originalText = el.innerHTML;
      el.disabled  = true;
      el.innerHTML = `<div class="spinner" style="width:16px;height:16px;border-width:2px;display:inline-block;vertical-align:middle;margin-right:6px"></div>${text}`;
    } else {
      el.disabled  = false;
      el.innerHTML = el.dataset.originalText || el.innerHTML;
    }
  },
};

// Exportar al ámbito global
window.BookiaUI = UI;
