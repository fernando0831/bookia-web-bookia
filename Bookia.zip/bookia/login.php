<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/session.php';

if (is_logged_in()) redirect(is_admin() ? 'admin.php' : 'index.php');

$error   = '';
$email   = '';
$mfaStep = false;

// Leer idioma lo antes posible para los mensajes de error
$_lg_u_early  = session_user();
$_lg_idioma_early = 'es';
if ($_lg_u_early) {
    try {
        $pref = db()->prepare('SELECT idioma FROM usuarios WHERE id=? LIMIT 1');
        $pref->execute([$_lg_u_early['id']]);
        $row = $pref->fetch();
        if ($row) $_lg_idioma_early = $row['idioma'];
    } catch (Exception $e) {}
}
$_lg_en_early = $_lg_idioma_early === 'en';

// ── Paso 2: verificar OTP ──────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['step'] ?? '') === 'mfa') {
    csrf_verify();
    $uid    = $_SESSION['mfa_pending_id'] ?? '';
    $codigo = trim($_POST['mfa_codigo']   ?? '');
    if (!$uid || strlen($codigo) !== 6) {
        $error = $_lg_en_early ? 'Enter the 6-digit code.' : 'Ingresa el código de 6 dígitos.'; $mfaStep = true;
    } else {
        try {
            $pdo = db();
            if (validar_otp($pdo, $uid, $codigo, 'email')) {
                $s = $pdo->prepare('SELECT * FROM usuarios WHERE id=? LIMIT 1');
                $s->execute([$uid]);
                $user = $s->fetch();
                unset($_SESSION['mfa_pending_id']);
                resetear_intentos($pdo, $uid);
                login_user($user);
                redirect($user['rol'] === 'admin' ? 'admin.php' : 'index.php');
            } else {
                $error = $_lg_en_early ? 'Incorrect or expired code.' : 'Código incorrecto o expirado.'; $mfaStep = true;
            }
        } catch (Exception $e) {
            $error = $_lg_en_early ? 'Connection error.' : 'Error de conexión.'; $mfaStep = true;
        }
    }
}
// ── Paso 1: email + contraseña ─────────────────────────────────────────────
elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $email    = trim($_POST['email']    ?? '');
    $password = trim($_POST['password'] ?? '');
    if (!$email || !$password) {
        $error = $_lg_en_early ? 'Please enter your email and password.' : 'Por favor ingresa tu correo y contraseña.';
    } else {
        try {
            $pdo = db();
            // Brute-force: verificar bloqueo ANTES de consultar contraseña
            if (cuenta_bloqueada($pdo, $email)) {
                $error = ($_lg_en_early
                    ? 'Account locked for ' . BLOQUEO_MIN . ' min. Use "Forgot your password?" to recover it.'
                    : 'Cuenta bloqueada por ' . BLOQUEO_MIN . ' min. Usa "¿Olvidaste tu contraseña?" para recuperarla.');
            } else {
                $s = $pdo->prepare('SELECT * FROM usuarios WHERE email=? LIMIT 1');
                $s->execute([$email]);
                $user = $s->fetch();
                if ($user && password_verify($password, $user['password_hash'])) {
                    if (!empty($user['mfa_activo'])) {
                        // MFA activo → enviar OTP
                        $_SESSION['mfa_pending_id'] = $user['id'];
                        $codigo = generar_otp($pdo, $user['id'], 'email');
                        Mailer::enviar($user['email'], 'Código de verificación — Bookia',
                            Mailer::htmlMFA($user['nombre'], $codigo, OTP_MIN));
                        $mfaStep = true;
                    } else {
                        resetear_intentos($pdo, $user['id']);
                        login_user($user);
                        redirect($user['rol'] === 'admin' ? 'admin.php' : 'index.php');
                    }
                } else {
                    registrar_intento_fallido($pdo, $email);
                    $error = $_lg_en_early ? 'Incorrect email or password.' : 'Correo o contraseña incorrectos.';
                }
            }
        } catch (Exception $e) {
            $error = $_lg_en_early ? 'Connection error. Check that MySQL is active.' : 'Error de conexión. Verifica que MySQL esté activo.';
        }
    }
}

// ── Preferencias tema/idioma ─────────────────────────────────────────────────
$_lg_u      = session_user();
$_lg_tema   = 0;
$_lg_idioma = 'es';
if ($_lg_u) {
    try {
        $pref = db()->prepare('SELECT tema_oscuro, idioma FROM usuarios WHERE id=? LIMIT 1');
        $pref->execute([$_lg_u['id']]);
        $row = $pref->fetch();
        if ($row) { $_lg_tema = (int)$row['tema_oscuro']; $_lg_idioma = $row['idioma']; }
    } catch (Exception $e) {}
}
$_lg_theme = $_lg_tema ? 'dark' : 'light';
$_lg_en    = $_lg_idioma === 'en';
?>
<!DOCTYPE html>
<html lang="<?= $_lg_idioma ?>" data-theme="<?= $_lg_theme ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $_lg_en ? "Log In — Bookia" : "Iniciar Sesión — Bookia" ?></title>
  <link rel="stylesheet" href="<?= url('css/estilos.css') ?>">
  <link rel="stylesheet" href="<?= url('css/animations.css') ?>">
  <style>
    .navbar { display: none; }
    .auth-page { min-height:100vh; display:grid; grid-template-columns:1fr 1fr; overflow:hidden; }

    .auth-panel-izq {
      background: linear-gradient(145deg,#4a0a1c 0%,#6B0F2A 40%,#8B1A3A 70%,#C9822A 100%);
      position:relative; display:flex; flex-direction:column; align-items:center;
      justify-content:center; padding:60px 50px; overflow:hidden; color:#fff;
    }
    .auth-panel-izq::before { content:''; position:absolute; width:350px; height:350px; border-radius:50%; border:2px solid rgba(255,255,255,.1); top:-80px; right:-80px; }
    .auth-panel-izq::after  { content:''; position:absolute; width:250px; height:250px; border-radius:50%; background:rgba(255,255,255,.05); bottom:-60px; left:-60px; }
    .auth-deco-circle { position:absolute; width:180px; height:180px; border-radius:50%; border:1px solid rgba(255,255,255,.12); top:50%; left:30%; transform:translate(-50%,-50%); pointer-events:none; }

    .auth-logo-grande { font-size:52px; font-weight:900; letter-spacing:-1px; margin-bottom:8px; z-index:1; text-shadow:0 2px 20px rgba(0,0,0,.3); }
    .auth-logo-grande span { color:#f5c87a; }
    .auth-tagline { font-size:15px; opacity:.85; text-align:center; max-width:280px; line-height:1.6; z-index:1; margin-bottom:40px; }

    .auth-features { display:flex; flex-direction:column; gap:16px; z-index:1; width:100%; max-width:300px; }
    .auth-feature { display:flex; align-items:center; gap:12px; background:rgba(255,255,255,.1); border:1px solid rgba(255,255,255,.15); border-radius:12px; padding:12px 16px; backdrop-filter:blur(4px); transition:transform .2s,background .2s; }
    .auth-feature:hover { transform:translateX(4px); background:rgba(255,255,255,.15); }
    .auth-feature-icono { font-size:20px; flex-shrink:0; }
    .auth-feature-texto { font-size:13px; line-height:1.4; }
    .auth-feature-texto strong { display:block; font-size:13px; }
    .auth-feature-texto small  { opacity:.75; font-size:12px; }

    .auth-libro-deco { position:absolute; font-size:30px; opacity:.15; pointer-events:none; animation:flotar 6s ease-in-out infinite; }
    @keyframes flotar { 0%,100%{transform:translateY(0) rotate(-5deg)} 50%{transform:translateY(-12px) rotate(5deg)} }

    .auth-panel-der { background:#fafafa; display:flex; flex-direction:column; justify-content:center; padding:60px 64px; overflow-y:auto; }
    .auth-volver { display:inline-flex; align-items:center; gap:6px; font-size:13px; color:var(--color-muted); text-decoration:none; margin-bottom:36px; transition:color .2s; }
    .auth-volver:hover { color:var(--color-primary); }
    .auth-titulo { font-size:28px; font-weight:800; color:#111827; line-height:1.2; margin-bottom:6px; }
    .auth-subtitulo { font-size:14px; color:var(--color-muted); margin-bottom:28px; }

    .auth-divider { display:flex; align-items:center; gap:14px; margin:22px 0; }
    .auth-divider::before,.auth-divider::after { content:''; flex:1; height:1px; background:#e5e7eb; }
    .auth-divider span { font-size:12px; color:#9CA3AF; white-space:nowrap; }

    .creds-demo { background:#EFF6FF; border:1px solid #BFDBFE; border-radius:10px; padding:12px 16px; font-size:12px; color:#1E40AF; margin-bottom:22px; line-height:1.6; }
    .creds-demo strong { display:block; margin-bottom:4px; }

    .auth-check-row { display:flex; align-items:center; justify-content:space-between; margin-bottom:20px; font-size:13px; }
    .auth-check-row label { display:flex; align-items:center; gap:8px; cursor:pointer; color:#374151; }
    .auth-check-row a { color:var(--color-accent); text-decoration:none; font-size:13px; }
    .auth-check-row a:hover { text-decoration:underline; }

    html[data-theme="dark"] body { background: #0f0f14 !important; }
    html[data-theme="dark"] .auth-panel-der { background: #0f0f14 !important; }
    html[data-theme="dark"] .auth-titulo    { color: #e8e0d0 !important; }
    html[data-theme="dark"] .auth-subtitulo { color: #9ca3af !important; }
    html[data-theme="dark"] .creds-demo     { background: #1a1a24 !important; border-color: #2e2e3e !important; color: #9ca3af !important; }
    html[data-theme="dark"] .auth-check-row label { color: #e8e0d0 !important; }
    html[data-theme="dark"] .auth-divider::before,
    html[data-theme="dark"] .auth-divider::after { background: #2e2e3e !important; }
    @media(max-width:800px){ .auth-page{grid-template-columns:1fr} .auth-panel-izq{display:none} .auth-panel-der{padding:40px 24px} }
  </style>
</head>
<body>
<div class="auth-page">

  <!-- PANEL IZQUIERDO -->
  <div class="auth-panel-izq">
    <div class="auth-deco-circle"></div>
    <span class="auth-libro-deco" style="top:15%;left:12%;animation-delay:0s">📖</span>
    <span class="auth-libro-deco" style="top:70%;right:10%;animation-delay:2s;font-size:22px">📚</span>
    <span class="auth-libro-deco" style="bottom:20%;left:20%;animation-delay:4s;font-size:18px">📕</span>
    <div class="auth-logo-grande">📚 Book<span>ia</span></div>
    <p class="auth-tagline"><?= $_lg_en ? "Your trusted pick-up library in Aguascalientes.<br>Reserve, pick up and enjoy." : "Tu librería pick-up de confianza en Aguascalientes.<br>Reserva, recoge y disfruta." ?></p>
    <div class="auth-features">
      <div class="auth-feature"><span class="auth-feature-icono">📌</span><div class="auth-feature-texto"><strong><?= $_lg_en?'Reserve in seconds':'Reserva en segundos' ?></strong><small><?= $_lg_en?'Hold your book before you go':'Separa tu libro antes de ir' ?></small></div></div>
      <div class="auth-feature"><span class="auth-feature-icono">🏪</span><div class="auth-feature-texto"><strong><?= $_lg_en?'Express Pick-Up':'Pick-Up exprés' ?></strong><small><?= $_lg_en?'Pick up whenever you want':'Recoge cuando tú quieras' ?></small></div></div>
      <div class="auth-feature"><span class="auth-feature-icono">📖</span><div class="auth-feature-texto"><strong>+500 <?= $_lg_en?'titles':'títulos' ?></strong><small><?= $_lg_en?'Catalogue updated weekly':'Catálogo actualizado semanalmente' ?></small></div></div>
    </div>
  </div>

  <!-- PANEL DERECHO -->
  <div class="auth-panel-der">
    <div style="text-align:center;margin-bottom:28px">
      <img src="<?= url('img/logo.png') ?>" alt="Bookia"
           style="width:80px;height:80px;object-fit:contain;border-radius:14px;
                  box-shadow:0 4px 20px rgba(107,15,42,.2);">
    </div>
    <a href="<?= url('index.php') ?>" class="auth-volver"><?= $_lg_en ? '← Back to home' : '← Volver al inicio' ?></a>

    <?php if ($error): ?>
      <div class="msg msg-error" style="margin-bottom:16px"><span class="msg-icon">✕</span><div><?= e($error) ?></div></div>
    <?php endif; ?>

    <h1 class="auth-titulo"><?= $_lg_en ? "Welcome back 👋" : "Bienvenido de nuevo 👋" ?></h1>
    <p class="auth-subtitulo"><?= $_lg_en ? "Enter your details to access your account" : "Ingresa tus datos para acceder a tu cuenta" ?></p>

    <?php if ($mfaStep): ?>
    <!-- PASO 2: Verificación MFA -->
    <div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:10px;padding:12px 16px;font-size:13px;color:#1E40AF;margin-bottom:20px">
      <strong>✉ <?= $_lg_en ? "Two-step verification" : "Verificación en dos pasos" ?></strong><br>
      <?= $_lg_en ? "We sent a 6-digit code to your email. Enter it to continue." : "Enviamos un código de 6 dígitos a tu correo. Ingrésalo para continuar." ?>
    </div>
    <form method="POST" action="<?= url('login.php') ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="step" value="mfa">
      <div class="form-group">
        <label for="mfa_codigo"><?= $_lg_en ? "Verification code" : "Código de verificación" ?> <span class="required">*</span></label>
        <div class="input-wrapper"><span class="input-icon">🔑</span>
          <input type="text" id="mfa_codigo" name="mfa_codigo" maxlength="6" pattern="\d{6}"
                 placeholder="000000" autocomplete="one-time-code" required autofocus
                 style="letter-spacing:8px;font-size:22px;font-weight:900;text-align:center">
        </div>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px;font-size:15px">
        <?= $_lg_en ? "Verify code →" : "Verificar código →" ?>
      </button>
    </form>
    <div style="text-align:center;margin-top:14px;font-size:13px;color:#6B7280">
      <?php $lnk = url('login.php'); echo $_lg_en ? "Didn't receive the code? <a href='$lnk' style='color:var(--color-accent)'>Go back</a>" : "¿No recibiste el código? <a href='$lnk' style='color:var(--color-accent)'>Volver</a>"; ?>
    </div>

    <?php else: ?>
    <!-- PASO 1: Email + Contraseña -->
    <form method="POST" action="<?= url('login.php') ?>">
      <?= csrf_field() ?>
      <div class="form-group">
        <label for="email"><?= $_lg_en ? "Email address" : "Correo electrónico" ?> <span class="required">*</span></label>
        <div class="input-wrapper">
          <span class="input-icon">✉</span>
          <input type="email" id="email" name="email" value="<?= e($email) ?>" placeholder="<?= $_lg_en ? 'your@email.com' : 'tu@correo.com' ?>" autocomplete="email" required autofocus>
        </div>
      </div>
      <div class="form-group">
        <label for="password"><?= $_lg_en ? "Password" : "Contraseña" ?> <span class="required">*</span></label>
        <div class="input-wrapper">
          <span class="input-icon">🔒</span>
          <input type="password" id="password" name="password" placeholder="<?= $_lg_en ? 'Your password' : 'Tu contraseña' ?>" autocomplete="current-password" required>
        </div>
      </div>
      <div class="auth-check-row">
        <label><input type="checkbox" name="remember"> <?= $_lg_en ? "Remember me" : "Recordar sesión" ?></label>
        <a href="<?= url('recuperar.php') ?>"><?= $_lg_en ? 'Forgot your password?' : '¿Olvidaste tu contraseña?' ?></a>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px;font-size:15px">
        <?= $_lg_en ? "Log In →" : "Iniciar Sesión →" ?>
      </button>
    </form>
    <?php endif; ?>


    <div class="auth-divider"><span><?= $_lg_en ? "Don't have an account?" : '¿No tienes cuenta?' ?></span></div>
    <a href="<?= url('registro.php') ?>" class="btn btn-ghost" style="width:100%;justify-content:center;padding:13px;font-size:14px">
      <?= $_lg_en?'Create free account':'Crear cuenta gratis' ?>
    </a>
    <p style="text-align:center;margin-top:28px;font-size:12px;color:#9CA3AF">&copy; Bookia 2026 · Angela Guadalupe Ropón Campos</p>
  </div>
</div>
<script src="<?= url('js/animations.js') ?>"></script>
</body>
</html>
