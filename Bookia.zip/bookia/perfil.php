<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/session.php';
require_login('login.php');

$u       = session_user();
$idioma  = $u['idioma'] ?? 'es';
$reservas = [];
$msg     = '';

// Cancelar reserva
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'cancelar') {
    csrf_verify();
    csrf_verify();
    $rid = $_POST['reserva_id'] ?? '';
    try {
        $pdo  = db();
        $pdo->beginTransaction();
        $stmt = $pdo->prepare('SELECT libro_id FROM reservas WHERE id=? AND usuario_id=? AND estado="pendiente"');
        $stmt->execute([$rid, $u['id']]);
        $res = $stmt->fetch();
        if ($res) {
            $pdo->prepare('UPDATE reservas SET estado="cancelada" WHERE id=?')->execute([$rid]);
            $pdo->prepare('UPDATE libros SET disponibles=disponibles+1 WHERE id=?')->execute([$res['libro_id']]);
            $pdo->commit();
            $msg = $idioma==='en'?'Reservation cancelled successfully.':'Reserva cancelada correctamente.';
        } else {
            $pdo->rollBack();
            $msg = $idioma==='en'?'Could not cancel the reservation.':'No se pudo cancelar la reserva.';
        }
    } catch (Exception $e) {
        if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    }
}

try {
    $reservas = db()->prepare(
        'SELECT r.*, l.imagen FROM reservas r
         LEFT JOIN libros l ON r.libro_id = l.id
         WHERE r.usuario_id = ?
         ORDER BY r.created_at DESC'
    );
    $reservas->execute([$u['id']]);
    $reservas = $reservas->fetchAll();
} catch (Exception $e) {}

$estadoLabels  = [$idioma==='en'?['pendiente'=>'Pending','lista'=>'Ready to pick up','recogida'=>'Picked up','cancelada'=>'Cancelled']:['pendiente'=>'Pendiente','lista'=>'Lista para recoger','recogida'=>'Recogida','cancelada'=>'Cancelada']];
$estadoClasses = ['pendiente'=>'pill-yellow','lista'=>'pill-green','recogida'=>'pill-blue','cancelada'=>'pill-red'];

$pageTitle = 'My Profile — Bookia';
require_once __DIR__ . '/includes/header.php';
?>

<div class="breadcrumbs">
  <ul>
    <li><a href="<?= url('index.php') ?>"><?= $idioma==='en'?'Home':'Inicio' ?></a></li>
    <li><span class="current"><?= $idioma==='en'?'My Profile':'Mi Perfil' ?></span></li>
  </ul>
</div>

<div class="perfil-grid">
  <!-- Sidebar -->
  <aside>
    <div class="perfil-sidebar-card">
      <div class="perfil-avatar-section">
        <div class="perfil-avatar">👤</div>
        <h3><?= e($u['nombre']) ?></h3>
        <p><?= e($u['email']) ?></p>
      </div>
      <ul class="perfil-nav">
        <li><a href="#reservas" class="active">📋 <?= $idioma==='en'?'My Reservations':'Mis Reservas' ?></a></li>
        <li><a href="<?= url('seguridad.php') ?>">🔒 <?= $idioma==='en'?'Security':'Seguridad' ?></a></li>
      </ul>
    </div>
  </aside>

  <!-- Contenido -->
  <main>
    <div class="perfil-main-card">
      <div class="form-content-header" style="border-radius:0">
        <h2>📋 <?= $idioma==='en'?'My Reservations':'Mis Reservas' ?></h2>
        <p><?= count($reservas) ?> <?= $idioma==='en'?'reservation':'reserva' ?><?= count($reservas)!==1?'s':'' ?> <?= $idioma==='en'?'registered':'registrada' ?><?= count($reservas)!==1?'s':'' ?></p>
      </div>
      <div style="padding:24px">
        <?php if ($msg): ?>
          <div class="msg msg-success"><span class="msg-icon">✓</span><?= e($msg) ?></div>
        <?php endif; ?>

        <?php if (empty($reservas)): ?>
          <div class="empty-state">
            <div class="empty-icon">📋</div>
            <h4><?= $idioma==='en'?'No reservations yet':'Sin reservas aún' ?></h4>
            <p><?= $idioma==='en'?'Browse the catalogue and reserve your next read.':'Explora el catálogo y reserva tu próxima lectura.' ?></p>
            <a href="<?= url('catalogo.php') ?>" class="btn" style="margin-top:16px"><?= $idioma==='en'?'Browse catalogue':'Ver catálogo' ?></a>
          </div>
        <?php else: ?>
          <?php foreach ($reservas as $r): ?>
            <div class="reserva-card">
              <?php if ($r['imagen']): ?>
                <img class="reserva-cover" src="<?= e($r['imagen']) ?>" alt="<?= e($r['titulo_libro']) ?>"
                     onerror="this.style.display='none'">
              <?php else: ?>
                <div class="reserva-cover" style="background:linear-gradient(135deg,#6B0F2A,#8B1A3A);display:flex;align-items:center;justify-content:center;font-size:24px">📚</div>
              <?php endif; ?>
              <div class="reserva-info">
                <h4><?= e($r['titulo_libro']) ?></h4>
                <p><?= e($r['autor_libro']) ?></p>
                <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:8px">
                  <span class="pill <?= $estadoClasses[$r['estado']] ?? 'pill-gray' ?>"><?= $estadoLabels[$r['estado']] ?? $r['estado'] ?></span>
                  <?php if ($r['fecha_recogida']): ?>
                    <span style="font-size:12px;color:#6B7280">📅 <?= e($r['fecha_recogida']) ?></span>
                  <?php endif; ?>
                </div>
                <?php if (in_array($r['estado'], ['pendiente','lista']) && $r['codigo_recogida']): ?>
                  <div style="background:linear-gradient(135deg,rgba(107,15,42,0.06),rgba(193,154,107,0.08));border:1px dashed rgba(107,15,42,0.25);border-radius:10px;padding:10px 14px">
                    <div style="font-size:10px;font-weight:700;color:#9CA3AF;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px"><?= $idioma==='en'?'Pick-up code':'Código de recogida' ?></div>
                    <code style="font-size:17px;font-weight:900;color:#6B0F2A;letter-spacing:2px"><?= e($r['codigo_recogida']) ?></code>
                  </div>
                <?php endif; ?>
              </div>
              <?php if ($r['estado'] === 'pendiente'): ?>
                <form method="POST" style="flex-shrink:0;align-self:flex-start">
                  <?= csrf_field() ?>
                  <?= csrf_field() ?>
                  <input type="hidden" name="action"    value="cancelar">
                  <input type="hidden" name="reserva_id" value="<?= e($r['id']) ?>">
                  <button type="submit" class="btn btn-danger btn-sm"
                          onclick="return confirm('<?= $idioma==='en'?'Cancel this reservation?':'¿Cancelar esta reserva?' ?>')"><?= $idioma==='en'?'Cancel':'Cancelar' ?></button>
                </form>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </main>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
