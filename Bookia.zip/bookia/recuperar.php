<?php
/**
 * BOOKIA — Recuperación de contraseña
 */
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/session.php';
if (is_logged_in()) redirect('index.php');

// Leer preferencias de tema e idioma (usuario puede no estar logueado — leer de sesión temporal o default)
$_rec_u      = session_user();
$_rec_tema   = 0;
$_rec_idioma = 'es';
if ($_rec_u) {
    try {
        $pref = db()->prepare('SELECT tema_oscuro, idioma FROM usuarios WHERE id=? LIMIT 1');
        $pref->execute([$_rec_u['id']]);
        $row = $pref->fetch();
        if ($row) { $_rec_tema = (int)$row['tema_oscuro']; $_rec_idioma = $row['idioma']; }
    } catch (Exception $e) {}
}
// Si hay reset_uid en sesión, podemos leer preferencias del usuario que recupera
if (!$_rec_u && !empty($_SESSION['reset_uid'])) {
    try {
        $pref = db()->prepare('SELECT tema_oscuro, idioma FROM usuarios WHERE id=? LIMIT 1');
        $pref->execute([$_SESSION['reset_uid']]);
        $row = $pref->fetch();
        if ($row) { $_rec_tema = (int)$row['tema_oscuro']; $_rec_idioma = $row['idioma']; }
    } catch (Exception $e) {}
}
$_rec_theme = $_rec_tema ? 'dark' : 'light';
$en         = $_rec_idioma === 'en';

$error   = '';
$success = '';
$step    = $_GET['step']  ?? 'solicitar';
$token   = $_GET['token'] ?? '';
$codigoVisible = ''; // código que se mostrará en pantalla (simulado)

// ── Nueva contraseña con token email ──────────────────────────────────────────
if ($step === 'nueva' && $token) {
    try {
        $pdo    = db();
        $userId = validar_token_reset($pdo, $token);
        if (!$userId) { $error = $en ? 'The link is invalid or expired.' : 'El enlace es inválido o expiró.'; $step = 'solicitar'; }
        elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
            csrf_verify();
            $p1 = $_POST['password']  ?? '';
            $p2 = $_POST['password2'] ?? '';
            if (strlen($p1) < 8)  { $error = $en ? 'Minimum 8 characters.' : 'Mínimo 8 caracteres.'; }
            elseif ($p1 !== $p2)  { $error = $en ? 'Passwords do not match.' : 'Las contraseñas no coinciden.'; }
            else {
                $h = password_hash($p1, PASSWORD_BCRYPT, ['cost'=>12]);
                $pdo->prepare('UPDATE usuarios SET password_hash=?,intentos_fallidos=0,bloqueado_hasta=NULL WHERE id=?')
                    ->execute([$h, $userId]);
                consumir_token_reset($pdo, $token);
                $success = $en ? '✅ Password updated. You can now log in.' : '✅ Contraseña actualizada. Ya puedes iniciar sesión.';
                $step = 'listo';
            }
        }
    } catch (Exception $e) { $error = $en ? 'Database error.' : 'Error de base de datos.'; $step = 'solicitar'; }
}

// ── Validar OTP de SMS ─────────────────────────────────────────────────────────
elseif ($step === 'otp_sms' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $uid = $_SESSION['reset_uid'] ?? '';
    $cod = trim($_POST['otp_codigo'] ?? '');
    try {
        $pdo = db();
        if (validar_otp($pdo, $uid, $cod, 'sms')) {
            $tk = generar_token_reset($pdo, $uid, 'email');
            redirect("recuperar.php?step=nueva&token=$tk");
        } else { $error = $en ? 'Incorrect or expired code.' : 'Código incorrecto o expirado.'; }
    } catch (Exception $e) { $error = $en ? 'Database error.' : 'Error de base de datos.'; }
}

// ── Validar OTP de llamada ────────────────────────────────────────────────────
elseif ($step === 'otp_voz' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $uid = $_SESSION['reset_uid'] ?? '';
    $cod = trim($_POST['otp_codigo'] ?? '');
    try {
        $pdo = db();
        if (validar_otp($pdo, $uid, $cod, 'voz')) {
            $tk = generar_token_reset($pdo, $uid, 'email');
            redirect("recuperar.php?step=nueva&token=$tk");
        } else { $error = $en ? 'Incorrect or expired code.' : 'Código incorrecto o expirado.'; }
    } catch (Exception $e) { $error = $en ? 'Database error.' : 'Error de base de datos.'; }
}

// ── Validar pregunta secreta ───────────────────────────────────────────────────
elseif ($step === 'pregunta' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $uid  = $_SESSION['reset_uid'] ?? '';
    $resp = strtolower(trim($_POST['respuesta'] ?? ''));
    try {
        $pdo  = db();
        $s    = $pdo->prepare('SELECT respuesta_secreta, intentos_fallidos FROM usuarios WHERE id=? LIMIT 1');
        $s->execute([$uid]);
        $u = $s->fetch();
        if (!$u || !$u['respuesta_secreta']) { $error = $en ? 'You have no secret question configured.' : 'No tienes pregunta secreta configurada.'; }
        elseif ((int)$u['intentos_fallidos'] >= MAX_INTENTOS) { $error = $en ? 'Too many attempts. Use another method.' : 'Demasiados intentos. Usa otro método.'; }
        elseif (password_verify($resp, $u['respuesta_secreta'])) {
            $pdo->prepare('UPDATE usuarios SET intentos_fallidos=0 WHERE id=?')->execute([$uid]);
            $tk = generar_token_reset($pdo, $uid, 'email');
            redirect("recuperar.php?step=nueva&token=$tk");
        } else {
            $pdo->prepare('UPDATE usuarios SET intentos_fallidos=intentos_fallidos+1 WHERE id=?')->execute([$uid]);
            $error = $en ? 'Incorrect answer.' : 'Respuesta incorrecta.';
        }
    } catch (Exception $e) { $error = $en ? 'Database error.' : 'Error de base de datos.'; }
}

// ── Solicitar recuperación ────────────────────────────────────────────────────
elseif ($step === 'solicitar' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $email  = trim($_POST['email']  ?? '');
    $metodo = $_POST['metodo'] ?? 'email';
    try {
        $pdo = db();
        $s   = $pdo->prepare('SELECT * FROM usuarios WHERE email=? LIMIT 1');
        $s->execute([$email]);
        $user = $s->fetch();
        if ($user) {
            if ($metodo === 'email') {
                $tk   = generar_token_reset($pdo, $user['id'], 'email');
                $link = (isset($_SERVER['HTTPS'])?'https':'http') . '://' . $_SERVER['HTTP_HOST'] . url("recuperar.php?step=nueva&token=$tk");
                Mailer::enviar($user['email'], 'Recuperar contraseña — Bookia', Mailer::htmlReset($user['nombre'], $link, RESET_MIN));
                $success = $en ? '📧 If that email exists, you will receive a link.' : '📧 Si ese correo existe, recibirás un enlace.';
            } elseif ($metodo === 'sms') {
                $_SESSION['reset_uid'] = $user['id'];
                $cod = generar_otp($pdo, $user['id'], 'sms');
                Mailer::sms($user['telefono'] ?? 'N/A', ($en ? "Your Bookia recovery code: $cod (valid " . OTP_MIN . " min)" : "Tu código de recuperación Bookia: $cod (válido " . OTP_MIN . " min)"));
                $codigoVisible = $cod; // mostrar en pantalla
                $success = $en ? '📱 SMS sent (simulated). Your code is shown below.' : '📱 Código SMS enviado (simulado). Tu código aparece abajo.';
                $step = 'otp_sms';
            } elseif ($metodo === 'voz') {
                $_SESSION['reset_uid'] = $user['id'];
                $cod = generar_otp($pdo, $user['id'], 'voz');
                Mailer::llamada($user['telefono'] ?? 'N/A', $cod);
                $codigoVisible = $cod;
                $success = $en ? '📞 Simulated call. Your code is shown below.' : '📞 Llamada simulada. Tu código aparece abajo.';
                $step = 'otp_voz';
            } elseif ($metodo === 'pregunta') {
                $s2 = $pdo->prepare('SELECT pregunta_secreta FROM usuarios WHERE id=? LIMIT 1');
                $s2->execute([$user['id']]);
                $row = $s2->fetch();
                if ($row && $row['pregunta_secreta']) {
                    $_SESSION['reset_uid']      = $user['id'];
                    $_SESSION['reset_pregunta'] = $row['pregunta_secreta'];
                    $step = 'pregunta';
                } else { $success = $en ? '📧 If that email exists, you will receive instructions.' : '📧 Si ese correo existe en nuestro sistema, recibirás indicaciones.'; }
            }
        } else {
            $success = $en ? '📧 If that email exists in our system, you will receive instructions.' : '📧 Si ese correo existe en nuestro sistema, recibirás indicaciones.';
        }
    } catch (Exception $e) { $error = $en ? 'Database error.' : 'Error de base de datos.'; }
}
?>
<!DOCTYPE html>
<html lang="<?= $_rec_idioma ?>" data-theme="<?= $_rec_theme ?>">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $en ? 'Recover Password — Bookia' : 'Recuperar contraseña — Bookia' ?></title>
  <link rel="stylesheet" href="<?= url('css/estilos.css') ?>">
  <link rel="stylesheet" href="<?= url('css/animations.css') ?>">
  <style>
    .navbar{display:none}
    .auth-page{min-height:100vh;display:grid;grid-template-columns:1fr 1.1fr;overflow:hidden}
    .auth-panel-izq{background:linear-gradient(155deg,#1a0a2e 0%,#6B0F2A 65%,#C9822A 100%);display:flex;flex-direction:column;align-items:center;justify-content:center;padding:60px 50px;color:#fff}
    .auth-logo{font-size:48px;font-weight:900;letter-spacing:-1px;margin-bottom:8px}
    .auth-logo span{color:#f5c87a}
    .auth-panel-der{background:#f9fafb;display:flex;flex-direction:column;justify-content:center;padding:48px 60px;overflow-y:auto}
    [data-theme="dark"] .auth-panel-der{background:#0f0f14}
    .auth-volver{display:inline-flex;align-items:center;gap:6px;font-size:13px;color:var(--color-muted);text-decoration:none;margin-bottom:28px}
    .auth-volver:hover{color:var(--color-primary)}
    .auth-titulo{font-size:26px;font-weight:800;color:#111827;margin-bottom:6px}
    [data-theme="dark"] .auth-titulo{color:#e8e0d0}
    .auth-sub{font-size:13px;color:var(--color-muted);margin-bottom:24px}
    .metodo-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:20px}
    .metodo-btn{border:2px solid #e5e7eb;border-radius:10px;padding:14px 10px;text-align:center;cursor:pointer;background:#fff;font-size:13px;transition:.2s}
    [data-theme="dark"] .metodo-btn{background:#1a1a24;border-color:#2e2e3e;color:#e8e0d0}
    .metodo-btn input[type=radio]{display:none}
    .metodo-btn:has(input:checked){border-color:#6B0F2A;background:#fdf2f4}
    [data-theme="dark"] .metodo-btn:has(input:checked){background:#2d0a1a}
    .metodo-icon{font-size:22px;display:block;margin-bottom:4px}
    /* Código simulado visible */
    .codigo-simulado{background:linear-gradient(135deg,#1a0a2e,#6B0F2A);border-radius:14px;padding:20px 24px;text-align:center;margin:16px 0;position:relative;overflow:hidden}
    .codigo-simulado::before{content:'SIM';position:absolute;top:8px;right:12px;font-size:10px;font-weight:800;color:rgba(255,255,255,.3);letter-spacing:2px}
    .codigo-simulado .cod-label{font-size:12px;color:rgba(255,255,255,.7);margin-bottom:8px;font-weight:600;letter-spacing:1px;text-transform:uppercase}
    .codigo-simulado .cod-num{font-size:38px;font-weight:900;color:#f5c87a;letter-spacing:12px;font-family:monospace;text-shadow:0 0 20px rgba(245,200,122,.4)}
    .codigo-simulado .cod-exp{font-size:11px;color:rgba(255,255,255,.5);margin-top:8px}
    @media(max-width:800px){.auth-page{grid-template-columns:1fr}.auth-panel-izq{display:none}.auth-panel-der{padding:40px 24px}}
  </style>
</head>
<body>
<div class="auth-page">
  <div class="auth-panel-izq">
    <div class="auth-logo">📚 Book<span>ia</span></div>
    <p style="font-size:14px;opacity:.85;text-align:center;max-width:280px"><?= $en ? 'Recover access to your account.' : 'Recupera el acceso a tu cuenta.' ?></p>
  </div>
  <div class="auth-panel-der">
    <a href="<?= url('login.php') ?>" class="auth-volver">← <?= $en ? 'Back to login' : 'Volver al login' ?></a>

    <?php if ($error): ?>
      <div class="msg msg-error" style="margin-bottom:16px"><span class="msg-icon">✕</span><?= e($error) ?></div>
    <?php endif; ?>

    <?php if ($step === 'listo'): ?>
      <h1 class="auth-titulo"><?= $en ? 'Password updated! ✅' : '¡Contraseña actualizada! ✅' ?></h1>
      <p class="auth-sub"><?= $en ? 'You can now log in with your new password.' : 'Ya puedes iniciar sesión con tu nueva contraseña.' ?></p>
      <a href="<?= url('login.php') ?>" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px"><?= $en ? 'Go to login →' : 'Ir al login →' ?></a>

    <?php elseif ($step === 'nueva' && !$error): ?>
      <h1 class="auth-titulo"><?= $en ? 'New password 🔒' : 'Nueva contraseña 🔒' ?></h1>
      <p class="auth-sub"><?= $en ? 'Choose a secure password of at least 8 characters.' : 'Elige una contraseña segura de al menos 8 caracteres.' ?></p>
      <form method="POST" action="<?= url("recuperar.php?step=nueva&token=" . urlencode($token)) ?>">
        <?= csrf_field() ?>
        <div class="form-group"><label><?= $en ? 'New password' : 'Nueva contraseña' ?> <span class="required">*</span></label>
          <div class="input-wrapper"><span class="input-icon">🔒</span>
            <input type="password" name="password" minlength="8" required autofocus></div></div>
        <div class="form-group"><label><?= $en ? 'Confirm password' : 'Confirmar contraseña' ?> <span class="required">*</span></label>
          <div class="input-wrapper"><span class="input-icon">🔒</span>
            <input type="password" name="password2" minlength="8" required></div></div>
        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px"><?= $en ? 'Save password →' : 'Guardar contraseña →' ?></button>
      </form>

    <?php elseif ($step === 'otp_sms' || $step === 'otp_voz'): ?>
      <h1 class="auth-titulo"><?= $step==='otp_sms' ? ($en ? '📱 SMS Verification' : '📱 Verificación por SMS') : ($en ? '📞 Call Verification' : '📞 Verificación por llamada') ?></h1>

      <?php if ($success): ?>
      <div style="background:<?= $step==='otp_sms' ? '#F0FDF4' : '#EFF6FF' ?>;
                  border:1px solid <?= $step==='otp_sms' ? '#BBF7D0' : '#BFDBFE' ?>;
                  border-radius:12px;padding:16px 18px;margin-bottom:16px;display:flex;gap:12px;align-items:flex-start">
        <span style="font-size:24px"><?= $step==='otp_sms' ? '📱' : '📞' ?></span>
        <div style="font-size:13px;color:<?= $step==='otp_sms' ? '#166534' : '#1E40AF' ?>">
          <strong><?= $step==='otp_sms' ? ($en ? 'Message sent' : 'Mensaje enviado') : ($en ? 'Call made' : 'Llamada realizada') ?></strong><br>
          <?= $step==='otp_sms'
              ? ($en ? 'Your code is shown below (simulated).' : 'Tu código aparece abajo (simulado).')
              : ($en ? 'Your code is shown below (simulated).' : 'Tu código aparece abajo (simulado).') ?>
        </div>
      </div>
      <?php endif; ?>

      <?php if ($codigoVisible): ?>
      <!-- Código visible en pantalla — modo desarrollo simulado -->
      <div class="codigo-simulado">
        <div class="cod-label"><?= $step==='otp_sms' ? ($en ? '📱 SMS Code' : '📱 Código SMS') : ($en ? '📞 Call Code' : '📞 Código de llamada') ?></div>
        <div class="cod-num"><?= e($codigoVisible) ?></div>
        <div class="cod-exp"><?= $en ? 'Valid for ' . OTP_MIN . ' minutes · Simulated' : 'Válido por ' . OTP_MIN . ' minutos · Simulado' ?></div>
      </div>
      <?php endif; ?>

      <?php if ($error): ?>
        <div class="msg msg-error" style="margin-bottom:16px"><span class="msg-icon">✕</span><?= e($error) ?></div>
      <?php endif; ?>

      <form method="POST" action="<?= url("recuperar.php?step=$step") ?>">
        <?= csrf_field() ?>
        <div class="form-group">
          <label><?= $en ? 'Verification code' : 'Código de verificación' ?> <span class="required">*</span></label>
          <p style="font-size:12px;color:#6B7280;margin:-4px 0 10px">
            <?= $en ? ($step==='otp_sms' ? 'Enter the 6 digits received by SMS.' : 'Enter the 6 digits received by call.') : ($step==='otp_sms' ? 'Ingresa los 6 dígitos recibidos por SMS.' : 'Ingresa los 6 dígitos recibidos por llamada.') ?>
          </p>
          <div class="input-wrapper"><span class="input-icon">🔑</span>
            <input type="text" name="otp_codigo" maxlength="6" pattern="\d{6}" placeholder="000000"
                   autocomplete="one-time-code" inputmode="numeric" required autofocus
                   style="letter-spacing:10px;font-size:26px;font-weight:900;text-align:center;padding:14px 0"></div>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px">
          <?= $en ? 'Verify code →' : 'Verificar código →' ?>
        </button>
      </form>
      <div style="text-align:center;margin-top:16px;font-size:13px;color:#9CA3AF">
        <?= $en ? "Didn't receive the code?" : '¿No recibiste el código?' ?>
        <a href="<?= url('recuperar.php') ?>" style="color:var(--color-accent)"><?= $en ? 'Try again' : 'Intentar de nuevo' ?></a>
      </div>
      <div style="text-align:center;margin-top:8px;font-size:13px;color:#9CA3AF">
        <?= $en ? 'Remembered your password?' : '¿Recordaste tu contraseña?' ?>
        <a href="<?= url('login.php') ?>" style="color:var(--color-accent)"><?= $en ? 'Log in' : 'Inicia sesión' ?></a>
      </div>

    <?php elseif ($step === 'pregunta'): ?>
      <h1 class="auth-titulo">🔐 <?= $en ? 'Secret question' : 'Pregunta secreta' ?></h1>
      <div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:10px;padding:12px 16px;font-size:13px;color:#1E40AF;margin-bottom:20px">
        <strong><?= $en ? 'Question' : 'Pregunta' ?>:</strong> <?= e($_SESSION['reset_pregunta'] ?? '') ?>
      </div>
      <form method="POST" action="<?= url('recuperar.php?step=pregunta') ?>">
        <?= csrf_field() ?>
        <div class="form-group"><label><?= $en ? 'Your answer' : 'Tu respuesta' ?> <span class="required">*</span></label>
          <div class="input-wrapper"><span class="input-icon">💬</span>
            <input type="text" name="respuesta" required autofocus autocomplete="off"></div></div>
        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px"><?= $en ? 'Verify answer →' : 'Verificar respuesta →' ?></button>
      </form>

    <?php else: ?>
      <h1 class="auth-titulo"><?= $en ? 'Recover password 🔑' : 'Recuperar contraseña 🔑' ?></h1>
      <?php if ($success): ?><div class="msg msg-success" style="margin-bottom:16px"><span class="msg-icon">✓</span><?= e($success) ?></div><?php endif; ?>
      <p class="auth-sub"><?= $en ? 'Enter your email and choose a recovery method.' : 'Elige tu correo y el método de recuperación.' ?></p>
      <form method="POST" action="<?= url('recuperar.php') ?>">
        <?= csrf_field() ?>
        <div class="form-group" style="margin-bottom:20px"><label><?= $en ? 'Email address' : 'Correo electrónico' ?> <span class="required">*</span></label>
          <div class="input-wrapper"><span class="input-icon">✉</span>
            <input type="email" name="email" placeholder="<?= $en ? 'your@email.com' : 'tu@correo.com' ?>" required autofocus></div></div>
        <p style="font-size:13px;font-weight:600;color:#374151;margin-bottom:10px"><?= $en ? 'Recovery method:' : 'Método de recuperación:' ?></p>
        <div class="metodo-grid">
          <label class="metodo-btn"><input type="radio" name="metodo" value="email" checked>
            <span class="metodo-icon">📧</span><strong><?= $en ? 'Email' : 'Correo' ?></strong><br><small style="color:#6B7280"><?= $en ? 'Link by email' : 'Enlace por email' ?></small></label>
          <label class="metodo-btn"><input type="radio" name="metodo" value="sms">
            <span class="metodo-icon">📱</span><strong>SMS</strong><br><small style="color:#6B7280"><?= $en ? 'Code by SMS' : 'Código por SMS' ?></small></label>
          <label class="metodo-btn"><input type="radio" name="metodo" value="voz">
            <span class="metodo-icon">📞</span><strong><?= $en ? 'Call' : 'Llamada' ?></strong><br><small style="color:#6B7280"><?= $en ? 'Code by call' : 'Código por voz' ?></small></label>
          <label class="metodo-btn"><input type="radio" name="metodo" value="pregunta">
            <span class="metodo-icon">🔐</span><strong><?= $en ? 'Question' : 'Pregunta' ?></strong><br><small style="color:#6B7280"><?= $en ? 'Secret answer' : 'Respuesta secreta' ?></small></label>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px"><?= $en ? 'Continue →' : 'Continuar →' ?></button>
      </form>
    <?php endif; ?>

    <div style="text-align:center;margin-top:20px;font-size:13px;color:#9CA3AF">
      <?= $en ? 'Remembered your password?' : '¿Recordaste tu contraseña?' ?>
      <a href="<?= url('login.php') ?>" style="color:var(--color-accent)"><?= $en ? 'Log in' : 'Inicia sesión' ?></a>
    </div>
  </div>
</div>
<script src="<?= url('js/animations.js') ?>"></script>
</body>
</html>
