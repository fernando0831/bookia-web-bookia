<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/session.php';

if (is_logged_in()) redirect('index.php');

$error  = '';
$datos  = ['nombre'=>'','email'=>'','telefono'=>''];

// Leer idioma para mensajes de error
$_reg_u_early = session_user();
$_reg_idioma_early = 'es';
if ($_reg_u_early) {
    try { $pref = db()->prepare('SELECT idioma FROM usuarios WHERE id=? LIMIT 1'); $pref->execute([$_reg_u_early['id']]); $row=$pref->fetch(); if($row) $_reg_idioma_early=$row['idioma']; } catch(Exception $e){}
}
$_reg_en_early = $_reg_idioma_early === 'en';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    csrf_verify();
    $datos = [
        'nombre'   => trim($_POST['nombre']   ?? ''),
        'email'    => trim($_POST['email']    ?? ''),
        'telefono' => trim($_POST['telefono'] ?? ''),
    ];
    $password  = $_POST['password']  ?? '';
    $password2 = $_POST['password2'] ?? '';

    if (!$datos['nombre'] || !$datos['email'] || !$password) {
        $error = $_reg_en_early ? 'Name, email and password are required.' : 'Nombre, correo y contraseña son obligatorios.';
    } elseif (strlen($password) < 8) {
        $error = $_reg_en_early ? 'Password must be at least 8 characters.' : 'La contraseña debe tener al menos 8 caracteres.';
    } elseif ($password !== $password2) {
        $error = $_reg_en_early ? 'Passwords do not match.' : 'Las contraseñas no coinciden.';
    } else {
        try {
            $pdo = db();
            $chk = $pdo->prepare('SELECT id FROM usuarios WHERE email=? LIMIT 1');
            $chk->execute([$datos['email']]);
            if ($chk->fetch()) {
                $error = $_reg_en_early ? 'This email is already registered.' : 'Este correo ya está registrado.';
            } else {
                $id   = uuid();
                $hash = password_hash($password, PASSWORD_BCRYPT, ['cost'=>12]);
                $pdo->prepare(
                    'INSERT INTO usuarios (id,nombre,email,telefono,rol,password_hash) VALUES(?,?,?,?,?,?)'
                )->execute([$id, $datos['nombre'], $datos['email'], $datos['telefono'], 'usuario', $hash]);
                login_user(['id'=>$id,'nombre'=>$datos['nombre'],'email'=>$datos['email'],'rol'=>'usuario']);
                redirect('index.php');
            }
        } catch (Exception $e) {
            $error = $_reg_en_early ? 'Registration error. Check that MySQL is active.' : 'Error al registrar. Verifica que MySQL esté activo.';
        }
    }
}

// Leer preferencias del usuario para tema e idioma
$_reg_u = session_user();
$_reg_tema = 0;
$_reg_idioma = 'es';
if ($_reg_u) {
    try {
        $pref = db()->prepare('SELECT tema_oscuro, idioma FROM usuarios WHERE id=? LIMIT 1');
        $pref->execute([$_reg_u['id']]);
        $row = $pref->fetch();
        if ($row) { $_reg_tema = (int)$row['tema_oscuro']; $_reg_idioma = $row['idioma']; }
    } catch (Exception $e) {}
}
$_reg_theme = $_reg_tema ? 'dark' : 'light';
$_reg_en = $_reg_idioma === 'en';
?>
<!DOCTYPE html>
<html lang="<?= $_reg_idioma ?>" data-theme="<?= $_reg_theme ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $_reg_en ? "Sign Up — Bookia" : "Registro — Bookia" ?></title>
  <link rel="stylesheet" href="<?= url('css/estilos.css') ?>">
  <link rel="stylesheet" href="<?= url('css/animations.css') ?>">
  <style>
    .navbar { display: none; }
    .auth-page { min-height:100vh; display:grid; grid-template-columns:1fr 1.1fr; overflow:hidden; }

    .auth-panel-izq {
      background: linear-gradient(155deg,#1a0a2e 0%,#2d0a3e 30%,#6B0F2A 65%,#C9822A 100%);
      position:relative; display:flex; flex-direction:column; align-items:center;
      justify-content:center; padding:60px 50px; overflow:hidden; color:#fff;
    }
    .auth-panel-izq::before { content:''; position:absolute; width:400px; height:400px; border-radius:50%; border:1.5px solid rgba(255,255,255,.08); top:-100px; right:-100px; }
    .auth-panel-izq::after  { content:''; position:absolute; width:220px; height:220px; border-radius:50%; background:rgba(255,255,255,.04); bottom:-60px; left:-60px; }
    .auth-deco-circle { position:absolute; width:160px; height:160px; border-radius:50%; border:1px solid rgba(255,255,255,.1); top:55%; left:40%; transform:translate(-50%,-50%); pointer-events:none; }

    .auth-logo-grande { font-size:48px; font-weight:900; letter-spacing:-1px; margin-bottom:8px; z-index:1; text-shadow:0 2px 20px rgba(0,0,0,.3); }
    .auth-logo-grande span { color:#f5c87a; }
    .auth-tagline { font-size:14px; opacity:.85; text-align:center; max-width:280px; line-height:1.6; z-index:1; margin-bottom:36px; }

    .auth-steps { display:flex; flex-direction:column; gap:14px; z-index:1; width:100%; max-width:300px; }
    .auth-step { display:flex; align-items:center; gap:14px; }
    .auth-step-num { width:34px; height:34px; border-radius:50%; background:rgba(255,255,255,.15); border:1.5px solid rgba(255,255,255,.3); display:flex; align-items:center; justify-content:center; font-size:14px; font-weight:800; flex-shrink:0; }
    .auth-step-texto strong { display:block; font-size:13px; font-weight:700; }
    .auth-step-texto small  { font-size:12px; opacity:.75; }
    .auth-step-conector { width:2px; height:16px; background:rgba(255,255,255,.2); margin-left:16px; }

    .auth-libro-deco { position:absolute; font-size:28px; opacity:.12; pointer-events:none; animation:flotar 7s ease-in-out infinite; }
    @keyframes flotar { 0%,100%{transform:translateY(0) rotate(-5deg)} 50%{transform:translateY(-14px) rotate(5deg)} }

    .auth-panel-der { background:#f9fafb; display:flex; flex-direction:column; justify-content:center; padding:48px 60px; overflow-y:auto; }
    .auth-volver { display:inline-flex; align-items:center; gap:6px; font-size:13px; color:var(--color-muted); text-decoration:none; margin-bottom:28px; transition:color .2s; }
    .auth-volver:hover { color:var(--color-primary); }
    .auth-titulo { font-size:26px; font-weight:800; color:#111827; line-height:1.2; margin-bottom:6px; }
    .auth-subtitulo { font-size:13px; color:var(--color-muted); margin-bottom:24px; }

    .form-2col { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
    .form-2col .form-full { grid-column:1/-1; }

    .auth-link-inferior { text-align:center; font-size:13px; color:var(--color-muted); margin-top:20px; }
    .auth-link-inferior a { color:var(--color-primary); font-weight:700; text-decoration:none; }
    .auth-link-inferior a:hover { text-decoration:underline; }

    html[data-theme="dark"] body { background: #0f0f14 !important; }
    html[data-theme="dark"] .auth-panel-der { background: #0f0f14 !important; }
    html[data-theme="dark"] .auth-titulo    { color: #e8e0d0 !important; }
    html[data-theme="dark"] .auth-subtitulo { color: #9ca3af !important; }
    html[data-theme="dark"] .password-strength { background: #2a2a3a !important; }
    html[data-theme="dark"] .metodo-btn     { background: #1a1a24 !important; border-color: #2e2e3e !important; color: #e8e0d0 !important; }
    html[data-theme="dark"] .metodo-btn:has(input:checked) { border-color: #c9456a !important; background: #2d0a1a !important; }
    @media(max-width:800px){ .auth-page{grid-template-columns:1fr} .auth-panel-izq{display:none} .auth-panel-der{padding:40px 24px} }
    @media(max-width:520px){ .form-2col{grid-template-columns:1fr} }
  </style>
</head>
<body>
<div class="auth-page">

  <!-- PANEL IZQUIERDO -->
  <div class="auth-panel-izq">
    <div class="auth-deco-circle"></div>
    <span class="auth-libro-deco" style="top:10%;left:8%;animation-delay:0s">📚</span>
    <span class="auth-libro-deco" style="top:75%;right:8%;animation-delay:2.5s">📖</span>
    <span class="auth-libro-deco" style="bottom:15%;left:15%;animation-delay:1.2s;font-size:20px">📕</span>
    <span class="auth-libro-deco" style="top:40%;right:5%;animation-delay:3.5s;font-size:18px">📗</span>

    <div class="auth-logo-grande">📚 Book<span>ia</span></div>
    <p class="auth-tagline"><?= $_reg_en ? "Join the reading community in Aguascalientes.<br>Reserve, pick up and read again." : "Únete a la comunidad lectora de Aguascalientes.<br>Reserva, recoge y vuelve a leer." ?></p>

    <div class="auth-steps">
      <div class="auth-step">
        <div class="auth-step-num">1</div>
        <div class="auth-step-texto"><strong><?= $_reg_en ? "Create your account" : "Crea tu cuenta" ?></strong><small><?= $_reg_en ? "Free sign-up in 30 seconds" : "Registro gratuito en 30 segundos" ?></small></div>
      </div>
      <div class="auth-step-conector"></div>
      <div class="auth-step">
        <div class="auth-step-num">2</div>
        <div class="auth-step-texto"><strong><?= $_reg_en ? "Browse the catalogue" : "Explora el catálogo" ?></strong><small>+500 <?= $_reg_en ? "titles available" : "títulos disponibles" ?></small></div>
      </div>
      <div class="auth-step-conector"></div>
      <div class="auth-step">
        <div class="auth-step-num">3</div>
        <div class="auth-step-texto"><strong><?= $_reg_en ? "Reserve and pick up" : "Reserva y recoge" ?></strong><small><?= $_reg_en ? "Express pick-up in store" : "Pick-up exprés en tienda" ?></small></div>
      </div>
    </div>
  </div>

  <!-- PANEL DERECHO -->
  <div class="auth-panel-der">
    <a href="<?= url('index.php') ?>" class="auth-volver"><?= $_reg_en ? "← Back to home" : "← Volver al inicio" ?></a>

    <?php if ($error): ?>
      <div class="msg msg-error" style="margin-bottom:16px"><span class="msg-icon">✕</span><div><?= e($error) ?></div></div>
    <?php endif; ?>

    <h1 class="auth-titulo"><?= $_reg_en ? "Create free account ✨" : "Crear cuenta gratis ✨" ?></h1>
    <p class="auth-subtitulo"><?= $_reg_en ? "Complete the form to join Bookia" : "Completa el formulario para unirte a Bookia" ?></p>

    <form method="POST" action="<?= url('registro.php') ?>">
      <?= csrf_field() ?>
      <?= csrf_field() ?>
      <div class="form-2col">

        <div class="form-group">
          <label for="nombre"><?= $_reg_en ? "Full name" : "Nombre completo" ?> <span class="required">*</span></label>
          <div class="input-wrapper"><span class="input-icon">👤</span>
            <input type="text" id="nombre" name="nombre" value="<?= e($datos['nombre']) ?>" placeholder="<?= $_reg_en ? 'Your full name' : 'Tu nombre completo' ?>" autocomplete="name" required autofocus>
          </div>
        </div>

        <div class="form-group">
          <label for="telefono"><?= $_reg_en ? "Phone" : "Teléfono" ?></label>
          <div class="input-wrapper"><span class="input-icon">📱</span>
            <input type="tel" id="telefono" name="telefono" value="<?= e($datos['telefono']) ?>" placeholder="<?= $_reg_en ? '10 digits' : '10 dígitos' ?>" autocomplete="tel">
          </div>
        </div>

        <div class="form-group form-full">
          <label for="email"><?= $_reg_en ? "Email address" : "Correo electrónico" ?> <span class="required">*</span></label>
          <div class="input-wrapper"><span class="input-icon">✉</span>
            <input type="email" id="email" name="email" value="<?= e($datos['email']) ?>" placeholder="tu@correo.com" autocomplete="email" required>
          </div>
        </div>

        <div class="form-group">
          <label for="password"><?= $_reg_en ? "Password" : "Contraseña" ?> <span class="required">*</span></label>
          <div class="input-wrapper"><span class="input-icon">🔒</span>
            <input type="password" id="password" name="password" placeholder="<?= $_reg_en ? 'Minimum 8 characters' : 'Mínimo 8 caracteres' ?>" autocomplete="new-password" minlength="8" required>
          </div>
          <div class="password-strength"><div class="password-strength-bar" id="strength-bar"></div></div>
          <span class="strength-text" id="strength-text"></span>
        </div>

        <div class="form-group">
          <label for="password2"><?= $_reg_en ? "Confirm password" : "Confirmar contraseña" ?> <span class="required">*</span></label>
          <div class="input-wrapper"><span class="input-icon">🔒</span>
            <input type="password" id="password2" name="password2" placeholder="<?= $_reg_en ? 'Repeat your password' : 'Repite tu contraseña' ?>" autocomplete="new-password" required>
          </div>
        </div>

        <div class="checkbox-group form-full">
          <input type="checkbox" id="terms" name="terms" required>
          <label for="terms"><?= $_reg_en ? 'I accept the <a href="#" style="color:var(--color-accent)">terms and conditions</a> and the <a href="#" style="color:var(--color-accent)">privacy policy</a>' : 'Acepto los <a href="#" style="color:var(--color-accent)">términos y condiciones</a> y la <a href="#" style="color:var(--color-accent)">política de privacidad</a>' ?></label>
        </div>

        <div class="form-full">
          <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px;font-size:15px">
            <?= $_reg_en ? "Create Free Account ✨" : "Crear Cuenta Gratis ✨" ?>
          </button>
        </div>
      </div>
    </form>

    <div class="auth-link-inferior"><?= $_reg_en ? 'Already have an account? <a href="' . url('login.php') . '">Log in →</a>' : '¿Ya tienes cuenta? <a href="' . url('login.php') . '">Inicia sesión →</a>' ?></div>
    <p style="text-align:center;margin-top:20px;font-size:11px;color:#9CA3AF">&copy; Bookia 2026 · Angela Guadalupe Ropón Campos</p>
  </div>
</div>

<script src="<?= url('js/animations.js') ?>"></script>
<script>
// Password strength meter
document.getElementById('password')?.addEventListener('input', function() {
  const v = this.value;
  const bar  = document.getElementById('strength-bar');
  const text = document.getElementById('strength-text');
  if (!bar || !text) return;
  let score = 0;
  if (v.length >= 8)           score++;
  if (/[a-z]/.test(v))         score++;
  if (/[A-Z]/.test(v))         score++;
  if (/\d/.test(v))            score++;
  if (/[^a-zA-Z0-9]/.test(v)) score++;
  const levels = [
    {color:'#dc2626',label:'<?= $_reg_en ? "Very weak" : "Muy débil" ?>',pct:'20%'},
    {color:'#f59e0b',label:'<?= $_reg_en ? "Weak" : "Débil" ?>',pct:'40%'},
    {color:'#f59e0b',label:'<?= $_reg_en ? "Fair" : "Regular" ?>',pct:'60%'},
    {color:'#16a34a',label:'<?= $_reg_en ? "Strong" : "Fuerte" ?>',pct:'80%'},
    {color:'#15803d',label:'<?= $_reg_en ? "Very strong" : "Muy fuerte" ?>',pct:'100%'},
  ];
  const l = levels[Math.max(0,score-1)];
  bar.style.width = v ? l.pct : '0%';
  bar.style.backgroundColor = l.color;
  text.textContent = v ? l.label : '';
  text.style.color = l.color;
});
</script>
</body>
</html>
