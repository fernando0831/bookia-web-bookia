<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/session.php';
require_login('login.php');

$u       = session_user();
$idioma  = $u['idioma'] ?? 'es';
$_rv_en  = $idioma === 'en';
$error   = '';
$success = '';
$libros  = [];
$selectedLibro = null;

try {
    $pdo    = db();
    $libros = $pdo->query('SELECT * FROM libros WHERE disponibles > 0 ORDER BY titulo')->fetchAll();
    if (isset($_GET['libro'])) {
        $s = $pdo->prepare('SELECT * FROM libros WHERE id=? AND disponibles>0');
        $s->execute([$_GET['libro']]);
        $selectedLibro = $s->fetch();
    }
} catch (Exception $e) {
    $error = $_rv_en ? 'Database error.' : 'Error de base de datos.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$error) {
    csrf_verify();
    $libroId       = $_POST['libro_id']       ?? '';
    $fechaRecogida = $_POST['fecha_recogida'] ?? '';
    $notas         = trim($_POST['notas']     ?? '');

    if (!$libroId || !$fechaRecogida) {
        $error = $_rv_en ? 'Select a book and a pick-up date.' : 'Selecciona un libro y una fecha de recogida.';
    } elseif (strtotime($fechaRecogida) < strtotime('today')) {
        $error = $_rv_en ? 'The pick-up date cannot be in the past.' : 'La fecha de recogida no puede ser en el pasado.';
    } else {
        try {
            $pdo = db();
            $lb  = $pdo->prepare('SELECT * FROM libros WHERE id=? AND disponibles>0 FOR UPDATE');
            $pdo->beginTransaction();
            $lb->execute([$libroId]);
            $libro = $lb->fetch();
            if (!$libro) {
                $pdo->rollBack();
                $error = $_rv_en ? 'The book is not available.' : 'El libro no está disponible.';
            } else {
                $rid    = uuid();
                $codigo = generarCodigo();
                $pdo->prepare(
                    'INSERT INTO reservas (id,usuario_id,libro_id,titulo_libro,autor_libro,fecha_recogida,estado,notas,codigo_recogida)
                     VALUES(?,?,?,?,?,?,?,?,?)'
                )->execute([$rid, $u['id'], $libroId, $libro['titulo'], $libro['autor'], $fechaRecogida, 'pendiente', $notas, $codigo]);
                $pdo->prepare('UPDATE libros SET disponibles=disponibles-1 WHERE id=?')->execute([$libroId]);
                $pdo->commit();
                $success  = $codigo;
                $libroRes = $libro;
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = $_rv_en ? 'Error processing the reservation.' : 'Error al procesar la reserva.';
        }
    }
}

$pageTitle = 'Reserve a Book — Bookia';
require_once __DIR__ . '/includes/header.php';
$en = $_rv_en; // already defined above
?>

<div class="breadcrumbs">
  <ul>
    <li><a href="<?= url('index.php') ?>"><?= $en ? 'Home' : 'Inicio' ?></a></li>
    <li><span class="current"><?= $en ? 'Reserve a book' : 'Reservar libro' ?></span></li>
  </ul>
</div>

<div class="form-content" style="margin:40px auto;max-width:640px">
  <div class="form-content-header">
    <h2>📌 <?= $en ? 'Reserve a book' : 'Reservar un libro' ?></h2>
    <p><?= $en ? "Hello, {$u['nombre']}. Choose your next read." : "Hola, {$u['nombre']}. Elige tu próxima lectura." ?></p>
  </div>
  <div class="form-content-body">

    <?php if ($success): ?>
      <div class="msg msg-success">
        <span class="msg-icon">✓</span>
        <div>
          <strong><?= $en ? 'Reservation confirmed!' : '¡Reserva confirmada!' ?></strong><br>
          <?= $en ? 'Book' : 'Libro' ?>: <strong><?= e($libroRes['titulo']) ?></strong><br>
          <?= $en ? 'Pick-up code' : 'Código de recogida' ?>: <code style="font-size:18px;font-weight:900;color:#6B0F2A;letter-spacing:2px"><?= e($success) ?></code><br>
          <?= $en ? 'Show this code at the store.' : 'Presenta este código en la librería.' ?>
        </div>
      </div>
      <a href="<?= url('perfil.php') ?>" class="btn" style="display:block;text-align:center;margin-top:12px"><?= $en ? 'View my reservations →' : 'Ver mis reservas →' ?></a>
    <?php else: ?>

      <?php if ($error): ?>
        <div class="msg msg-error"><span class="msg-icon">✕</span><div><?= e($error) ?></div></div>
      <?php endif; ?>

      <form method="POST" action="<?= url('reservar.php') ?>">
        <?= csrf_field() ?>
        <div class="form-group">
          <label for="libro_id"><?= $en ? 'Book' : 'Libro' ?> <span class="required">*</span></label>
          <select id="libro_id" name="libro_id" required>
            <option value=""><?= $en ? '-- Select a book --' : '-- Selecciona un libro --' ?></option>
            <?php foreach ($libros as $l): ?>
              <option value="<?= e($l['id']) ?>"
                <?= ($selectedLibro && $selectedLibro['id']===$l['id']) || ($_POST['libro_id']??'')===$l['id'] ? 'selected' : '' ?>>
                <?= e($l['titulo']) ?> — <?= e($l['autor']) ?> (<?= (int)$l['disponibles'] ?> <?= $en ? 'available' : 'disponibles' ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group">
          <label for="fecha_recogida"><?= $en ? 'Pick-up date' : 'Fecha de recogida' ?> <span class="required">*</span></label>
          <div class="input-wrapper">
            <span class="input-icon">📅</span>
            <input type="date" id="fecha_recogida" name="fecha_recogida"
                   min="<?= date('Y-m-d', strtotime('+1 day')) ?>"
                   value="<?= e($_POST['fecha_recogida'] ?? date('Y-m-d', strtotime('+1 day'))) ?>"
                   required>
          </div>
        </div>

        <div class="form-group">
          <label for="notas"><?= $en ? 'Additional notes (optional)' : 'Notas adicionales (opcional)' ?></label>
          <textarea id="notas" name="notas" rows="3" placeholder="<?= $en ? 'Any special instructions...' : 'Cualquier indicación especial...' ?>"><?= e($_POST['notas'] ?? '') ?></textarea>
        </div>

        <button type="submit" class="btn" style="width:100%;justify-content:center;padding:14px;font-size:16px">
          📌 <?= $en ? 'Confirm reservation' : 'Confirmar reserva' ?>
        </button>
      </form>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
