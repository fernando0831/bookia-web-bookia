<?php
/**
 * BOOKIA — Panel de Seguridad del Usuario
 * Tabs: contraseña | mfa | sesiones | pregunta | preferencias
 */
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/session.php';
require_login('login.php');

$u      = session_user();
$idioma = $u['idioma'] ?? 'es';
$msg    = '';
$tab    = $_GET['tab'] ?? 'password';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    try {
        $pdo = db();

        if ($action === 'cambiar_password') {
            $act  = $_POST['password_actual'] ?? '';
            $new  = $_POST['password_nueva']  ?? '';
            $conf = $_POST['password_conf']   ?? '';
            $s    = $pdo->prepare('SELECT password_hash FROM usuarios WHERE id=? LIMIT 1');
            $s->execute([$u['id']]); $row = $s->fetch();
            if (!password_verify($act, $row['password_hash']))  { $msg = $idioma==='en' ? 'error|Current password is incorrect.' : 'error|Contraseña actual incorrecta.'; }
            elseif (strlen($new) < 8)                           { $msg = $idioma==='en' ? 'error|Minimum 8 characters.' : 'error|Mínimo 8 caracteres.'; }
            elseif ($new !== $conf)                             { $msg = $idioma==='en' ? 'error|Passwords do not match.' : 'error|Las contraseñas no coinciden.'; }
            else {
                $pdo->prepare('UPDATE usuarios SET password_hash=? WHERE id=?')
                    ->execute([password_hash($new, PASSWORD_BCRYPT, ['cost'=>12]), $u['id']]);
                $msg = $idioma==='en' ? 'ok|✅ Password updated successfully.' : 'ok|✅ Contraseña actualizada correctamente.';
            }
            $tab = 'password';
        }

        elseif ($action === 'activar_mfa') {
            $pdo->prepare('UPDATE usuarios SET mfa_activo=1 WHERE id=?')->execute([$u['id']]);
            $msg = $idioma==='en' ? 'ok|✅ MFA enabled. A code will be required at each login.' : 'ok|✅ MFA activado. Se pedirá código en cada login.'; $tab = 'mfa';
        }

        elseif ($action === 'desactivar_mfa') {
            $pass = $_POST['password_confirm'] ?? '';
            $s    = $pdo->prepare('SELECT password_hash FROM usuarios WHERE id=? LIMIT 1');
            $s->execute([$u['id']]); $row = $s->fetch();
            if (!password_verify($pass, $row['password_hash'])) { $msg = $idioma==='en' ? 'error|Incorrect password.' : 'error|Contraseña incorrecta.'; }
            else { $pdo->prepare('UPDATE usuarios SET mfa_activo=0 WHERE id=?')->execute([$u['id']]);
                   $msg = $idioma==='en' ? 'ok|✅ MFA disabled.' : 'ok|✅ MFA desactivado.'; }
            $tab = 'mfa';
        }

        elseif ($action === 'guardar_pregunta') {
            $preg = trim($_POST['pregunta']  ?? '');
            $resp = strtolower(trim($_POST['respuesta'] ?? ''));
            if (!$preg || !$resp) { $msg = $idioma==='en' ? 'error|Question and answer are required.' : 'error|Pregunta y respuesta son obligatorias.'; }
            else {
                $hash = password_hash($resp, PASSWORD_BCRYPT, ['cost'=>10]);
                $pdo->prepare('UPDATE usuarios SET pregunta_secreta=?, respuesta_secreta=? WHERE id=?')
                    ->execute([$preg, $hash, $u['id']]);
                $msg = 'ok|✅ ' . ($idioma==='en'?'Secret question':'Pregunta secreta') . ' guardada (respuesta cifrada con bcrypt).';
            }
            $tab = 'pregunta';
        }

        elseif ($action === 'cerrar_sesion') {
            $sid = $_POST['session_id'] ?? '';
            cerrar_sesion_bd($pdo, $sid, $u['id']);
            $msg = $idioma==='en' ? 'ok|✅ Session closed.' : 'ok|✅ Sesión cerrada.'; $tab = 'sesiones';
        }

        elseif ($action === 'cerrar_otras') {
            cerrar_otras_sesiones($pdo, $u['id']);
            $msg = $idioma==='en' ? 'ok|✅ All other sessions have been closed.' : 'ok|✅ Todas las otras sesiones han sido cerradas.'; $tab = 'sesiones';
        }

        elseif ($action === 'preferencias') {
            $tema   = ($_POST['tema_oscuro'] ?? '0') === '1' ? 1 : 0;
            $idioma = in_array($_POST['idioma'] ?? '', ['es','en']) ? $_POST['idioma'] : 'es';
            $pdo->prepare('UPDATE usuarios SET tema_oscuro=?, idioma=? WHERE id=?')
                ->execute([$tema, $idioma, $u['id']]);
            $_SESSION['bookia_user']['tema_oscuro'] = $tema;
            $_SESSION['bookia_user']['idioma']      = $idioma;
            $msg = 'ok|✅ ' . ($idioma==='en'?'Preferences':'Preferencias') . ' guardadas.'; $tab = 'preferencias';
        }

    } catch (Exception $e) { $msg = 'error|Error: ' . $e->getMessage(); }
}

try {
    $pdo    = db();
    $s      = $pdo->prepare('SELECT * FROM usuarios WHERE id=? LIMIT 1');
    $s->execute([$u['id']]); $perfil = $s->fetch();
    $sesiones = listar_sesiones($pdo, $u['id']);
} catch (Exception $e) { $perfil = []; $sesiones = []; }

[$mt, $mx] = $msg ? explode('|', $msg, 2) : ['',''];
$sid_actual = session_id();
$idioma     = $u['idioma'] ?? 'es';
$pageTitle  = $idioma==='en'?'Security — Bookia':'Seguridad — Bookia';
require_once __DIR__ . '/includes/header.php';
?>
<div class="breadcrumbs"><ul>
  <li><a href="<?= url('index.php') ?>"><?= $idioma==='en'?'Home':'Inicio' ?></a></li>
  <li><a href="<?= url('perfil.php') ?>"><?= $idioma==='en'?'My Profile':'Mi Perfil' ?></a></li>
  <li><span class="current"><?= $idioma==='en'?'Security':'Seguridad' ?></span></li>
</ul></div>

<div class="perfil-grid">
  <aside>
    <div class="perfil-sidebar-card">
      <div class="perfil-avatar-section">
        <div class="perfil-avatar">🔒</div>
        <h3><?= e($u['nombre']) ?></h3>
        <p style="font-size:12px;color:#6B7280"><?= $idioma==='en'?'Account security':'Seguridad de la cuenta' ?></p>
      </div>
      <ul class="perfil-nav">
        <li><a href="?tab=password"     class="<?= $tab==='password'    ?'active':'' ?>">🔑 <?= $idioma==='en'?'Password':'Contraseña' ?></a></li>
        <li><a href="?tab=mfa"          class="<?= $tab==='mfa'         ?'active':'' ?>">📲 MFA</a></li>
        <li><a href="?tab=sesiones"     class="<?= $tab==='sesiones'    ?'active':'' ?>">💻 <?= $idioma==='en'?'Active sessions':'Sesiones activas' ?></a></li>
        <li><a href="?tab=pregunta"     class="<?= $tab==='pregunta'    ?'active':'' ?>">🔐 <?= $idioma==='en'?'Secret question':'Pregunta secreta' ?></a></li>
        <li><a href="?tab=preferencias" class="<?= $tab==='preferencias'?'active':'' ?>">⚙️ <?= $idioma==='en'?'Preferences':'Preferencias' ?></a></li>
        <li><a href="<?= url('perfil.php') ?>">📋 <?= $idioma==='en'?'Back to profile':'Volver al perfil' ?></a></li>
      </ul>
    </div>
  </aside>

  <main>
    <div class="perfil-main-card">
      <?php if ($mx): ?>
        <div class="msg <?= $mt==='ok'?'msg-success':'msg-error' ?>" style="margin:20px 20px 0">
          <span class="msg-icon"><?= $mt==='ok'?'✓':'✕' ?></span><?= e($mx) ?>
        </div>
      <?php endif; ?>

      <?php if ($tab === 'password'): ?>
      <div class="form-content-header" style="border-radius:0"><h2>🔑 <?= $idioma==='en'?'Change password':'Cambiar contraseña' ?></h2><p><?= $idioma==='en'?'Use at least 8 characters.':'Usa al menos 8 caracteres.' ?></p></div>
      <div style="padding:24px;max-width:480px">
        <form method="POST"><?= csrf_field() ?><input type="hidden" name="action" value="cambiar_password">
          <div class="form-group"><label><?= $idioma==='en'?'Current password':'Contraseña actual' ?> <span class="required">*</span></label>
            <div class="input-wrapper"><span class="input-icon">🔒</span>
              <input type="password" name="password_actual" required autocomplete="current-password"></div></div>
          <div class="form-group"><label><?= $idioma==='en'?'New password':'Nueva contraseña' ?> <span class="required">*</span></label>
            <div class="input-wrapper"><span class="input-icon">🔒</span>
              <input type="password" name="password_nueva" minlength="8" required autocomplete="new-password"></div></div>
          <div class="form-group"><label><?= $idioma==='en'?'Confirm new password':'Confirmar nueva contraseña' ?> <span class="required">*</span></label>
            <div class="input-wrapper"><span class="input-icon">🔒</span>
              <input type="password" name="password_conf" minlength="8" required autocomplete="new-password"></div></div>
          <button type="submit" class="btn btn-primary"><?= $idioma==='en'?'Update password':'Actualizar contraseña' ?></button>
        </form>
      </div>

      <?php elseif ($tab === 'mfa'): ?>
      <div class="form-content-header" style="border-radius:0"><h2>📲 <?= $idioma==='en'?'Two-step verification (MFA)':'Verificación en dos pasos (MFA)' ?></h2><p><?= $idioma==='en'?'Protect your account with an OTP code. Choose how to receive it.':'Protege tu cuenta con un código OTP. Elige cómo recibirlo.' ?></p></div>
      <div style="padding:24px;max-width:560px">
        <?php $mfaOn = !empty($perfil['mfa_activo']); ?>

        <!-- Estado MFA -->
        <div style="background:<?= $mfaOn?'#f0fdf4':'#fef9c3' ?>;border:1px solid <?= $mfaOn?'#86efac':'#fde047' ?>;border-radius:12px;padding:16px 20px;margin-bottom:24px;display:flex;align-items:center;gap:14px">
          <span style="font-size:28px"><?= $mfaOn?'✅':'⚠️' ?></span>
          <div>
            <strong style="color:<?= $mfaOn?'#166534':'#713f12' ?>"><?= $mfaOn?($idioma==='en'?'MFA Enabled':'MFA Activado'):($idioma==='en'?'MFA Disabled':'MFA Desactivado') ?></strong>
            <p style="font-size:13px;margin:2px 0 0;color:<?= $mfaOn?'#15803d':'#92400e' ?>"><?= $mfaOn?($idioma==='en'?'Every login requires an OTP code.':'Cada login requiere un código OTP.'):($idioma==='en'?'Only your password protects your account.':'Solo contraseña protege tu cuenta.') ?></p>
          </div>
        </div>

        <?php if (!$mfaOn): ?>
        <form method="POST"><?= csrf_field() ?><input type="hidden" name="action" value="activar_mfa">
          <p style="font-size:13px;color:#374151;margin-bottom:16px"><?= $idioma==='en'?'When you enable MFA, you will receive a 6-digit code when logging in.':'Al activar MFA, recibirás un código de 6 dígitos al iniciar sesión.' ?></p>
          <button type="submit" class="btn btn-primary"><?= $idioma==='en'?'Enable MFA':'Activar MFA' ?></button>
        </form>
        <?php else: ?>
        <form method="POST" style="margin-bottom:32px"><?= csrf_field() ?><input type="hidden" name="action" value="desactivar_mfa">
          <div class="form-group"><label><?= $idioma==='en'?'Confirm your password to disable':'Confirma tu contraseña para desactivar' ?> <span class="required">*</span></label>
            <div class="input-wrapper"><span class="input-icon">🔒</span>
              <input type="password" name="password_confirm" required></div></div>
          <button type="submit" class="btn btn-danger"><?= $idioma==='en'?'Disable MFA':'Desactivar MFA' ?></button>
        </form>
        <?php endif; ?>

        <!-- ══════ DEMO INTERACTIVA ══════ -->
        <div style="border:2px dashed #C19A6B;border-radius:14px;padding:24px;background:#fffaf5">
          <h3 style="margin:0 0 4px;font-size:16px;color:#6B0F2A">🧪 Demo — <?= $idioma==='en'?'Test OTP sending':'Probar envío de OTP' ?></h3>
          <p style="font-size:12px;color:#6B7280;margin:0 0 20px"><?= $idioma==='en'?'Simulates the 3 verification methods. The code appears here (in production it goes to the device).':'Simula los 3 métodos de verificación. El código aparece aquí (en producción llega al dispositivo).' ?></p>

          <!-- Selector de método -->
          <div style="display:flex;gap:10px;margin-bottom:20px;flex-wrap:wrap">
            <button type="button" onclick="mfaSelectMethod('email')" id="btn-email"
              style="flex:1;min-width:120px;padding:12px 8px;border-radius:10px;border:2px solid #6B0F2A;background:#6B0F2A;color:#fff;font-weight:700;cursor:pointer;transition:all .2s;font-size:13px">
              📧 Email
            </button>
            <button type="button" onclick="mfaSelectMethod('sms')" id="btn-sms"
              style="flex:1;min-width:120px;padding:12px 8px;border-radius:10px;border:2px solid #e5e7eb;background:#fff;color:#374151;font-weight:700;cursor:pointer;transition:all .2s;font-size:13px">
              💬 SMS
            </button>
            <button type="button" onclick="mfaSelectMethod('voz')" id="btn-voz"
              style="flex:1;min-width:120px;padding:12px 8px;border-radius:10px;border:2px solid #e5e7eb;background:#fff;color:#374151;font-weight:700;cursor:pointer;transition:all .2s;font-size:13px">
              📞 Llamada
            </button>
          </div>

          <!-- Info del método seleccionado -->
          <div id="mfa-method-info" style="font-size:13px;color:#374151;margin-bottom:16px;padding:10px 14px;background:#f3f4f6;border-radius:8px">
            📧 <?= $idioma==='en'?'A 6-digit code will be sent to':'Se enviará un código de 6 dígitos a' ?> <strong><?= e($perfil['email'] ?? '') ?></strong>
          </div>

          <!-- Botón enviar -->
          <button type="button" id="btn-enviar-otp" onclick="mfaEnviarOTP()"
            style="width:100%;padding:12px;border-radius:10px;border:none;background:#6B0F2A;color:#fff;font-weight:700;font-size:15px;cursor:pointer;margin-bottom:20px;transition:opacity .2s">
            <?= $idioma==='en'?'Send code →':'Enviar código →' ?>
          </button>

          <!-- Resultado simulado (aparece tras envío) -->
          <div id="mfa-result" style="display:none">
            <!-- Notificación simulada -->
            <div id="mfa-notif" style="border-radius:12px;padding:16px 18px;margin-bottom:18px;display:flex;align-items:center;gap:14px"></div>

            <!-- Input de verificación -->
            <div style="margin-bottom:16px">
              <label style="font-size:13px;font-weight:600;display:block;margin-bottom:8px"><?= $idioma==='en'?'Enter the code received:':'Ingresa el código recibido:' ?></label>
              <div style="display:flex;gap:8px">
                <input type="text" id="otp-input" maxlength="6" placeholder="000000"
                  style="flex:1;padding:12px 16px;border:2px solid #e5e7eb;border-radius:10px;font-size:22px;font-weight:900;letter-spacing:8px;text-align:center;font-family:monospace;transition:border .2s">
                <button type="button" onclick="mfaVerificarOTP()"
                  style="padding:12px 20px;border-radius:10px;border:none;background:#15803d;color:#fff;font-weight:700;cursor:pointer;font-size:14px">
                  <?= $idioma==='en'?'Verify ✓':'Verificar ✓' ?>
                </button>
              </div>
            </div>

            <!-- Resultado de verificación -->
            <div id="mfa-verify-result" style="display:none;padding:12px 16px;border-radius:10px;font-size:14px;font-weight:600"></div>

            <!-- Reenviar -->
            <p style="font-size:12px;color:#6B7280;margin-top:12px;text-align:center">
              <?= $idioma==='en'?"Didn't receive the code?":'¿No recibiste el código?' ?> <a href="#" onclick="mfaEnviarOTP();return false" style="color:#6B0F2A;font-weight:600"><?= $idioma==='en'?'Resend →':'Reenviar →' ?></a>
            </p>
          </div>
        </div>
      </div>

      <script>
      let mfaMetodo    = 'email';
      let mfaTel       = '<?= e($perfil['telefono'] ?? 'N/A') ?>';
      let mfaEmail     = '<?= e($perfil['email'] ?? '') ?>';
      let mfaCodigoDemo = '';
      const mfaLang    = '<?= $idioma ?>';
      const t = {
        emailInfo:    mfaLang==='en' ? `📧 A 6-digit code will be sent to <strong>${mfaEmail}</strong>`
                                     : `📧 Se enviará un código de 6 dígitos a <strong>${mfaEmail}</strong>`,
        smsInfo:      mfaLang==='en' ? `💬 An SMS will be sent to <strong>${mfaTel || 'no phone registered'}</strong>`
                                     : `💬 Se enviará un SMS al número <strong>${mfaTel || 'sin teléfono registrado'}</strong>`,
        vozInfo:      mfaLang==='en' ? `📞 You will receive a call at <strong>${mfaTel || 'no phone registered'}</strong> with the dictated code`
                                     : `📞 Recibirás una llamada al número <strong>${mfaTel || 'sin teléfono registrado'}</strong> con el código dictado`,
        sending:      mfaLang==='en' ? 'Sending...'      : 'Enviando...',
        sendBtn:      mfaLang==='en' ? 'Send code →'     : 'Enviar código →',
        digits6:      mfaLang==='en' ? '⚠️ The code must be 6 digits.' : '⚠️ El código debe tener 6 dígitos.',
        correct:      mfaLang==='en' ? '✅ <strong>Correct code!</strong> Verification successful.' : '✅ <strong>¡Código correcto!</strong> Verificación exitosa.',
        wrong:        mfaLang==='en' ? '❌ <strong>Incorrect code.</strong> Try again.'             : '❌ <strong>Código incorrecto.</strong> Intenta de nuevo.',
        emailSent:    mfaLang==='en' ? 'Email sent (simulated)'    : 'Email enviado (simulado)',
        smsSent:      mfaLang==='en' ? 'SMS sent (simulated)'      : 'SMS enviado (simulado)',
        callSim:      mfaLang==='en' ? 'Simulated call'            : 'Llamada simulada',
        verCode:      mfaLang==='en' ? 'Your verification code'    : 'Tu código de verificación',
        expires:      mfaLang==='en' ? 'Expires in 10 minutes'     : 'Expira en 10 minutos',
        codeSentTo:   mfaLang==='en' ? 'Code sent to'              : 'Código enviado a',
        smsSentTo:    mfaLang==='en' ? 'SMS sent to number'        : 'SMS enviado al número',
        callTo:       mfaLang==='en' ? 'Call made to number'       : 'Llamada realizada al número',
        noShare:      mfaLang==='en' ? 'Do not share with anyone.' : 'No lo compartas con nadie.',
        voiceMsg:     mfaLang==='en' ? '🤖 Automated voice from Bookia:' : '🤖 Mensaje de voz de Bookia:',
        voiceText:    mfaLang==='en' ? '"Hello, your Bookia verification code is:'
                                     : '"Hola, tu código de verificación de Bookia es:',
        voiceRepeat:  mfaLang==='en' ? 'I repeat:'                 : 'Repito:',
        voiceExpire:  mfaLang==='en' ? 'This code expires in 10 minutes."' : 'Este código expira en 10 minutos."',
      };

      const metodosInfo = { email: t.emailInfo, sms: t.smsInfo, voz: t.vozInfo };

      function mfaGenerarCodigoDemo() {
        return String(Math.floor(100000 + Math.random() * 900000));
      }

      function mfaSelectMethod(m) {
        mfaMetodo = m;
        ['email','sms','voz'].forEach(k => {
          const b = document.getElementById('btn-'+k);
          if (k === m) {
            b.style.background = '#6B0F2A'; b.style.borderColor = '#6B0F2A'; b.style.color = '#fff';
          } else {
            b.style.background = '#fff'; b.style.borderColor = '#e5e7eb'; b.style.color = '#374151';
          }
        });
        document.getElementById('mfa-method-info').innerHTML = metodosInfo[m];
        document.getElementById('mfa-result').style.display = 'none';
        document.getElementById('mfa-verify-result').style.display = 'none';
      }

      async function mfaEnviarOTP() {
        const btn = document.getElementById('btn-enviar-otp');
        btn.disabled = true; btn.style.opacity = '0.6'; btn.textContent = t.sending;

        await new Promise(r => setTimeout(r, 900 + Math.random() * 400));
        mfaCodigoDemo = mfaGenerarCodigoDemo();

        mostrarNotificacion(mfaMetodo, mfaCodigoDemo);
        document.getElementById('mfa-result').style.display = 'block';
        document.getElementById('otp-input').value = '';
        document.getElementById('mfa-verify-result').style.display = 'none';

        btn.disabled = false; btn.style.opacity = '1'; btn.textContent = t.sendBtn;
      }

      function mostrarNotificacion(metodo, codigo) {
        const notif = document.getElementById('mfa-notif');
        const codigoFormateado = codigo.split('').join(' - ');

        const config = {
          email: {
            icon: '📧', color: '#eff6ff', border: '#93c5fd', titulo: t.emailSent,
            html: `${t.codeSentTo} <strong>${mfaEmail}</strong><br>
                   <div style="margin-top:10px;background:#fff;border-radius:8px;padding:12px 16px;border:1px solid #dbeafe;text-align:center">
                     <div style="font-size:11px;color:#6B7280;margin-bottom:4px">${t.verCode}</div>
                     <div style="font-size:32px;font-weight:900;letter-spacing:8px;color:#6B0F2A;font-family:monospace">${codigo}</div>
                     <div style="font-size:11px;color:#6B7280;margin-top:4px">${t.expires}</div>
                   </div>`
          },
          sms: {
            icon: '💬', color: '#f0fdf4', border: '#86efac', titulo: t.smsSent,
            html: `${t.smsSentTo} <strong>${mfaTel}</strong><br>
                   <div style="margin-top:10px;background:#fff;border-radius:12px;padding:12px 16px;border:1px solid #d1fae5;max-width:260px">
                     <div style="font-size:11px;color:#6B7280;margin-bottom:6px">📱 Bookia · ${mfaLang==='en'?'Now':'Ahora'}</div>
                     <div style="background:#dcfce7;border-radius:10px 10px 0 10px;padding:10px 14px;font-size:13px;color:#14532d">
                       ${mfaLang==='en'?'Your Bookia code:':'Tu código Bookia:'} <strong style="font-size:18px;letter-spacing:4px">${codigo}</strong><br>
                       <span style="font-size:11px;color:#166534">${t.noShare}</span>
                     </div>
                   </div>`
          },
          voz: {
            icon: '📞', color: '#fdf4ff', border: '#d8b4fe', titulo: t.callSim,
            html: `${t.callTo} <strong>${mfaTel}</strong><br>
                   <div style="margin-top:10px;background:#fff;border-radius:12px;padding:14px 16px;border:1px solid #e9d5ff">
                     <div style="font-size:11px;color:#6B7280;margin-bottom:8px">${t.voiceMsg}</div>
                     <div style="font-style:italic;color:#6B21A8;font-size:14px;line-height:1.6">
                       ${t.voiceText}<br>
                       <strong style="font-size:20px;letter-spacing:4px;font-style:normal">${codigoFormateado}</strong><br>
                       ${t.voiceRepeat} <strong style="letter-spacing:4px">${codigoFormateado}</strong>.<br>
                       ${t.voiceExpire}
                     </div>
                   </div>`
          }
        };

        const c = config[metodo];
        notif.style.background = c.color;
        notif.style.border = `1.5px solid ${c.border}`;
        notif.innerHTML = `
          <span style="font-size:28px">${c.icon}</span>
          <div>
            <strong style="font-size:14px">${c.titulo}</strong><br>
            <div style="font-size:13px;margin-top:6px;color:#374151">${c.html}</div>
          </div>`;
      }

      function mfaVerificarOTP() {
        const codigo  = document.getElementById('otp-input').value.trim();
        const res_div = document.getElementById('mfa-verify-result');

        if (codigo.length !== 6) {
          res_div.style.display = 'block';
          res_div.style.background = '#fef2f2'; res_div.style.color = '#991b1b';
          res_div.textContent = t.digits6; return;
        }

        if (codigo === mfaCodigoDemo) {
          res_div.style.display = 'block';
          res_div.style.background = '#f0fdf4'; res_div.style.color = '#166534';
          res_div.innerHTML = t.correct;
          document.getElementById('otp-input').style.borderColor = '#86efac';
        } else {
          res_div.style.display = 'block';
          res_div.style.background = '#fef2f2'; res_div.style.color = '#991b1b';
          res_div.innerHTML = t.wrong;
          document.getElementById('otp-input').style.borderColor = '#fca5a5';
        }
      }

      document.addEventListener('DOMContentLoaded', () => {
        const inp = document.getElementById('otp-input');
        if (inp) {
          inp.addEventListener('keydown', e => { if (e.key === 'Enter') mfaVerificarOTP(); });
          inp.addEventListener('input',   () => { inp.style.borderColor = '#e5e7eb'; });
        }
      });
      </script>

      <?php elseif ($tab === 'sesiones'): ?>
      <div class="form-content-header" style="border-radius:0">
        <h2>💻 <?= $idioma==='en'?'Active sessions':'Sesiones activas' ?></h2><p><?= count($sesiones) ?> <?= $idioma==='en'?'active session':'sesión activa' ?><?= count($sesiones)!==1?'s':'' ?>.</p>
      </div>
      <div style="padding:24px">
        <?php if (count($sesiones) > 1): ?>
        <form method="POST" style="margin-bottom:20px" onsubmit="return confirm('<?= $idioma==='en'?'Close all other sessions?':'¿Cerrar todas las otras sesiones?' ?>')">
          <?= csrf_field() ?><input type="hidden" name="action" value="cerrar_otras">
          <button type="submit" class="btn btn-danger btn-sm">🚫 <?= $idioma==='en'?'Close all other sessions':'Cerrar todas las otras sesiones' ?></button>
        </form>
        <?php endif; ?>
        <?php foreach ($sesiones as $ses):
          $esActual = ($ses['id'] === $sid_actual);
          $ua = $ses['user_agent'];
          $icon = (stripos($ua,'mobile')!==false || stripos($ua,'android')!==false) ? '📱' : '💻';
        ?>
        <div style="display:flex;align-items:center;gap:16px;padding:16px;border:1.5px solid <?= $esActual?'#6B0F2A':'#e5e7eb' ?>;border-radius:12px;margin-bottom:10px;background:<?= $esActual?'#fdf2f4':'#fff' ?>">
          <span style="font-size:28px"><?= $icon ?></span>
          <div style="flex:1;min-width:0">
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
              <strong style="font-size:13px"><?= $esActual?($idioma==='en'?'✅ This session':'✅ Esta sesión'):($idioma==='en'?'Another session':'Otra sesión') ?></strong>
              <?php if ($esActual): ?><span class="pill pill-green" style="font-size:11px"><?= $idioma==='en'?'Current':'Actual' ?></span><?php endif; ?>
            </div>
            <div style="font-size:12px;color:#6B7280;margin-top:3px">
              IP: <code><?= e($ses['ip']?:($idioma==='en'?'Unknown':'Desconocida')) ?></code> &bull;
              <?= $idioma==='en'?'Last access':'Último acceso' ?>: <?= e(date('d/m/Y H:i', strtotime($ses['last_active']))) ?><br>
              <span style="word-break:break-all"><?= e(mb_substr($ua?:($idioma==='en'?'Unknown agent':'Agente desconocido'),0,100)) ?></span>
            </div>
          </div>
          <?php if (!$esActual): ?>
          <form method="POST" onsubmit="return confirm('<?= $idioma==='en'?'Close this session?':'¿Cerrar esta sesión?' ?>')">
            <?= csrf_field() ?><input type="hidden" name="action" value="cerrar_sesion">
            <input type="hidden" name="session_id" value="<?= e($ses['id']) ?>">
            <button type="submit" class="btn btn-danger btn-sm"><?= $idioma==='en'?'Close':'Cerrar' ?></button>
          </form>
          <?php endif; ?>
        </div>
        <?php endforeach; ?>
        <?php if (empty($sesiones)): ?>
          <div class="empty-state"><div class="empty-icon">💻</div><h4><?= $idioma==='en'?'No sessions registered':'Sin sesiones registradas' ?></h4></div>
        <?php endif; ?>
      </div>

      <?php elseif ($tab === 'pregunta'): ?>
      <div class="form-content-header" style="border-radius:0"><h2>🔐 <?= $idioma==='en'?'Secret question':'Pregunta secreta' ?></h2><p><?= $idioma==='en'?'Alternative password recovery method. The answer is stored encrypted.':'Método alternativo de recuperación de contraseña. La respuesta se guarda cifrada.' ?></p></div>
      <div style="padding:24px;max-width:520px">

        <?php if (!empty($perfil['pregunta_secreta'])): ?>
          <div style="background:#f0fdf4;border:1.5px solid #86efac;border-radius:12px;padding:14px 18px;margin-bottom:24px;display:flex;align-items:center;gap:12px">
            <span style="font-size:24px">✅</span>
            <div>
              <strong style="color:#166534;font-size:13px"><?= $idioma==='en'?'Question configured':'Pregunta configurada' ?></strong>
              <p style="margin:2px 0 0;font-size:13px;color:#374151"><?= e($perfil['pregunta_secreta']) ?></p>
            </div>
          </div>
        <?php endif; ?>

        <form method="POST" id="form-pregunta"><?= csrf_field() ?><input type="hidden" name="action" value="guardar_pregunta">

          <!-- Modo selector -->
          <div style="display:flex;gap:10px;margin-bottom:18px">
            <button type="button" onclick="preguntaSetModo('lista')" id="btn-modo-lista"
              style="flex:1;padding:9px;border-radius:8px;border:2px solid #6B0F2A;background:#6B0F2A;color:#fff;font-weight:700;cursor:pointer;font-size:13px">
              📋 <?= $idioma==='en'?'Choose from list':'Elegir de lista' ?>
            </button>
            <button type="button" onclick="preguntaSetModo('propia')" id="btn-modo-propia"
              style="flex:1;padding:9px;border-radius:8px;border:2px solid #e5e7eb;background:#fff;color:#374151;font-weight:700;cursor:pointer;font-size:13px">
              ✏️ <?= $idioma==='en'?'Write my own':'Escribir la mía' ?>
            </button>
          </div>

          <!-- Modo lista -->
          <div id="modo-lista">
            <div class="form-group">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
                <label style="margin:0"><?= $idioma==='en'?'Secret question':'Pregunta secreta' ?> <span class="required">*</span></label>
                <button type="button" onclick="preguntaSugerir()" title="<?= $idioma==='en'?'Suggest random question':'Sugerir pregunta aleatoria' ?>"
                  style="background:#f3f4f6;border:1px solid #e5e7eb;border-radius:6px;padding:4px 10px;font-size:12px;cursor:pointer;color:#374151;font-weight:600">
                  🎲 <?= $idioma==='en'?'Suggest':'Sugerir' ?>
                </button>
              </div>
              <select id="select-pregunta" name="pregunta"
                style="width:100%;padding:10px 12px;border:1.5px solid #e5e7eb;border-radius:8px;font-size:14px;transition:border .2s"
                onchange="preguntaDesdeSelect(this.value)">
                <option value="">-- Elige una pregunta --</option>
                <optgroup label="🐾 Infancia y mascotas">
                  <option <?= ($perfil['pregunta_secreta']??'')==='¿Cuál es el nombre de tu primera mascota?'?'selected':'' ?>>¿Cuál es el nombre de tu primera mascota?</option>
                  <option <?= ($perfil['pregunta_secreta']??'')==='¿Cuál fue el nombre de tu mejor amigo/a de infancia?'?'selected':'' ?>>¿Cuál fue el nombre de tu mejor amigo/a de infancia?</option>
                  <option <?= ($perfil['pregunta_secreta']??'')==='¿Cuál fue tu juguete favorito de niño/a?'?'selected':'' ?>>¿Cuál fue tu juguete favorito de niño/a?</option>
                </optgroup>
                <optgroup label="📍 Lugares">
                  <option <?= ($perfil['pregunta_secreta']??'')==='¿En qué ciudad naciste?'?'selected':'' ?>>¿En qué ciudad naciste?</option>
                  <option <?= ($perfil['pregunta_secreta']??'')==='¿Cuál es el nombre de tu calle de infancia?'?'selected':'' ?>>¿Cuál es el nombre de tu calle de infancia?</option>
                  <option <?= ($perfil['pregunta_secreta']??'')==='¿En qué ciudad se conocieron tus padres?'?'selected':'' ?>>¿En qué ciudad se conocieron tus padres?</option>
                </optgroup>
                <optgroup label="🎓 Escuela y trabajo">
                  <option <?= ($perfil['pregunta_secreta']??'')==='¿Cuál es el nombre de tu escuela primaria?'?'selected':'' ?>>¿Cuál es el nombre de tu escuela primaria?</option>
                  <option <?= ($perfil['pregunta_secreta']??'')==='¿Cuál fue tu primer trabajo?'?'selected':'' ?>>¿Cuál fue tu primer trabajo?</option>
                  <option <?= ($perfil['pregunta_secreta']??'')==='¿Cuál es el nombre de tu maestro/a favorito/a?'?'selected':'' ?>>¿Cuál es el nombre de tu maestro/a favorito/a?</option>
                </optgroup>
                <optgroup label="👨‍👩‍👧 Familia">
                  <option <?= ($perfil['pregunta_secreta']??'')==='¿Cuál es el apellido de soltera de tu madre?'?'selected':'' ?>>¿Cuál es el apellido de soltera de tu madre?</option>
                  <option <?= ($perfil['pregunta_secreta']??'')==='¿Cuál es el segundo nombre de tu padre?'?'selected':'' ?>>¿Cuál es el segundo nombre de tu padre?</option>
                  <option <?= ($perfil['pregunta_secreta']??'')==='¿Cómo se llama tu hermano/a mayor?'?'selected':'' ?>>¿Cómo se llama tu hermano/a mayor?</option>
                </optgroup>
                <optgroup label="❤️ Favoritos">
                  <option <?= ($perfil['pregunta_secreta']??'')==='¿Cuál es tu libro favorito?'?'selected':'' ?>>¿Cuál es tu libro favorito?</option>
                  <option <?= ($perfil['pregunta_secreta']??'')==='¿Cuál es tu película favorita?'?'selected':'' ?>>¿Cuál es tu película favorita?</option>
                  <option <?= ($perfil['pregunta_secreta']??'')==='¿Cuál fue el primer concierto al que asististe?'?'selected':'' ?>>¿Cuál fue el primer concierto al que asististe?</option>
                </optgroup>
              </select>
            </div>

            <!-- Vista previa de la pregunta sugerida -->
            <div id="pregunta-preview" style="display:none;background:#fffaf5;border:1.5px solid #C19A6B;border-radius:10px;padding:12px 16px;margin-bottom:16px;font-size:13px;color:#374151">
              <strong style="color:#6B0F2A">💡 <?= $idioma==='en'?'Suggested question:':'Pregunta sugerida:' ?></strong>
              <p id="pregunta-preview-text" style="margin:4px 0 0;font-size:14px"></p>
              <button type="button" onclick="preguntaAceptarSugerida()"
                style="margin-top:8px;padding:4px 12px;border-radius:6px;border:1.5px solid #6B0F2A;background:#fff;color:#6B0F2A;font-weight:600;cursor:pointer;font-size:12px">
                <?= $idioma==='en'?'Use this question ✓':'Usar esta pregunta ✓' ?>
              </button>
            </div>
          </div>

          <!-- Modo pregunta propia -->
          <div id="modo-propia" style="display:none">
            <div class="form-group">
              <label><?= $idioma==='en'?'Write your own question':'Escribe tu propia pregunta' ?> <span class="required">*</span></label>
              <div class="input-wrapper"><span class="input-icon">✏️</span>
                <input type="text" id="input-pregunta-propia" placeholder="<?= $idioma==='en'?'E.g.: What is the name of my favorite book?':'Ej: ¿Cuál es el nombre de mi libro favorito?' ?>"
                  maxlength="150"
                  style="padding-left:40px"
                  oninput="document.getElementById('char-count').textContent=this.value.length"></div>
              <small style="color:#6B7280;font-size:12px;display:flex;justify-content:space-between">
                <span><?= $idioma==='en'?'Use something only you know.':'Usa algo que solo tú sepas responder.' ?></span>
                <span><span id="char-count">0</span>/150</span>
              </small>
            </div>
          </div>

          <!-- Campo oculto que recibe la pregunta final -->
          <input type="hidden" id="pregunta-final" name="pregunta" value="<?= e($perfil['pregunta_secreta'] ?? '') ?>">

          <div class="form-group">
            <label><?= $idioma==='en'?'Your answer':'Tu respuesta' ?> <span class="required">*</span></label>
            <div class="input-wrapper"><span class="input-icon">💬</span>
              <input type="text" name="respuesta" id="input-respuesta"
                placeholder="<?= $idioma==='en'?'Not case-sensitive':'No distingue mayúsculas' ?>" required autocomplete="off"></div>
            <small style="color:#6B7280;font-size:12px"><?= $idioma==='en'?'Stored encrypted with bcrypt. Never in plain text.':'Se guarda cifrada con bcrypt. Nunca en texto plano.' ?></small>
          </div>

          <div style="display:flex;gap:10px;flex-wrap:wrap">
            <button type="button" onclick="preguntaSubmit()"
              style="padding:11px 24px;border-radius:8px;border:none;background:#6B0F2A;color:#fff;font-weight:700;cursor:pointer;font-size:14px">
              <?= $idioma==='en'?'Save secret question':'Guardar pregunta secreta' ?>
            </button>
          </div>

          <!-- Error inline -->
          <div id="pregunta-error" style="display:none;margin-top:12px;padding:10px 14px;background:#fef2f2;border-radius:8px;color:#991b1b;font-size:13px"></div>
        </form>

        <script>
        let preguntaModo = 'lista';
        const preguntasSugeridas = [
          '¿Cuál es el nombre de tu primera mascota?',
          '¿En qué ciudad naciste?',
          '¿Cuál es el nombre de tu escuela primaria?',
          '¿Cuál es el apellido de soltera de tu madre?',
          '¿Cuál fue tu primer trabajo?',
          '¿Cuál fue el nombre de tu mejor amigo/a de infancia?',
          '¿Cuál fue tu juguete favorito de niño/a?',
          '¿Cuál es el nombre de tu calle de infancia?',
          '¿En qué ciudad se conocieron tus padres?',
          '¿Cuál es el nombre de tu maestro/a favorito/a?',
          '¿Cuál es el segundo nombre de tu padre?',
          '¿Cómo se llama tu hermano/a mayor?',
          '¿Cuál es tu libro favorito?',
          '¿Cuál es tu película favorita?',
          '¿Cuál fue el primer concierto al que asististe?',
        ];

        function preguntaSetModo(modo) {
          preguntaModo = modo;
          document.getElementById('modo-lista').style.display  = modo === 'lista'  ? 'block' : 'none';
          document.getElementById('modo-propia').style.display = modo === 'propia' ? 'block' : 'none';
          const btnLista  = document.getElementById('btn-modo-lista');
          const btnPropia = document.getElementById('btn-modo-propia');
          if (modo === 'lista') {
            btnLista.style.background = '#6B0F2A'; btnLista.style.borderColor = '#6B0F2A'; btnLista.style.color = '#fff';
            btnPropia.style.background = '#fff'; btnPropia.style.borderColor = '#e5e7eb'; btnPropia.style.color = '#374151';
          } else {
            btnPropia.style.background = '#6B0F2A'; btnPropia.style.borderColor = '#6B0F2A'; btnPropia.style.color = '#fff';
            btnLista.style.background = '#fff'; btnLista.style.borderColor = '#e5e7eb'; btnLista.style.color = '#374151';
          }
          document.getElementById('pregunta-error').style.display = 'none';
        }

        function preguntaSugerir() {
          const idx  = Math.floor(Math.random() * preguntasSugeridas.length);
          const preg = preguntasSugeridas[idx];
          document.getElementById('pregunta-preview-text').textContent = preg;
          document.getElementById('pregunta-preview').style.display = 'block';
          document.getElementById('select-pregunta').style.borderColor = '#C19A6B';
        }

        function preguntaAceptarSugerida() {
          const texto = document.getElementById('pregunta-preview-text').textContent;
          const sel   = document.getElementById('select-pregunta');
          // Buscar si ya existe en el select
          let encontrado = false;
          for (let opt of sel.options) {
            if (opt.text === texto) { sel.value = texto; encontrado = true; break; }
          }
          if (!encontrado) {
            const opt = new Option(texto, texto, true, true);
            sel.add(opt);
          }
          document.getElementById('pregunta-final').value = texto;
          document.getElementById('pregunta-preview').style.display = 'none';
          sel.style.borderColor = '#86efac';
        }

        function preguntaDesdeSelect(val) {
          document.getElementById('pregunta-final').value = val;
          document.getElementById('select-pregunta').style.borderColor = val ? '#86efac' : '#e5e7eb';
        }

        function preguntaSubmit() {
          const err  = document.getElementById('pregunta-error');
          const resp = document.getElementById('input-respuesta').value.trim();
          let preg   = '';
          const lang = '<?= $idioma ?>';

          if (preguntaModo === 'lista') {
            preg = document.getElementById('pregunta-final').value.trim();
            if (!preg) {
              err.style.display = 'block';
              err.textContent   = lang==='en' ? '⚠️ You must choose a question from the list or use "Suggest".' : '⚠️ Debes elegir una pregunta de la lista o usar "Sugerir".';
              return;
            }
          } else {
            preg = document.getElementById('input-pregunta-propia').value.trim();
            if (preg.length < 10) {
              err.style.display = 'block';
              err.textContent   = lang==='en' ? '⚠️ The question must be at least 10 characters.' : '⚠️ La pregunta debe tener al menos 10 caracteres.';
              return;
            }
            document.getElementById('pregunta-final').value = preg;
          }

          if (!resp) {
            err.style.display = 'block';
            err.textContent   = lang==='en' ? '⚠️ You must write an answer.' : '⚠️ Debes escribir una respuesta.';
            return;
          }

          err.style.display = 'none';
          document.getElementById('form-pregunta').submit();
        }

        // Init: si ya hay pregunta configurada, marcar en el select
        (function() {
          const configurada = <?= json_encode($perfil['pregunta_secreta'] ?? '') ?>;
          if (configurada) {
            document.getElementById('pregunta-final').value = configurada;
          }
        })();
        </script>
      </div>

      <?php elseif ($tab === 'preferencias'): ?>
      <div class="form-content-header" style="border-radius:0">
        <h2>⚙️ <?= $idioma==='en'?'Preferences':'Preferencias' ?></h2>
        <p><?= $idioma==='en'?'Customize your experience':'Personaliza tu experiencia' ?></p>
      </div>
      <div style="padding:28px 32px;max-width:660px">
        <form method="POST">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="preferencias">

          <!-- Apariencia -->
          <div style="margin-bottom:24px">
            <h3 style="font-size:14px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#9CA3AF;margin-bottom:14px">
              🎨 <?= $idioma==='en'?'Appearance':'Apariencia' ?>
            </h3>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">

              <label style="cursor:pointer">
                <input type="radio" name="tema_oscuro" value="0" <?= empty($perfil['tema_oscuro'])?'checked':'' ?> style="display:none" class="pref-radio-seg">
                <div class="pref-card-seg" style="border:2px solid <?= empty($perfil['tema_oscuro'])?'#6B0F2A':'#e5e7eb' ?>;border-radius:12px;padding:20px;text-align:center;transition:all .2s;<?= empty($perfil['tema_oscuro'])?'box-shadow:0 0 0 3px rgba(107,15,42,0.12)':'' ?>">
                  <div style="font-size:30px;margin-bottom:8px">☀️</div>
                  <div style="font-weight:700;font-size:14px;margin-bottom:3px"><?= $idioma==='en'?'Light mode':'Modo claro' ?></div>
                  <div style="font-size:12px;color:#9CA3AF"><?= $idioma==='en'?'Bright & clean':'Claro y limpio' ?></div>
                </div>
              </label>

              <label style="cursor:pointer">
                <input type="radio" name="tema_oscuro" value="1" <?= !empty($perfil['tema_oscuro'])?'checked':'' ?> style="display:none" class="pref-radio-seg">
                <div class="pref-card-seg" style="border:2px solid <?= !empty($perfil['tema_oscuro'])?'#6B0F2A':'#e5e7eb' ?>;border-radius:12px;padding:20px;text-align:center;transition:all .2s;<?= !empty($perfil['tema_oscuro'])?'box-shadow:0 0 0 3px rgba(107,15,42,0.12)':'' ?>">
                  <div style="font-size:30px;margin-bottom:8px">🌙</div>
                  <div style="font-weight:700;font-size:14px;margin-bottom:3px"><?= $idioma==='en'?'Dark mode':'Modo oscuro' ?></div>
                  <div style="font-size:12px;color:#9CA3AF"><?= $idioma==='en'?'Easy on the eyes':'Reduce fatiga visual' ?></div>
                </div>
              </label>

            </div>
          </div>

          <!-- Idioma -->
          <div style="margin-bottom:28px">
            <h3 style="font-size:14px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#9CA3AF;margin-bottom:14px">
              🌐 <?= $idioma==='en'?'Language':'Idioma' ?>
            </h3>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">

              <label style="cursor:pointer">
                <input type="radio" name="idioma" value="es" <?= ($perfil['idioma']??'es')==='es'?'checked':'' ?> style="display:none" class="pref-radio-seg">
                <div class="pref-card-seg" style="border:2px solid <?= ($perfil['idioma']??'es')==='es'?'#6B0F2A':'#e5e7eb' ?>;border-radius:12px;padding:20px;text-align:center;transition:all .2s;<?= ($perfil['idioma']??'es')==='es'?'box-shadow:0 0 0 3px rgba(107,15,42,0.12)':'' ?>">
                  <div style="font-size:30px;margin-bottom:8px">🇲🇽</div>
                  <div style="font-weight:700;font-size:14px;margin-bottom:3px">Español</div>
                  <div style="font-size:12px;color:#9CA3AF">Interfaz en español</div>
                </div>
              </label>

              <label style="cursor:pointer">
                <input type="radio" name="idioma" value="en" <?= ($perfil['idioma']??'es')==='en'?'checked':'' ?> style="display:none" class="pref-radio-seg">
                <div class="pref-card-seg" style="border:2px solid <?= ($perfil['idioma']??'es')==='en'?'#6B0F2A':'#e5e7eb' ?>;border-radius:12px;padding:20px;text-align:center;transition:all .2s;<?= ($perfil['idioma']??'es')==='en'?'box-shadow:0 0 0 3px rgba(107,15,42,0.12)':'' ?>">
                  <div style="font-size:30px;margin-bottom:8px">🇺🇸</div>
                  <div style="font-weight:700;font-size:14px;margin-bottom:3px">English</div>
                  <div style="font-size:12px;color:#9CA3AF">Interface in English</div>
                </div>
              </label>

            </div>
          </div>

          <button type="submit" class="btn" style="padding:12px 36px;font-size:15px;font-weight:700">
            💾 <?= $idioma==='en'?'Save preferences':'Guardar preferencias' ?>
          </button>
        </form>

        <script>
        (function(){
          document.querySelectorAll('.pref-radio-seg').forEach(function(radio){
            radio.addEventListener('change', function(){
              var name = this.name;
              document.querySelectorAll('input[name="'+name+'"]').forEach(function(r){
                var card = r.closest('label').querySelector('.pref-card-seg');
                card.style.border = '2px solid #e5e7eb';
                card.style.boxShadow = '';
              });
              var sel = this.closest('label').querySelector('.pref-card-seg');
              sel.style.border = '2px solid #6B0F2A';
              sel.style.boxShadow = '0 0 0 3px rgba(107,15,42,0.12)';
            });
          });
        })();
        </script>
      </div>
      <?php endif; ?>

    </div>
  </main>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
