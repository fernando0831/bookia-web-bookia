<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/session.php';
$pageTitle = 'Services — Bookia';
require_once __DIR__ . '/includes/header.php';
$en = $idioma === 'en';
?>
<div class="breadcrumbs"><ul>
  <li><a href="<?= url('index.php') ?>"><?= $en ? 'Home' : 'Inicio' ?></a></li>
  <li><span class="current"><?= $en ? 'Services' : 'Servicios' ?></span></li>
</ul></div>
<section class="content">
  <h2><?= $en ? 'Our Services' : 'Nuestros Servicios' ?></h2>
  <div class="servicios-grid" style="margin-top:24px">
    <div class="servicio-card">
      <div class="servicio-icon">📌</div>
      <h3><?= $en ? 'Online reservation' : 'Reserva en línea' ?></h3>
      <p><?= $en ? 'Choose your book from our platform and reserve it with one click. Available 24 hours a day.' : 'Elige tu libro desde nuestra plataforma y resérvalo con solo un clic. Disponible las 24 horas.' ?></p>
    </div>
    <div class="servicio-card">
      <div class="servicio-icon">🏪</div>
      <h3>Pick Up Express</h3>
      <p><?= $en ? 'Pick up your book at our branch in less than 2 hours after confirming your reservation.' : 'Recoge tu libro en nuestra sucursal en menos de 2 horas después de confirmar tu reserva.' ?></p>
    </div>
    <div class="servicio-card">
      <div class="servicio-icon">📚</div>
      <h3><?= $en ? 'Wide catalogue' : 'Catálogo amplio' ?></h3>
      <p><?= $en ? 'More than 48 titles in 8 genres: fiction, romance, sci-fi, children and more.' : 'Más de 48 títulos en 8 géneros: ficción, romance, ciencia ficción, infantil y más.' ?></p>
    </div>
    <div class="servicio-card">
      <div class="servicio-icon">🔔</div>
      <h3><?= $en ? 'Notifications' : 'Notificaciones' ?></h3>
      <p><?= $en ? 'We notify you when your book is ready with a unique pick-up code.' : 'Te avisamos cuando tu libro esté listo para recoger con un código único de recogida.' ?></p>
    </div>
    <div class="servicio-card">
      <div class="servicio-icon">↩</div>
      <h3><?= $en ? 'Returns' : 'Devoluciones' ?></h3>
      <p><?= $en ? 'Simple return process. Cancel your pending reservation from your profile at any time.' : 'Proceso sencillo de devolución. Cancela tu reserva pendiente desde tu perfil en cualquier momento.' ?></p>
    </div>
    <div class="servicio-card">
      <div class="servicio-icon">🎁</div>
      <h3><?= $en ? 'Book clubs' : 'Clubes de lectura' ?></h3>
      <p><?= $en ? 'Join our monthly clubs and share your passion for reading with other readers.' : 'Únete a nuestros clubes mensuales y comparte tu pasión por la lectura con otros lectores.' ?></p>
    </div>
  </div>
  <div style="text-align:center;margin-top:32px">
    <a href="<?= url('reservar.php') ?>" class="btn">📌 <?= $en ? 'Reserve now →' : 'Reservar ahora →' ?></a>
  </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
