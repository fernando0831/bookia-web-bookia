<?php
/**
 * BOOKIA — SSO App B (Single Sign-On simulado)
 * App A = Bookia → genera JWT SSO de 60s
 * App B = esta página → valida el token sin BD
 */
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/session.php';

$token   = $_GET['token'] ?? '';
$error   = '';
$usuario = null;

if ($token) {
    $payload = validar_token_sso($token);
    if ($payload) { $usuario = $payload; $_SESSION['sso_appb'] = $payload; }
    else           { $error  = 'Token SSO inválido o expirado (60s). Regresa a Bookia.'; }
} elseif (!empty($_SESSION['sso_appb'])) {
    $usuario = $_SESSION['sso_appb'];
}

// Si el usuario está logueado en App A, generar token para App B
$tokenSso = '';
if (is_logged_in() && !$token) {
    $tokenSso = generar_token_sso(session_user());
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>App B — SSO Demo · Bookia</title>
  <link rel="stylesheet" href="<?= url('css/estilos.css') ?>">
  <style>
    body{background:linear-gradient(135deg,#0f172a,#1e293b);min-height:100vh;display:flex;align-items:center;justify-content:center}
    .card{background:#fff;border-radius:20px;padding:48px 56px;max-width:520px;width:100%;box-shadow:0 25px 60px rgba(0,0,0,.35);text-align:center}
    .badge{display:inline-flex;align-items:center;gap:8px;background:#EFF6FF;border:1px solid #BFDBFE;border-radius:999px;padding:6px 16px;font-size:12px;color:#1D4ED8;font-weight:700;text-transform:uppercase;margin-bottom:28px}
    .flow{display:flex;align-items:center;justify-content:center;gap:6px;flex-wrap:wrap;margin:24px 0}
    .node{background:#f8fafc;border:1.5px solid #e2e8f0;border-radius:10px;padding:10px 16px;font-size:12px;font-weight:700;color:#374151}
    .node.active{background:#6B0F2A;color:#fff;border-color:#6B0F2A}
    .arrow{color:#9CA3AF;font-size:18px}
  </style>
</head>
<body>
<div class="card">
  <div class="badge">🔗 Single Sign-On Demo</div>
  <div style="font-size:52px;margin-bottom:12px">🗂️</div>

  <?php if ($error): ?>
    <h2 style="font-size:22px;font-weight:900;color:#dc2626;margin-bottom:8px">Token Expirado ⚠️</h2>
    <p style="font-size:14px;color:#6B7280;margin-bottom:24px"><?= e($error) ?></p>
    <a href="<?= url('index.php') ?>" class="btn btn-primary">← Volver a Bookia</a>

  <?php elseif ($usuario): ?>
    <h2 style="font-size:22px;font-weight:900;color:#111827;margin-bottom:6px">¡Bienvenido a App B! ✅</h2>
    <p style="font-size:14px;color:#6B7280;margin-bottom:20px">Accediste sin volver a iniciar sesión.</p>
    <div style="background:linear-gradient(135deg,rgba(107,15,42,.06),rgba(201,130,42,.08));border:1px solid rgba(107,15,42,.2);border-radius:14px;padding:20px 24px;text-align:left;margin:0 0 20px">
      <div style="font-size:11px;font-weight:700;color:#9CA3AF;text-transform:uppercase;letter-spacing:.5px;margin-bottom:10px">Usuario autenticado vía SSO</div>
      <div style="display:flex;gap:14px;align-items:center">
        <span style="font-size:36px">👤</span>
        <div>
          <div style="font-weight:800;font-size:16px;color:#111827"><?= e($usuario['nombre'] ?? '') ?></div>
          <div style="font-size:13px;color:#6B7280">Rol: <span class="pill pill-<?= $usuario['rol']==='admin'?'purple':($usuario['rol']==='editor'?'blue':'green') ?>"><?= e($usuario['rol']??'') ?></span></div>
          <div style="font-size:11px;color:#9CA3AF;margin-top:4px">JWT HS256 · Token SSO validado ✓</div>
        </div>
      </div>
    </div>
    <div class="flow">
      <div class="node">📚 App A<br><small>Bookia</small></div>
      <span class="arrow">→</span>
      <div class="node">🔑 JWT 60s</div>
      <span class="arrow">→</span>
      <div class="node active">🗂️ App B<br><small>Esta app</small></div>
    </div>
    <a href="<?= url('index.php') ?>" class="btn btn-ghost btn-sm">← Volver a Bookia</a>

  <?php elseif (is_logged_in()): ?>
    <h2 style="font-size:22px;font-weight:900;color:#111827;margin-bottom:6px">App B — Aplicación Externa</h2>
    <p style="font-size:14px;color:#6B7280;margin-bottom:20px">Estás en Bookia (App A). Haz clic para acceder a App B sin volver a autenticarte.</p>
    <div class="flow" style="margin-bottom:24px">
      <div class="node active">📚 App A ✓</div>
      <span class="arrow">→</span>
      <div class="node">🔑 JWT SSO</div>
      <span class="arrow">→</span>
      <div class="node">🗂️ App B</div>
    </div>
    <a href="<?= url("sso_appb.php?token=$tokenSso") ?>" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px;font-size:15px">
      Acceder a App B con SSO →
    </a>

  <?php else: ?>
    <h2 style="font-size:22px;font-weight:900;color:#111827;margin-bottom:6px">App B — Aplicación Externa</h2>
    <p style="font-size:14px;color:#6B7280;margin-bottom:20px">Debes iniciar sesión en Bookia primero.</p>
    <div class="flow" style="margin-bottom:24px">
      <div class="node">📚 App A</div>
      <span class="arrow">→</span>
      <div class="node">🔑 JWT SSO</div>
      <span class="arrow">→</span>
      <div class="node">🗂️ App B</div>
    </div>
    <a href="<?= url('login.php') ?>" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px">Ir a iniciar sesión →</a>
  <?php endif; ?>
</div>
</body>
</html>
